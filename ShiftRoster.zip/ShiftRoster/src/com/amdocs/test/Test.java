package com.amdocs.test;

import java.util.Calendar;

public class Test
{
	public static void main(String args[])
	{	String month,year,day;
		Calendar c=Calendar.getInstance();
		if((c.get(Calendar.MONTH)+1)<=9)
		month="0"+(c.get(Calendar.MONTH)+1);
		else
		{
			month=""+(c.get(Calendar.MONTH)+1);
		}
		if((c.get(Calendar.DAY_OF_MONTH)+1)<=9)
			day="0"+(c.get(Calendar.DAY_OF_MONTH)+1);
			else
			{
				day=""+(c.get(Calendar.DAY_OF_MONTH)+1);
			}
	
				year=(""+(c.get(Calendar.YEAR)+1)).substring(2,4);
		
				String folder=month+"-"+day+"-"+year;
				System.out.println(folder);
		
	}
}