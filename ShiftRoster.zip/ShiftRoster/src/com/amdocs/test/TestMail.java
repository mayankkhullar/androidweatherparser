package com.amdocs.test;

import java.util.Properties;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

public class TestMail {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		  String to = "";
		  String to1="";
		  String subject="";
		  String email_message="";
	      // Sender's email ID needs to be mentioned
	     // String from = "ShiftRoster@amdocs.com";
	      String from="roster@amdocs.com";
	      // Assuming you are sending email from localhost
	      String host = "ggnmail.corp.amdocs.com";
	      System.setProperty("java.net.preferIPv4Stack" , "true");
	      // Get system properties
	      Properties properties = System.getProperties();

	      // Setup mail server
	      properties.setProperty("mail.smtp.host", host);

	      // Get the default Session object.
	      Session session = Session.getDefaultInstance(properties);
	      
	      

	      try{
	    	  
	    //	  Context initCtx = new InitialContext();
	     //     Context envCtx = (Context) initCtx.lookup("java:comp/env");
	    //      Session session = (Session) envCtx.lookup("mail/NomDeLaRessource");
	         // Create a default MimeMessage object.
	         MimeMessage message = new MimeMessage(session);

	         // Set From: header field of the header.
	         message.setFrom(new InternetAddress(from));

	         // Set To: header field of the header.
	         message.addRecipient(Message.RecipientType.TO,
	                                  new InternetAddress(to));
	         message.addRecipient(Message.RecipientType.TO,
                     new InternetAddress(to1));
	         // Set Subject: header field
	         message.setSubject(subject);

	         // Send the actual HTML message, as big as you like
	         message.setContent(email_message,"text/html" );

	         // Send message
	         Transport.send(message);
	         System.out.println("Sent message successfully....");
	      }catch (MessagingException mex) {
	         mex.printStackTrace();
	      }// catch (NamingException e) {
			// TODO Auto-generated catch block
		//	e.printStackTrace();
		//}
	   }

}
