package com.amdocs.test;

import java.io.File;

import com.jacob.*;
import com.jacob.activeX.*;
import com.jacob.com.*;


public class JACOBTest {
	  static {
	        File lib = new File("C:\\Users\\sahilba\\Downloads\\" + LibraryLoader.getPreferredDLLName() + ".dll");
	        System.setProperty(LibraryLoader.JACOB_DLL_PATH, lib.getAbsolutePath());

	        System.out.println("JACOB_DLL_PATH = " + lib.getAbsolutePath());
	        LibraryLoader.loadJacobLibrary();
	    }
	@SuppressWarnings({ "deprecation", "static-access" })
	public static void main(String args[])
	{ final int olFolderContacts = 6;
    ActiveXComponent ol = new ActiveXComponent("Outlook.Application");
		Dispatch dsp = new Dispatch();
	    Dispatch olo = ol.getObject();
	    Dispatch myNamespace = Dispatch.call(olo, "GetNamespace", "MAPI")
	            .toDispatch();
	    Dispatch myFolder = Dispatch.call(myNamespace, "GetDefaultFolder",
	            new Integer(olFolderContacts)).toDispatch();
	    Dispatch items = Dispatch.get(myFolder, "Items").toDispatch();
	    int count = Dispatch.call(items, "Count").toInt();

for(int i=count;i>=0;i--)
{
	    	Dispatch mailItem = Dispatch.call(items, "Item", new Variant(i)).toDispatch();
	    	System.out.println(count+" : "+" : "+i+" : "+mailItem.get(mailItem, "Subject"));
}		
	}

}
