package com.amdocs.tmo;
import org.springframework.stereotype.Controller;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
@Controller
public class MainmenuController {
	 @RequestMapping(value = "/myshift", method = RequestMethod.POST)
	  public String myShift(@RequestParam("name") String name,
			  				@RequestParam("team") String team,
			  				@RequestParam("ateam") String ateam,
			  				@RequestParam("id") String id,
			  				@RequestParam("project") String project,Model model) {
		 DateFormat dateFormat = new SimpleDateFormat("MMMM dd yyyy");
		  java.util.Date date = new java.util.Date();
		  model.addAttribute("team",team);
		  model.addAttribute("ateam",ateam);
 			model.addAttribute("name",name); 
 			model.addAttribute("date",date.toString());
 			model.addAttribute("id",id);
 			model.addAttribute("project",project);
		 return "myshift";
}
	 @RequestMapping(value = "/logout", method = RequestMethod.GET)
	  public String myShiftLogout() {
		 return "logout";
}
	 @RequestMapping(value = "/test", method = RequestMethod.GET)
	  public String myShiftLogout1() {
		 return "test";
}
}