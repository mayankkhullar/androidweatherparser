package com.amdocs.tmo;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.io.Writer;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.amdocs.tmo.model.SendMail;

@Controller
public class ShiftuploadController {
	
	@RequestMapping(value = "/fileupload", method = RequestMethod.POST)
	public String upload(@RequestParam("file") MultipartFile myFile,
						 @RequestParam("name") String name,
						 @RequestParam("team") String team,
						 @RequestParam("ateam") String ateam,
						 @RequestParam("id") String id,
						 @RequestParam("project") String project,Model model) {
		InputStream inputStream = null;
		OutputStream outputStream = null;
		 DateFormat dateFormat = new SimpleDateFormat("MM dd yyyy");
		  java.util.Date date = new java.util.Date();
		boolean isError=false;
	try {
		Class.forName("oracle.jdbc.driver.OracleDriver");
		  Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@sorabhh01v:1521/xe","system", "amdocs");
		  Statement stmt=conn.createStatement();
		  String sql="Delete from test_shifts where nt_id is null or shift is null";
		inputStream = myFile.getInputStream();
		outputStream = new FileOutputStream("C:\\upload_test\\"+ myFile.getOriginalFilename(),false);
		int readBytes = 0;
		byte[] buffer = new byte[8192];
		while ((readBytes = inputStream.read(buffer, 0, 8192)) != -1) 
		{outputStream.write(buffer, 0, readBytes);}
		outputStream.close();
		inputStream.close();
		Test t=new Test();
		t.update_db("C:\\upload_test\\"+ myFile.getOriginalFilename());
		stmt.executeUpdate(sql);
		conn.close();
	} catch (IOException e) {
		isError=true;
		e.printStackTrace();
	}
	catch (ClassNotFoundException ee) {
		isError=true;
	}
	catch (SQLException eee) {
		isError=true;
		eee.printStackTrace();
	} catch (ParseException e) {
		isError=true;
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
		model.addAttribute("team",team);
		model.addAttribute("ateam",ateam);
		model.addAttribute("name",name.toString()); 
		model.addAttribute("date",date.toString());
		model.addAttribute("id",id);
		model.addAttribute("project",project);
		if(!isError){
	model.addAttribute("message","The file is uploaded and database is updated successfully");
	  return "fileupload";}
		else
		{
			model.addAttribute("message","<H1>Error Occured !!!! Please check the sample file and upload the file again.</H1>");
			  return "fileupload";
		}
}
	
	@RequestMapping(value = "/download", method = RequestMethod.POST)
	public void download(HttpServletRequest request,HttpServletResponse response,@RequestParam("project") String project)throws ServletException, IOException
	{
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		 String filename = "test2.xlsx"; 
		  String filepath = "C:\\"; 
		  response.setContentType("APPLICATION/OCTET-STREAM"); 
		  response.setHeader("Content-Disposition","attachment; filename=\"" + filename + "\""); 

		  java.io.FileInputStream fileInputStream = new java.io.FileInputStream(filepath + filename);
		  
		  int i; 
		  while ((i=fileInputStream.read()) != -1) {
		    out.write(i); 
		  } 
		  fileInputStream.close(); 
		  out.close(); 

}
	@RequestMapping(value = "/downloadsheet", method = RequestMethod.POST)
	public void downloadSheet(HttpServletRequest request,HttpServletResponse response,@RequestParam("project") String project,@RequestParam("mm") String month,
				@RequestParam("yy") String year,
  				@RequestParam("tm") String reqteam,Model model)throws ServletException, IOException
	{	ImportShift obj=new ImportShift();
		obj.importShift(month,year,reqteam,project);
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		 String filename = "ShiftImport.xlsx"; 
		  String filepath = "C:\\tomcat\\"; 
		  response.setContentType("APPLICATION/OCTET-STREAM"); 
		  response.setHeader("Content-Disposition","attachment; filename=\"" + filename + "\""); 

		  java.io.FileInputStream fileInputStream = new java.io.FileInputStream(filepath + filename);
		  
		  int i; 
		  while ((i=fileInputStream.read()) != -1) {
		    out.write(i); 
		  } 
		  fileInputStream.close(); 
		  out.close(); 

}
	 @RequestMapping(value = "/import", method = RequestMethod.POST)
	  public String myShiftChangeReview(@RequestParam("name") String name,
			  				@RequestParam("team") String team,
			  				@RequestParam("id") String id,
			  				@RequestParam("ateam") String ateam,
			  				@RequestParam("project") String project,Model model) {
		 DateFormat dateFormat = new SimpleDateFormat("MMMM dd yyyy");
		  java.util.Date date = new java.util.Date();
		  model.addAttribute("team",team);
			model.addAttribute("name",name); 	
			model.addAttribute("date",date.toString());
			model.addAttribute("id",id);
			 model.addAttribute("ateam",ateam);
			 model.addAttribute("project",project);
		 return "import";	
}
	 
	 @RequestMapping(value = "/importreport", method = RequestMethod.POST)
	  public String report(@RequestParam("name") String name,
			  				@RequestParam("team") String team,
			  				@RequestParam("id") String id,
			  				@RequestParam("ateam") String ateam,
			  				@RequestParam("project") String project,Model model) {
		 DateFormat dateFormat = new SimpleDateFormat("MMMM dd yyyy");
		  java.util.Date date = new java.util.Date();
		  model.addAttribute("team",team);
			model.addAttribute("name",name); 	
			model.addAttribute("date",date.toString());
			model.addAttribute("id",id);
			 model.addAttribute("ateam",ateam);
			 model.addAttribute("project",project);
		 return "importreport";	
}
	 
		@RequestMapping(value = "/downloadreport", method = RequestMethod.POST)
		public void downloadReportSheet(HttpServletRequest request,HttpServletResponse response,@RequestParam("project") String project,@RequestParam("mm") String month,
					@RequestParam("yy") String year,
	  				Model model)throws ServletException, IOException
		{	ShiftReports report=new ShiftReports();
		report.importShift(month,year,project);
			response.setContentType("text/html");
			PrintWriter out = response.getWriter();
			 String filename = "ShiftImportReport.xlsx"; 
			  String filepath = "C:\\tomcat\\"; 
			  response.setContentType("APPLICATION/OCTET-STREAM"); 
			  response.setHeader("Content-Disposition","attachment; filename=\"" + filename + "\""); 

			  java.io.FileInputStream fileInputStream = new java.io.FileInputStream(filepath + filename);
			  
			  int i; 
			  while ((i=fileInputStream.read()) != -1) {
			    out.write(i); 
			  } 
			  fileInputStream.close(); 
			  out.close(); 

	}

}