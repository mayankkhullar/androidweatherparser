package com.amdocs.tmo;
import org.springframework.stereotype.Controller;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.io.Writer;
import java.sql.*;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.amdocs.tmo.model.SendMail;

@Controller
public class WelcomeController {
	 @RequestMapping(value = "/welcome", method = RequestMethod.POST)
	  public String welcome(@RequestParam("id") String id, Model model) {
		 try { 
			  Class.forName("oracle.jdbc.driver.OracleDriver");
			  Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@sorabhh01v:1521/xe","system", "amdocs");
			  if(conn !=null)
			  {
				  System.out.println(id + "connected to database");
				  Statement stmt;
				  stmt = conn.createStatement();
				  List<String> projects=new ArrayList<String>();
			      String sql = "SELECT distinct project FROM test_employee_details where nt_id='"+id+"'";
			      ResultSet rs = stmt.executeQuery(sql);
			      while(rs.next())
			      {
			    	  projects.add(rs.getString("project"));
			      }
		model.addAttribute("projects", projects);
	
			  }
			conn.close();  
		      }
		      catch (Exception e)
		      {
		              e.printStackTrace();
		      }
		 return "welcome";
}
	 
	 @RequestMapping(value = "/mainmenu", method = RequestMethod.POST)
	 public String validation(@RequestParam("id") String id,
			 			@RequestParam("project1") String project,HttpServletRequest request,Model model){
		 boolean flag=false;
		 DateFormat dateFormat = new SimpleDateFormat("MMMM dd yyyy");
		  java.util.Date date = new java.util.Date();
		StringBuilder team=new StringBuilder("Unknown");
		StringBuilder ateam=new StringBuilder("Unknown");
	//	StringBuilder project=new StringBuilder();
		 StringBuilder emp_name=new StringBuilder(id);
		 try { 
			  Class.forName("oracle.jdbc.driver.OracleDriver");
			  Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@sorabhh01v:1521/xe","system", "amdocs");
			  if(conn !=null)
			  {
				  System.out.println(id + "connected to database");
				  Statement stmt;
				  stmt = conn.createStatement();

			      String sql = "SELECT nt_id,team,fname,lname,ateam FROM test_employee_details where project='"+project+"'";
			      ResultSet rs = stmt.executeQuery(sql);
			      while(rs.next())
			      {
			    	 if(emp_name.toString().equalsIgnoreCase(rs.getString("nt_id")))
			    	 {
			    		 flag=true;
			    		
			    		 if(flag)
			    		 {	emp_name=new StringBuilder("");
			    		 	team=new StringBuilder("");
			    		 	ateam=new StringBuilder("");
			    		 	emp_name=emp_name.append(rs.getString("fname").toUpperCase());
			    		 	emp_name=emp_name.append(" "+rs.getString("lname").toUpperCase());
			    		 	team=team.append(rs.getString("team"));
			    		 	ateam=ateam.append(rs.getString("ateam"));
			    		
			    		 }
			    		 break;
			    	 }
			      }
			      request.getSession().setAttribute("team", team);  
			      request.getSession().setAttribute("ateam", ateam);  
			      request.getSession().setAttribute("name", emp_name.toString());  
			      request.getSession().setAttribute("id", id);  
			      request.getSession().setAttribute("project", project);  
			model.addAttribute("team",team);
			model.addAttribute("ateam",ateam);
   			model.addAttribute("name",emp_name.toString()); 
   			model.addAttribute("date",date.toString());
   			model.addAttribute("id",id);
   			model.addAttribute("project",project);
   			
			  }
			conn.close();  
		      }
		      catch (Exception e)
		      {
		              e.printStackTrace();
		      }
		      
		     if(flag)
		     {
		    	 return "mainmenu_new";
		     }
		     else
		     {
		    	 return "error";
		     }
		 
	  }
	 
	 @RequestMapping(value = "/managerportal", method = RequestMethod.POST)
	 public String managerValidation(@RequestParam("mname") String mname,
			 @RequestParam("project2") String project,Model model){
		 boolean flag=false;
		 boolean delegator=false;
		 DateFormat dateFormat = new SimpleDateFormat("MMMM dd yyyy");
		  java.util.Date date = new java.util.Date();
		  StringBuilder team=new StringBuilder("Unknown");
		  StringBuilder ateam=new StringBuilder("Unknown");
			 StringBuilder emp_name=new StringBuilder(mname);
			 try { 
				  Class.forName("oracle.jdbc.driver.OracleDriver");
				  Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@sorabhh01v:1521/xe","system", "amdocs");
				  if(conn !=null)
				  {
					  System.out.println(mname+"connected to database");
					  Statement stmt,pstmt;
					  String delegator_sql="SELECT id FROM test_manager where id='"+mname.toUpperCase()+"' and delegate='Y' and project='"+project+"'";
					  String sql = "SELECT id FROM test_manager where id='"+mname.toUpperCase()+"' and delegate='N' and project='"+project+"'";
					  String psql = "SELECT nt_id,team,fname,lname,ateam FROM test_employee_details where nt_id='"+mname.toUpperCase()+"' and project='"+project+"'";
					  stmt = conn.createStatement();	
					  pstmt = conn.createStatement();
				      ResultSet rs = stmt.executeQuery(sql);
				      while(rs.next())
				      {
				    	  if(emp_name.toString().equalsIgnoreCase(rs.getString("id")))
				    	 {
				    		 flag=true;
				    	 }
				      }
				      ResultSet del_rs = stmt.executeQuery(delegator_sql);
				      while(del_rs.next())
				      {
				    	  if(emp_name.toString().equalsIgnoreCase(del_rs.getString("id")))
				    	 {
				    		  delegator=true;
				    	 }
				      }
				    	if(flag || delegator)
				    		 {	ResultSet prs = pstmt.executeQuery(psql);
				    			 emp_name=new StringBuilder("");
				    		 	team=new StringBuilder("");
				    		 	ateam=new StringBuilder("");
				    	//	 	project=new StringBuilder("");
				    		 	while(prs.next()){
				    		 	emp_name=emp_name.append(prs.getString("fname").toUpperCase());
				    		 	emp_name=emp_name.append(" "+prs.getString("lname").toUpperCase());
				    		 	team=team.append(prs.getString("team"));
				    		 	ateam=ateam.append(prs.getString("ateam"));
				    		// 	project=project.append(prs.getString("project"));
				    		 	
				    		 	}
				    		
				    		 }
				model.addAttribute("ateam",ateam);    	
				model.addAttribute("team",team);
	   			model.addAttribute("name",emp_name.toString()); 
	   			model.addAttribute("date",date.toString());
	   			model.addAttribute("id",mname);
	   			model.addAttribute("project",project);
	   			
				  }
				conn.close();  
			      }
			      catch (Exception e)
			      {
			              e.printStackTrace();
			      }
			      
			     if(flag)
			     {
			    	 return "managerportal";
			     }
			     else if(delegator)
			     {
			    	 return "managerportaldelegator";
			     }
			     else
			     {
			    	 return "error";
			     }
	 }
}

