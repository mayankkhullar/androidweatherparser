package com.amdocs.tmo;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.io.Writer;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Iterator;
import java.util.List;

import com.amdocs.tmo.model.SendMail;

public class ShiftCountsWeekendJewel {
	String[] days={"Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"};
	String[] months = {"","Jan", "Feb","Mar", "Apr", "May", "Jun", "Jul","Aug", "Sep", "Oct", "Nov","Dec"};
	StringBuilder message,message1;
	public StringBuilder countShifts(String month,String year,String team,String project) throws ParseException
	{	List<String> weekends=new ArrayList<String>();
		List<String> weekdays=new ArrayList<String>();
		String dates[]=new String[35];
	 String ntid[]=new String[50];
	 
	 int count=0;
		 try { 
			 Class.forName("oracle.jdbc.driver.OracleDriver");
			  Connection conn = (Connection) DriverManager.getConnection("jdbc:oracle:thin:@sorabhh01v:1521/xe","system", "amdocs");
			  Statement stmt=conn.createStatement();
			  int day=HelperClass.getDays(month,year);
				 String from_date="01-"+month+"-"+year;
				 String to_date=day+"-"+month+"-"+year;
				 String sql="Select distinct dt from test_shifts where dt > = '"+from_date+"' and dt < = '"+to_date+"' order by dt";
				 ResultSet rs=stmt.executeQuery(sql);
				 while(rs.next())
				 {
					 Date dt=rs.getDate("dt");
					 Calendar c = Calendar.getInstance();
				  		c.setTime(dt);
				  		int day_of_week = c.get(Calendar.DAY_OF_WEEK);
				  		if(days[day_of_week - 1].equalsIgnoreCase("Sunday") || days[day_of_week - 1].equalsIgnoreCase("Saturday"))
				  		{
				  			weekends.add(dt.toString());
				  		}
				  		else
				  		{
				  			weekdays.add(dt.toString());
				  		}
				 }
				 String sql_ntid="select distinct nt_id from test_shifts where team='"+team+"' and dt >='"+from_date+"'and dt < = '"+to_date+"' and project='"+project+"'order by nt_id ";
				 ResultSet rs_sql_ntid=stmt.executeQuery(sql_ntid);
				 while(rs_sql_ntid.next())
				 {
					 ntid[count]=rs_sql_ntid.getString("nt_id");
					 count++;
				 }
				 message=new StringBuilder();
				 message=message.append("<h3>Weekend Count : </h3><br><br><table border=\"1\"><tr><th bgcolor=\"#C0C0C0\">Name</th>" +
				 						"<th>Morning</th>" +
				 						"<th>Afternoon</th>"+
				 						"<th>Late Morning</th>"+
				 						"<th>General</th>"+
				 						"<th>On Call</th>"+
				 						"<th>Backup On Call</th>"+
				 						"<th>L3OC</th>"+
				 						"<th>Training</th>"+
				 						"<th>Vacation</th>"+
				 						"<th>WeekOff</th>"+
				 						"<th>Sickleave</th>"+
				 						"<th>US Holiday</th>"+
				 						"<th>Holiday</th>"+
				 						"<th>Opt.Off</th>"+
				 						"<th>Release weekend</th>"+
				 						"<th>Travel</th>"+
				 						"<th>Comp-Off</th>"+
				 						"<th>Maternity Leaves</th>"
				 						);
				 for(int i=0;i<count;i++)
				 {	
					int a=0,lm=0,mo=0,oc=0,g=0,c=0,v=0,tr=0,dh=0,t=0,uh=0,sl=0,oh=0,boc=0,rw=0,ml=0,l3oc=0,wo=0;
					 Iterator iter=weekends.iterator();
					 message.append("<tr><td>"+GetNamesDb.getNames(ntid[i],conn)+"</td>");
					 while(iter.hasNext())
					 {		SimpleDateFormat formatter=new SimpleDateFormat("dd-MM-yyyy");
					 		String dt=(String) iter.next();
					 			String temp=dt.toString().substring(5,7);
					 		String m=months[Integer.parseInt(temp)];
					 		String tempp=dt.substring(8, 10);
					 		tempp= tempp+"-"+m;
						 String get_shift="Select shift from test_shifts where nt_id='"+ntid[i]+"' and dt='"+tempp+"-"+year+"'";
						 ResultSet rs_get_shift=stmt.executeQuery(get_shift);
						 String shift="";
						 while(rs_get_shift.next()){
							 shift=rs_get_shift.getString("shift");
						 }
						 if(shift.equalsIgnoreCase("A"))
						 {
							 a++;
						 }
						 else if(shift.equalsIgnoreCase("LM"))
						 {
							 lm++;
						 }
						 else if(shift.equalsIgnoreCase("M"))
						 {
							 mo++;
						 }
						 else if(shift.equalsIgnoreCase("OC"))
						 {
							 oc++;
						 }
						 else if(shift.equalsIgnoreCase("G"))
						 {
							 g++;
						 }
						 else if(shift.equalsIgnoreCase("C"))
						 {
							 c++;
						 }
						 else if(shift.equalsIgnoreCase("V"))
						 {
							 v++;
						 }
						 else if(shift.equalsIgnoreCase("TR"))
						 {
							 tr++;
						 }
						 else if(shift.equalsIgnoreCase("DH"))
						 {
							 dh++;
						 }
						 else if(shift.equalsIgnoreCase("T"))
						 {
							 t++;
						 }
						 else if(shift.equalsIgnoreCase("UH"))
						 {
							uh++; 
						 }
						 else if(shift.equalsIgnoreCase("SL"))
						 {
							sl++; 
						 }
						 else if(shift.equalsIgnoreCase("OH"))
						 {
							oh++; 
						 }
						 else if(shift.equalsIgnoreCase("BOC"))
						 {
							boc++; 
						 }
						 else if(shift.equalsIgnoreCase("RW"))
						 {
							rw++; 
						 }
						 else if(shift.equalsIgnoreCase("ML"))
						 {
							ml++; 
						 }
						 else if(shift.equalsIgnoreCase("L3OC"))
						 {
							l3oc++; 
						 }
						 else if(shift.equalsIgnoreCase("WO"))
						 {
							wo++; 
						 }
					 }
					 message.append("<td>"+mo+"</td>");
					 message.append("<td>"+a+"</td>");
					 message.append("<td>"+lm+"</td>");
					 message.append("<td>"+g+"</td>");
					 message.append("<td>"+oc+"</td>");
					 message.append("<td>"+boc+"</td>");
					 message.append("<td>"+l3oc+"</td>");
					 message.append("<td>"+tr+"</td>");
					 message.append("<td>"+v+"</td>");
					 message.append("<td>"+wo+"</td>");
					 message.append("<td>"+sl+"</td>");
					 message.append("<td>"+uh+"</td>");
					 message.append("<td>"+dh+"</td>");
					 message.append("<td>"+oh+"</td>");
					 message.append("<td>"+rw+"</td>");
					 message.append("<td>"+t+"</td>");
					 message.append("<td>"+c+"</td>");
					 message.append("<td>"+ml+"</td></tr>");
				 }
				 message.append("</table><br><br>");
				message1=new StringBuilder();
				 message1=message1.append("<h3>WeekDay Count : </h3><br><table border=\"1\"><tr><th bgcolor=\"#C0C0C0\">Name</th>" +
						 "<th>Morning</th>" +
	 						"<th>Afternoon</th>"+
	 						"<th>Late Morning</th>"+
	 						"<th>General</th>"+
	 						"<th>On Call</th>"+
	 						"<th>Backup On Call</th>"+
	 						"<th>L3OC</th>"+
	 						"<th>Training</th>"+
	 						"<th>Vacation</th>"+
	 						"<th>WeekOff</th>"+
	 						"<th>Sickleave</th>"+
	 						"<th>US Holiday</th>"+
	 						"<th>Holiday</th>"+
	 						"<th>Opt.Off</th>"+
	 						"<th>Release weekend</th>"+
	 						"<th>Travel</th>"+
	 						"<th>Comp-Off</th>"+
	 						"<th>Maternity Leaves</th>"
	 						);
				 for(int i=0;i<count;i++)
				 {	
					 int a=0,lm=0,mo=0,oc=0,g=0,c=0,v=0,tr=0,dh=0,t=0,uh=0,sl=0,oh=0,boc=0,rw=0,ml=0,l3oc=0,wo=0;
					 Iterator iter=weekdays.iterator();
					 message1.append("<tr><td>"+GetNamesDb.getNames(ntid[i],conn)+"</td>");
					 while(iter.hasNext())
					 {		SimpleDateFormat formatter=new SimpleDateFormat("dd-MM-yyyy");
					 		String dt=(String) iter.next();
					 			String temp=dt.toString().substring(5,7);
					 		String m=months[Integer.parseInt(temp)];
					 		String tempp=dt.substring(8, 10);
					 		tempp= tempp+"-"+m;
						 String get_shift="Select shift from test_shifts where nt_id='"+ntid[i]+"' and dt='"+tempp+"-"+year+"'";
						 ResultSet rs_get_shift=stmt.executeQuery(get_shift);
						 String shift="";
						 while(rs_get_shift.next()){
							 shift=rs_get_shift.getString("shift");
						 }
						 if(shift.equalsIgnoreCase("A"))
						 {
							 a++;
						 }
						 else if(shift.equalsIgnoreCase("LM"))
						 {
							 lm++;
						 }
						 else if(shift.equalsIgnoreCase("M"))
						 {
							 mo++;
						 }
						 else if(shift.equalsIgnoreCase("OC"))
						 {
							 oc++;
						 }
						 else if(shift.equalsIgnoreCase("G"))
						 {
							 g++;
						 }
						 else if(shift.equalsIgnoreCase("C"))
						 {
							 c++;
						 }
						 else if(shift.equalsIgnoreCase("V"))
						 {
							 v++;
						 }
						 else if(shift.equalsIgnoreCase("TR"))
						 {
							 tr++;
						 }
						 else if(shift.equalsIgnoreCase("DH"))
						 {
							 dh++;
						 }
						 else if(shift.equalsIgnoreCase("T"))
						 {
							 t++;
						 }
						 else if(shift.equalsIgnoreCase("UH"))
						 {
							uh++; 
						 }
						 else if(shift.equalsIgnoreCase("SL"))
						 {
							sl++; 
						 }
						 else if(shift.equalsIgnoreCase("OH"))
						 {
							oh++; 
						 }
						 else if(shift.equalsIgnoreCase("BOC"))
						 {
							boc++; 
						 }
						 else if(shift.equalsIgnoreCase("RW"))
						 {
							rw++; 
						 }
						 else if(shift.equalsIgnoreCase("ML"))
						 {
							ml++; 
						 }
						 else if(shift.equalsIgnoreCase("L3OC"))
						 {
							l3oc++; 
						 }
						 else if(shift.equalsIgnoreCase("WO"))
						 {
							wo++; 
						 }
					 }
					 message1.append("<td>"+mo+"</td>");
					 message1.append("<td>"+a+"</td>");
					 message1.append("<td>"+lm+"</td>");
					 message1.append("<td>"+g+"</td>");
					 message1.append("<td>"+oc+"</td>");
					 message1.append("<td>"+boc+"</td>");
					 message1.append("<td>"+l3oc+"</td>");
					 message1.append("<td>"+tr+"</td>");
					 message1.append("<td>"+v+"</td>");
					 message1.append("<td>"+wo+"</td>");
					 message1.append("<td>"+sl+"</td>");
					 message1.append("<td>"+uh+"</td>");
					 message1.append("<td>"+dh+"</td>");
					 message1.append("<td>"+oh+"</td>");
					 message1.append("<td>"+rw+"</td>");
					 message1.append("<td>"+t+"</td>");
					 message1.append("<td>"+c+"</td>");
					 message1.append("<td>"+ml+"</td></tr>");
				 }
				 message1.append("</table><br><br>");
				 conn.close();
	//			 SendMail obj=new SendMail();
	//			 String[] emailid=new String[50];
	//				String[] email_cc=new String[50];
	//				 emailid[0]="Sahil.batra@amdocs.com";
	//			 obj.sendMessage(message.toString()+message1.toString(), "Weekend and Weekday Shift Counts for team :"+team ,emailid,email_cc);
		 } 
		  catch (SQLException e)
			{     e.printStackTrace(); 
	          }
			catch (ClassNotFoundException e)
			{     e.printStackTrace(); 
	          }
			return message.append(message1);
	}
	 public static void main(String args[]) throws ParseException
	 {
//		 ShiftCountWeekends obj=new ShiftCountWeekends();
//		 obj.countShifts("Mar","2014","CM");
//		 obj.countShifts("Mar","2014","EP");
//		 obj.countShifts("Mar","2014","BI");
//		 obj.countShifts("Mar","2014","MW");
	 }
}
