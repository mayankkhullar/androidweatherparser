package com.amdocs.tmo;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.io.Writer;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CreationHelper;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.amdocs.tmo.model.SendMail;

public class ImportShift {
	
	public void importShift(String month,String year,String team,String project)
	{
		
		try {
			String dates[]=new String[35];
			String[] nt_id=new String[100];
			XSSFWorkbook workbook = new XSSFWorkbook();
			XSSFSheet sheet = workbook.createSheet(month+"-"+year);
			XSSFCellStyle style=workbook.createCellStyle();
			XSSFCellStyle stylecolor=workbook.createCellStyle();
			CreationHelper createHelper = workbook.getCreationHelper();
			style.setDataFormat(
				        createHelper.createDataFormat().getFormat("dd-mmm-yyyy"));
			String[] months = {"","Jan", "Feb","Mar", "Apr", "May", "Jun", "Jul","Aug", "Sep", "Oct", "Nov","Dec"};
			  Class.forName("oracle.jdbc.driver.OracleDriver");
			Class.forName("oracle.jdbc.driver.OracleDriver");
			  Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@sorabhh01v:1521/xe","system", "amdocs");
			  Statement stmt=conn.createStatement();
			  stmt = conn.createStatement();
			  Row row0=sheet.createRow(0);
			  Cell cell0=row0.createCell(0);
			  cell0.setCellValue("NTID");
			  Cell cell1=row0.createCell(1);
			  cell1.setCellValue("Team");
			  Cell cell2=row0.createCell(2);
			  cell2.setCellValue("Project");
			  File f=new File("C:\\tomcat\\ShiftImport.xlsx");
			  String mon="";
				 if(!month.equalsIgnoreCase("")){ mon=month.substring(0, 3);}
				 int day=HelperClass.getDays(mon,year);
				 String from_date="01-"+mon+"-"+year;
				 String to_date=day+"-"+mon+"-"+year;
			  String get_dates="select distinct dt from test_shifts where project='"+project+"' and dt > = '"+from_date+"' and dt < = '"+to_date+"' order by dt";
			  ResultSet rs_get_dates=stmt.executeQuery(get_dates);
			  int count=3;
			  int days=0;
			  while(rs_get_dates.next())
			  {	
				 Cell cell=row0.createCell(count);
				 cell.setCellValue(rs_get_dates.getDate("dt"));
				 cell.setCellStyle(style);
				 count++;
				 java.sql.Date dt=rs_get_dates.getDate("dt");
				  Calendar c = Calendar.getInstance();
		  			c.setTime(dt);
				  	String temp=rs_get_dates.getString("dt").substring(5,7);
		  			String m=months[Integer.parseInt(temp)];
		  			String tempp=rs_get_dates.getString("dt").substring(8, 10);
		  			tempp= tempp+"-"+m;
				  dates[days]=tempp;
				  days++;
			  }
			  String get_nt_id="";
			  if(team.equalsIgnoreCase("ALL"))
			  {
				  get_nt_id="select distinct nt_id from test_shifts where shift is not null and dt >='"+from_date+"' and project='"+project+"' order by nt_id"; 
			  }
			  else
			  {	  
			  get_nt_id="select distinct nt_id from test_shifts where team='"+team+"' and dt >='"+from_date+"' and project='"+project+"' order by nt_id ";
			  }
			  ResultSet rs_get_nt_id=stmt.executeQuery(get_nt_id);
			  int ntidcount=0;
			  while(rs_get_nt_id.next())
			  {
				  nt_id[ntidcount]=rs_get_nt_id.getString("nt_id");
				  ntidcount++;  
			  }
			  for(int i=0;i<ntidcount;i++)
			  {Row row=sheet.createRow(i+1);
			  	Cell c0=row.createCell(0);
			  	c0.setCellValue(nt_id[i]);
			  	Cell c1=row.createCell(1);
			  	c1.setCellValue(GetNamesDb.getTeam(nt_id[i],conn,project));
			  	Cell c2=row.createCell(2);
			  	c2.setCellValue(project);
				  	for(int k=0;k<days;k++)
				  	{
				  		String get_shift="select shift from test_shifts where nt_id='"+nt_id[i]+"' and dt='"+dates[k]+"-"+year+"'";
				  		ResultSet rs_get_shift=stmt.executeQuery(get_shift);
				  		while(rs_get_shift.next())
				  		{String temp=rs_get_shift.getString("shift");
				  			Cell cc=row.createCell(k+3);
				  			cc.setCellValue(temp);
				  		}
				  	}
			  }
			  if(f.exists())
			  {
				  f.delete();
				  f.createNewFile();
			  }
			  else
			  {
				  f.createNewFile(); 
			  }
		    FileOutputStream out =
		            new FileOutputStream(f);
		    workbook.write(out);
		    out.close();
		    System.out.println("Excel written successfully..");
		     
		} catch (FileNotFoundException e) {
		    e.printStackTrace();
		} catch (IOException e) {
		    e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public static void main(String args[])
	{
		ImportShift obj=new ImportShift();
		obj.importShift("May","2014","CM","TMO-US");
	}

}
