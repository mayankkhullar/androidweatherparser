package com.amdocs.tmo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import com.amdocs.tmo.model.SendMail;

public class ReportScheduler {

	/**
	 * @param args
	 * @throws ClassNotFoundException 
	 * @throws SQLException 
	 * @throws ParseException 
	 */
	public static void main(String[] args) throws ClassNotFoundException, SQLException, ParseException {
		String[] team_array={"CM","MW","EP"};
	//	String[] email={"ankur.mehta@amdocs.com","ISHLEEN.CHHABRA@AMDOCS.COM","PRASHANT.VERMA@AMDOCS.COM "};
		String[] email={"sahil.batra@amdocs.com"};
		String[] email_cc={"sahil.batra@amdocs.com"};
		 for(int i=0;i<team_array.length;i++)
		  {	 if(!team_array[i].equalsIgnoreCase("")){
			  SimpleDateFormat formatter = new SimpleDateFormat("dd-MMM-yyyy");
				Calendar cal = Calendar.getInstance();
				    cal.add(Calendar.DATE, -1); 
				  int  day_of_week = cal.get(Calendar.DAY_OF_WEEK);
				  String dt=formatter.format(cal.getTime());
				  String month=dt.substring(3, 6);
				  String year=dt.substring(7, 11);
				  String project="TMO-US";
			  			StringBuilder mailMessage= new StringBuilder();
						WeeklyReport obj=new WeeklyReport();
					 	mailMessage.append(obj.generateMonthlyShifts(month,year,team_array[i],01,07,project));
						mailMessage.append(obj.generateMonthlyShifts(month,year,team_array[i],8,14,project));
						mailMessage.append(obj.generateMonthlyShifts(month,year,team_array[i],15,21,project));
						mailMessage.append(obj.generateMonthlyShifts(month,year,team_array[i],22,28,project));
						mailMessage.append(obj.generateMonthlyShifts(month,year,team_array[i],29,0,project));
						mailMessage.append(new PerPersonShiftCountReport().perPersonReports(team_array[i], month.substring(0,3), year,project));
						mailMessage.append(new ShiftCountWeekends().countShifts(month.substring(0,3), year, team_array[i],project));
				//		mailMessage.append(new ShiftCountWeekends().countShifts(month.substring(0,3), year, team_array[i],project));
					    mailMessage.append(new NightShiftCount().countNightShift(month.substring(0, 3), year, team_array[i],project));
					    new SendMail().sendMessage(mailMessage.toString(),"Monthly Report for team " +team_array[i], email, email_cc);
			  }
			 } 
		  }
}
