package com.amdocs.tmo;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.io.Writer;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Calendar;

import com.amdocs.tmo.model.SendMail;

public class RequestReport {
	
	void requestReports(String team)
	{String[] months = {"Jan", "Feb","Mar", "Apr", "May", "Jun", "Jul","Aug", "Sep", "Oct", "Nov","Dec"};
		String[] nt_id=new String[100];
		int count=0;
		String[] emailid=new String[50];
		emailid[0]="sahil.batra@amdocs.com";
		String[] email_cc=new String[50];
		StringBuilder message=new StringBuilder();
		Calendar cal = Calendar.getInstance();
		String month = months[cal.get(Calendar.MONTH)];
		int year=cal.get(Calendar.YEAR );
		int day=HelperClass.getDays(month,year+"");
		 String from_date="01-"+month+"-"+year;
		 String to_date=day+"-"+month+"-"+year;
		 try { 
			  Class.forName("oracle.jdbc.driver.OracleDriver");
			  Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@sorabhh01v:1521/xe","system", "amdocs");
			  Statement stmt=conn.createStatement();
			  stmt = conn.createStatement();
			  String sql="Select distinct nt_id from change_request where team='"+team+"'";
			  ResultSet rs=stmt.executeQuery(sql);
			  while(rs.next())
			  {nt_id[count]=rs.getString("nt_id");
			  	count++;
			  }
			  message.append("<html><body>Hi Leads,<br>Please find number of Request per person for current month<br><br><br><table border=\"1\"><tr><th bgcolor=\"light green\">Name</th><th  bgcolor=\"light green\">Total Request</th><th  bgcolor=\"light green\">Approved</th><th  bgcolor=\"light green\">Rejected</th><th  bgcolor=\"light green\">Pending</th><tr>");
			  for(int i=0;i<count;i++){
				  int total=0;
				  int rejected=0;
				  int approved=0;
				  int pending=0;
			  String sql_total="select count(*) from change_request where nt_id='"+nt_id[i]+"' and dt>='"+from_date+"' and dt<='"+to_date+"'";
			  ResultSet rs_total=stmt.executeQuery(sql_total);
			  while(rs_total.next())
			  {
				  total= rs_total.getInt(1);
			  }
			  String sql_approved="select count(*) from change_request where nt_id='"+nt_id[i]+"' and dt>='"+from_date+"' and dt<='"+to_date+"' and status=1";
			  ResultSet rs_sql_approved=stmt.executeQuery(sql_approved);
			  while(rs_sql_approved.next())
			  {
				  approved= rs_sql_approved.getInt(1);
			  }
			  String sql_reject="select count(*) from change_request where nt_id='"+nt_id[i]+"' and dt>='"+from_date+"' and dt<='"+to_date+"' and status=2";
			  ResultSet rs_sql_reject=stmt.executeQuery(sql_reject);
			  while(rs_sql_reject.next())
			  {
				  rejected= rs_sql_reject.getInt(1);
			  }
			  pending=total - (approved+rejected);
			  message.append("<tr><td>"+GetNamesDb.getNames(nt_id[i],conn)+"</td><td>"+total+"</td><td>"+approved+"</td><td>"+rejected+"</td><td>"+pending+"</td></tr>");
			  }
			  message.append("</table>");
			  conn.close();
			  SendMail obj=new SendMail();
			  obj.sendMessage(message.toString(), "Shift Change Request For Month Of "+month+" for Team "+team, emailid, email_cc);
			  } 
			  
		  catch (SQLException e)
			{     e.printStackTrace(); 
			Writer writer = new StringWriter();
	          PrintWriter printWriter = new PrintWriter(writer);
	          e.printStackTrace(printWriter);
	          String s = writer.toString();
	          SendMail m=new SendMail();
	          String[] ee=new String[1];
	          String[] ec=new String[0];
	          ee[0]="Sahil.batra@amdocs.com";
	          m.sendMessage(s,"Error Report", ee, ec);
	          }
		  catch (ClassNotFoundException e)
			{     e.printStackTrace(); 
			Writer writer = new StringWriter();
	          PrintWriter printWriter = new PrintWriter(writer);
	          e.printStackTrace(printWriter);
	          String s = writer.toString();
	          SendMail m=new SendMail();
	          String[] ee=new String[1];
	          String[] ec=new String[0];
	          ee[0]="Sahil.batra@amdocs.com";
	          m.sendMessage(s,"Error Report", ee, ec);
	          }
	}
}
