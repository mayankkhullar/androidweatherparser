package com.amdocs.tmo;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.io.Writer;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.amdocs.tmo.model.SendMail;

public class NightShiftCount {
	
	public StringBuilder countNightShift(String month,String year,String team,String project)
	{String[] nt_id=new String[100];
	int count=0;
	String mon="";
	int day=HelperClass.getDays(month,year+"");
	 String from_date="01-"+month+"-"+year;
	 String to_date=day+"-"+month+"-"+year;
	StringBuilder message=new StringBuilder();
		 try {
			 	String[] months = {"","Jan", "Feb","Mar", "Apr", "May", "Jun", "Jul","Aug", "Sep", "Oct", "Nov","Dec"};
			  Class.forName("oracle.jdbc.driver.OracleDriver");
			  Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@sorabhh01v:1521/xe","system", "amdocs");
			  Statement stmt=conn.createStatement();
			  stmt = conn.createStatement();
			  String sql="Select distinct nt_id from test_shifts where team='"+team+"' and project='"+project+"'";
			  ResultSet rs=stmt.executeQuery(sql);
			  
			  while(rs.next())
			  {nt_id[count]=rs.getString("nt_id");
			  	count++;
			  } 
			  for(int k=0;k<months.length;k++)
			  {
				  if(month.equalsIgnoreCase(months[k]))
				  {	if(k<10)
				  {
					  mon="0"+k; 
				  }
				  else
				  {
					  mon=""+k; 
				  }
				  }
			  }
			  message.append("<html><body>Hi Leads,<br>Please find number of shifts per person for "+month+" month<br><br><br><table border=\"1\"><tr><th>Emp. ID</th>");
			  message.append("<th>Employee Name (First & Last Name)</th><th>Month(YYYY/MM)</th><th>No. of Days worked in Shift during the month</th></tr>");
			  for(int i=0;i<count;i++)
			  {		
				  String names[]=GetFullNames.getNames(nt_id[i], conn).split("%");
				  message.append("<tr><td>"+names[0]+"</td><td>"+names[1]+"</td><td>"+year+"/"+mon+"</td>");
				  String shift_count="Select Count(*) from test_shifts where shift='N' and nt_id='"+nt_id[i]+"' and dt>='"+from_date+"' and dt<='"+to_date+"'";
				  ResultSet rs_sql_shift_count=stmt.executeQuery(shift_count);
				  while(rs_sql_shift_count.next())
				  {
					  message.append("<td>"+rs_sql_shift_count.getInt(1)+"</td>");
				  }
				  message.append("</tr>");
			  }
			  message.append("</table>");
			  conn.close();
			  } 
		  
		  catch (SQLException e)
			{     e.printStackTrace(); 
	          }
		  catch (ClassNotFoundException e)
			{     e.printStackTrace(); 
	          }
		  return message;
	}

}
