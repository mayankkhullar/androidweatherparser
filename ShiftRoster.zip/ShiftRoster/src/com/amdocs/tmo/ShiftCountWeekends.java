package com.amdocs.tmo;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.io.Writer;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Iterator;
import java.util.List;

import com.amdocs.tmo.model.SendMail;

public class ShiftCountWeekends {
	String[] days={"Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"};
	String[] months = {"","Jan", "Feb","Mar", "Apr", "May", "Jun", "Jul","Aug", "Sep", "Oct", "Nov","Dec"};
	StringBuilder message,message1;
	public StringBuilder countShifts(String month,String year,String team,String project) throws ParseException
	{	List<String> weekends=new ArrayList<String>();
		List<String> weekdays=new ArrayList<String>();
		String dates[]=new String[35];
	 String ntid[]=new String[50];
	 
	 int count=0;
		 try { 
			 Class.forName("oracle.jdbc.driver.OracleDriver");
			  Connection conn = (Connection) DriverManager.getConnection("jdbc:oracle:thin:@sorabhh01v:1521/xe","system", "amdocs");
			  Statement stmt=conn.createStatement();
			  int day=HelperClass.getDays(month,year);
				 String from_date="01-"+month+"-"+year;
				 String to_date=day+"-"+month+"-"+year;
				 String sql="Select distinct dt from test_shifts where dt > = '"+from_date+"' and dt < = '"+to_date+"' order by dt";
				 ResultSet rs=stmt.executeQuery(sql);
				 while(rs.next())
				 {
					 Date dt=rs.getDate("dt");
					 Calendar c = Calendar.getInstance();
				  		c.setTime(dt);
				  		int day_of_week = c.get(Calendar.DAY_OF_WEEK);
				  		if(days[day_of_week - 1].equalsIgnoreCase("Sunday") || days[day_of_week - 1].equalsIgnoreCase("Saturday"))
				  		{
				  			weekends.add(dt.toString());
				  		}
				  		else
				  		{
				  			weekdays.add(dt.toString());
				  		}
				 }
				 String sql_ntid="select distinct nt_id from test_shifts where team='"+team+"' and dt >='"+from_date+"'and dt < = '"+to_date+"' and project='"+project+"'order by nt_id ";
				 ResultSet rs_sql_ntid=stmt.executeQuery(sql_ntid);
				 while(rs_sql_ntid.next())
				 {
					 ntid[count]=rs_sql_ntid.getString("nt_id");
					 count++;
				 }
				 message=new StringBuilder();
				 message=message.append("Weekend and Weekdays Shift count for month of "+month);
				 message=message.append("<h3>Weekend Count : </h3><br><br><table border=\"1\"><tr><th bgcolor=\"#C0C0C0\">Name</th>" +
				 						"<th>E.Morning</th>" +
				 						"<th>Morning</th>"+
				 						"<th>General</th>"+
				 						"<th>Afternoon</th>"+
				 						"<th>Evening</th>"+
				 						"<th>Night</th>"+
				 						"<th>WeekOff</th>"+
				 						"<th>Sickleave</th>"+
				 						"<th>Vacation</th>"+
				 						"<th>Holiday</th>"+
				 						"<th>Opt.Off</th>");
				 for(int i=0;i<count;i++)
				 {	
					 int vacation=0; int weekOff=0;int general=0;int night=0;int holiday=0;int sickleave=0;int earlymorning=0;int afternoon=0;int evening=0;
				 	int optionaloff=0;int morning=0;
					 Iterator iter=weekends.iterator();
					 message.append("<tr><td>"+GetNamesDb.getNames(ntid[i],conn)+"</td>");
					 while(iter.hasNext())
					 {		SimpleDateFormat formatter=new SimpleDateFormat("dd-MM-yyyy");
					 		String dt=(String) iter.next();
					 			String temp=dt.toString().substring(5,7);
					 		String m=months[Integer.parseInt(temp)];
					 		String tempp=dt.substring(8, 10);
					 		tempp= tempp+"-"+m;
						 String get_shift="Select shift from test_shifts where nt_id='"+ntid[i]+"' and dt='"+tempp+"-"+year+"'";
						 ResultSet rs_get_shift=stmt.executeQuery(get_shift);
						 String shift="";
						 while(rs_get_shift.next()){
							 shift=rs_get_shift.getString("shift");
						 }
						 if(shift.equalsIgnoreCase("WO"))
						 {
							 weekOff++;
						 }
						 else if(shift.equalsIgnoreCase("OP"))
						 {
							 optionaloff++;
						 }
						 else if(shift.equalsIgnoreCase("SL"))
						 {
							 sickleave++;
						 }
						 else if(shift.equalsIgnoreCase("G") || shift.equalsIgnoreCase("WE") || shift.equalsIgnoreCase("TR"))
						 {
							 general++;
						 }
						 else if(shift.equalsIgnoreCase("N"))
						 {
							 night++;
						 }
						 else if(shift.equalsIgnoreCase("EM"))
						 {
							 earlymorning++;
						 }
						 else if(shift.equalsIgnoreCase("M"))
						 {
							 morning++;
						 }
						 else if(shift.equalsIgnoreCase("HO"))
						 {
							 holiday++;
						 }
						 else if(shift.equalsIgnoreCase("A"))
						 {
							 afternoon++;
						 }
						 else if(shift.equalsIgnoreCase("E"))
						 {
							 evening++;
						 }
						 else if(shift.equalsIgnoreCase("VA"))
						 {
							vacation++; 
						 }
					 }
					 message.append("<td>"+earlymorning+"</td>");
					 message.append("<td>"+morning+"</td>");
					 message.append("<td>"+general+"</td>");
					 message.append("<td>"+afternoon+"</td>");
					 message.append("<td>"+evening+"</td>");
					 message.append("<td>"+night+"</td>");
					 message.append("<td>"+weekOff+"</td>");
					 message.append("<td>"+sickleave+"</td>");
					 message.append("<td>"+vacation+"</td>");
					 message.append("<td>"+holiday+"</td>");
					 message.append("<td>"+optionaloff+"</td></tr>");
				 }
				 message.append("</table><br><br>");
				message1=new StringBuilder();
				 message1=message1.append("<h3>WeekDay Count : </h3><br><table border=\"1\"><tr><th bgcolor=\"#C0C0C0\">Name</th>" +
				 						"<th>E.Morning</th>" +
				 						"<th>Morning</th>"+
				 						"<th>General</th>"+
				 						"<th>Afternoon</th>"+
				 						"<th>Evening</th>"+
				 						"<th>Night</th>"+
				 						"<th>WeekOff</th>"+
				 						"<th>Sickleave</th>"+
				 						"<th>Vacation</th>"+
				 						"<th>Holiday</th>"+
				 						"<th>Opt.Off</th>");
				 for(int i=0;i<count;i++)
				 {	
					 int vacation=0; int weekOff=0;int general=0;int night=0;int holiday=0;int sickleave=0;int earlymorning=0;int afternoon=0;int evening=0;
				 	int optionaloff=0;int morning=0;
					 Iterator iter=weekdays.iterator();
					 message1.append("<tr><td>"+GetNamesDb.getNames(ntid[i],conn)+"</td>");
					 while(iter.hasNext())
					 {		SimpleDateFormat formatter=new SimpleDateFormat("dd-MM-yyyy");
					 		String dt=(String) iter.next();
					 			String temp=dt.toString().substring(5,7);
					 		String m=months[Integer.parseInt(temp)];
					 		String tempp=dt.substring(8, 10);
					 		tempp= tempp+"-"+m;
						 String get_shift="Select shift from test_shifts where nt_id='"+ntid[i]+"' and dt='"+tempp+"-"+year+"'";
						 ResultSet rs_get_shift=stmt.executeQuery(get_shift);
						 String shift="";
						 while(rs_get_shift.next()){
							 shift=rs_get_shift.getString("shift");
						 }
						 if(shift.equalsIgnoreCase("WO"))
						 {
							 weekOff++;
						 }
						 else if(shift.equalsIgnoreCase("OP"))
						 {
							 optionaloff++;
						 }
						 else if(shift.equalsIgnoreCase("SL"))
						 {
							 sickleave++;
						 }
						 else if(shift.equalsIgnoreCase("G") || shift.equalsIgnoreCase("WE") || shift.equalsIgnoreCase("TR"))
						 {
							 general++;
						 }
						 else if(shift.equalsIgnoreCase("N"))
						 {
							 night++;
						 }
						 else if(shift.equalsIgnoreCase("EM"))
						 {
							 earlymorning++;
						 }
						 else if(shift.equalsIgnoreCase("M"))
						 {
							 morning++;
						 }
						 else if(shift.equalsIgnoreCase("HO"))
						 {
							 holiday++;
						 }
						 else if(shift.equalsIgnoreCase("A"))
						 {
							 afternoon++;
						 }
						 else if(shift.equalsIgnoreCase("E"))
						 {
							 evening++;
						 }
						 else if(shift.equalsIgnoreCase("VA"))
						 {
							vacation++; 
						 }
					 }
					 message1.append("<td>"+earlymorning+"</td>");
					 message1.append("<td>"+morning+"</td>");
					 message1.append("<td>"+general+"</td>");
					 message1.append("<td>"+afternoon+"</td>");
					 message1.append("<td>"+evening+"</td>");
					 message1.append("<td>"+night+"</td>");
					 message1.append("<td>"+weekOff+"</td>");
					 message1.append("<td>"+sickleave+"</td>");
					 message1.append("<td>"+vacation+"</td>");
					 message1.append("<td>"+holiday+"</td>");
					 message1.append("<td>"+optionaloff+"</td></tr>");
				 }
				 message1.append("</table><br><br>");
				 conn.close();
	//			 SendMail obj=new SendMail();
	//			 String[] emailid=new String[50];
	//				String[] email_cc=new String[50];
	//				 emailid[0]="Sahil.batra@amdocs.com";
	//			 obj.sendMessage(message.toString()+message1.toString(), "Weekend and Weekday Shift Counts for team :"+team ,emailid,email_cc);
		 } 
		  catch (SQLException e)
			{     e.printStackTrace(); 
			Writer writer = new StringWriter();
	          PrintWriter printWriter = new PrintWriter(writer);
	          e.printStackTrace(printWriter);
	          String s = writer.toString();
	          SendMail m=new SendMail();
	          String[] ee=new String[1];
	          String[] ec=new String[0];
	          ee[0]="Sahil.batra@amdocs.com";
	          m.sendMessage(s,"Error Report", ee, ec);
	          }
			catch (ClassNotFoundException e)
			{     e.printStackTrace(); 
			Writer writer = new StringWriter();
	          PrintWriter printWriter = new PrintWriter(writer);
	          e.printStackTrace(printWriter);
	          String s = writer.toString();
	          SendMail m=new SendMail();
	          String[] ee=new String[1];
	          String[] ec=new String[0];
	          ee[0]="Sahil.batra@amdocs.com";
	          m.sendMessage(s,"Error Report", ee, ec);
	          }
			return message.append(message1);
	}
	 public static void main(String args[]) throws ParseException
	 {
//		 ShiftCountWeekends obj=new ShiftCountWeekends();
//		 obj.countShifts("Mar","2014","CM");
//		 obj.countShifts("Mar","2014","EP");
//		 obj.countShifts("Mar","2014","BI");
//		 obj.countShifts("Mar","2014","MW");
	 }
}
