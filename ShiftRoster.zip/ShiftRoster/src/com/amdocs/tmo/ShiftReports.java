package com.amdocs.tmo;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.io.Writer;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CreationHelper;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.amdocs.tmo.model.SendMail;

public class ShiftReports {
	public void importShift(String month,String year,String project)
	{int rowcount=1;
		try {
		File f=new File("C:\\tomcat\\ShiftImportReport.xlsx");	
		  if(f.exists())
		  {
			  f.delete();
			  f.createNewFile();
		  }
		  else
		  {
			  f.createNewFile(); 
		  }
		String[] nt_id=new String[100];
		XSSFWorkbook workbook = new XSSFWorkbook();
		XSSFSheet sheet = workbook.createSheet(month+"-"+year);
		XSSFCellStyle style=workbook.createCellStyle();
		XSSFCellStyle stylecolor=workbook.createCellStyle();
		CreationHelper createHelper = workbook.getCreationHelper();
		String[] months = {"","Jan", "Feb","Mar", "Apr", "May", "Jun", "Jul","Aug", "Sep", "Oct", "Nov","Dec"};
		  Class.forName("oracle.jdbc.driver.OracleDriver");
		Class.forName("oracle.jdbc.driver.OracleDriver");
		  Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@sorabhh01v:1521/xe","system", "amdocs");
		  Row row0=sheet.createRow(0);
		  Cell cell0=row0.createCell(0);
		  cell0.setCellValue("Emp. ID");
		  Cell cell1=row0.createCell(1);
		  cell1.setCellValue("Employee Name\n(First & Last)");
		  Cell cell2=row0.createCell(2);
		  cell2.setCellValue("Month\n(YYYY/MM)");
		  Cell cell3=row0.createCell(3);
		  cell3.setCellValue("Stream");
		  Cell cell4=row0.createCell(4);
		  cell4.setCellValue("Shift start Time\n*(anytime in between the given ranges given below)");
		  Cell cell5=row0.createCell(5);
		  cell5.setCellValue("No. of Days worked in Shift during the month ");
		  Cell cell6=row0.createCell(6);
		  cell6.setCellValue("Shift Allowance per Day");
		  Cell cell7=row0.createCell(7);
		  cell7.setCellValue("Total Shift Allowance to be paid in the month");
		  Cell cell8=row0.createCell(8);
		  cell8.setCellValue("Project Name ");
		  Cell cell9=row0.createCell(9);
		  cell9.setCellValue("Unit/ Division");
		  Cell cell10=row0.createCell(10);
		  cell10.setCellValue("Name of the 1st Supervisor ");
		  Cell cell11=row0.createCell(11);
		  cell11.setCellValue("Name of the 2nd Supervisor");
		  Cell cell12=row0.createCell(12);
		  cell12.setCellValue("Shift is pre approved by the Director as per eligibility criteria");
		  Cell cell13=row0.createCell(13);
		  cell13.setCellValue("Indicate reason the Employee was asked to work in Shift");
		  Statement stmt=conn.createStatement();
		  stmt = conn.createStatement();
		  String mon="";
		  String m="";
			 if(!month.equalsIgnoreCase("")){ mon=month.substring(0, 3);}
			 int day=HelperClass.getDays(mon,year);
			 String from_date="01-"+mon+"-"+year;
			 String to_date=day+"-"+mon+"-"+year;
		  String get_nt_id="select distinct nt_id from test_shifts where shift is not null and dt >='"+from_date+"'  and dt <='"+to_date+"' and project='"+project+"' order by nt_id"; 
		  ResultSet rs_get_nt_id=stmt.executeQuery(get_nt_id);
		  int ntidcount=0;
		  while(rs_get_nt_id.next())
		  {
			  nt_id[ntidcount]=rs_get_nt_id.getString("nt_id");
			  ntidcount++;  
		  }
		  for(int i=0;i<ntidcount;i++)
		  {	int morning=0;
		  	int night=0;
		  	int afternun=0;
			  String names[]=GetFullNames.getNames(nt_id[i], conn).split("%");
			  Row row=sheet.createRow(rowcount);
			  Cell cel0=row.createCell(0);
			  cel0.setCellValue(names[0]);
			  Cell cel1=row.createCell(1);
			  cel1.setCellValue(names[1]);
			  
			  for(int k=0;k<months.length;k++)
			  {
				  if(mon.equalsIgnoreCase(months[k]))
				  {	if(k<10)
				  {
					  m="0"+k; 
				  }
				  else
				  {
					  m=""+k; 
				  }
				  }
			  }
			  
			  Cell cel2=row.createCell(2);
			  cel2.setCellValue(year+"/"+m);
			  
			  Cell cel3=row.createCell(3);
			  cel3.setCellValue("All Other Streams - B1 to B3");
			  Cell cel4=row.createCell(4);
			  cel4.setCellValue("0500 - 0759 Hrs");
			  String sql="Select count(shift) from test_shifts where dt >='"+from_date+"'  and dt <='"+to_date+"' and project='"+project+"' and (shift='EM' or shift='M') and nt_id = '"+nt_id[i]+"'";
			  ResultSet rs2=stmt.executeQuery(sql);
			  Cell cel5=row.createCell(5);
			  while(rs2.next())
			  {
			  morning=rs2.getInt(1);
			  }
			  cel5.setCellValue(morning);		  
			  Cell cel6=row.createCell(6);
			  cel6.setCellValue("400");
			  Cell cel7=row.createCell(7);
			  cel7.setCellValue(400 * morning);
			  Cell cel8=row.createCell(8);
			  cel8.setCellValue("TMOUS Apollo");
			  Cell cel9=row.createCell(9);
			  cel9.setCellValue("sTech");
			  Cell cel10=row.createCell(10);
			  cel10.setCellValue("");
			  Cell cel11=row.createCell(11);
			  cel11.setCellValue("Sorabh Harit");
			  Cell cel12=row.createCell(12);
			  cel12.setCellValue("Yes");
			  Cell cel13=row.createCell(13);
			  cel13.setCellValue("Shift Coverage");
			  if(morning > 0)
			  {
			  rowcount++;
			  }

			  Row row1=sheet.createRow(rowcount);
			  Cell ce0=row1.createCell(0);
			  ce0.setCellValue(names[0]);
			  Cell ce1=row1.createCell(1);
			  ce1.setCellValue(names[1]);
			  
			  for(int k=0;k<months.length;k++)
			  {
				  if(month.equalsIgnoreCase(months[k]))
				  {	if(k<10)
				  {
					  m="0"+k; 
				  }
				  else
				  {
					  m=""+k; 
				  }
				  }
			  }
			  
			  Cell ce2=row1.createCell(2);
			  ce2.setCellValue(year+"/"+m);
			  
			  Cell ce3=row1.createCell(3);
			  ce3.setCellValue("All Other Streams - B1 to B3");
			  Cell ce4=row1.createCell(4);
			  ce4.setCellValue("1800 - 0459 Hrs");
			  String sql3="Select count(shift) from test_shifts where dt >='"+from_date+"'  and dt <='"+to_date+"' and project='"+project+"' and shift='N' and nt_id = '"+nt_id[i]+"'";
			  ResultSet rs3=stmt.executeQuery(sql3);
			  Cell ce5=row1.createCell(5);
			  while(rs3.next())
			  {
			  night=rs3.getInt(1);
			  }
			  ce5.setCellValue(night);		  
			  Cell ce6=row1.createCell(6);
			  ce6.setCellValue("600");
			  Cell ce7=row1.createCell(7);
			  ce7.setCellValue(600 * night);
			  Cell ce8=row1.createCell(8);
			  ce8.setCellValue("TMOUS Apollo");
			  Cell ce9=row1.createCell(9);
			  ce9.setCellValue("sTech");
			  Cell ce10=row1.createCell(10);
			  ce10.setCellValue("");
			  Cell ce11=row1.createCell(11);
			  ce11.setCellValue("Sorabh Harit");
			  Cell ce12=row1.createCell(12);
			  ce12.setCellValue("Yes");
			  Cell ce13=row1.createCell(13);
			  ce13.setCellValue("Shift Coverage");
			  if(night > 0)
			  {
			  rowcount++;
			  }
			  
		  }
		  FileOutputStream out =
	            new FileOutputStream(f);
	    workbook.write(out);
	    out.close();
	} catch (FileNotFoundException e) {
	    e.printStackTrace();
	} catch (IOException e) {
	    e.printStackTrace();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (ClassNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	}
	public static void main(String args[])
	{ShiftReports obj=new ShiftReports();
	obj.importShift("August","2014","TMO-US");
	}

}
