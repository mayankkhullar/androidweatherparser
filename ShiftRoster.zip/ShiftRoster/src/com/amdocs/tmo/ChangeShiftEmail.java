package com.amdocs.tmo;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.io.Writer;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import com.amdocs.tmo.model.SendMail;

public class ChangeShiftEmail {
	public void changeShift(String id,String fromdt,String todt,String shift,String team,String name,String ateam,String project,String notify)
	{
		String[] emailid=new String[100]; 
		String[] email_cc=new String[100]; 
		String[] test_emailid=new String[100]; 
		String[] test_email_cc=new String[100]; 
		test_emailid[0]="sahil.batra@amdocs.com";
		int day_of_week=0,day_of_week1=0;
		 String[] days={"","Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"};
		  try { 
			  String email_to="";
			  Class.forName("oracle.jdbc.driver.OracleDriver");
			  Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@sorabhh01v:1521/xe","system", "amdocs");
			  Statement stmt=conn.createStatement();
			  stmt = conn.createStatement();
			  String userTeam="";
			  if(id.equalsIgnoreCase("All Team"))
			  {
				  userTeam=team;
			  }
			  else
			  {userTeam=GetNamesDb.getTeam(id, conn,project);
			  }
			  if(notify.equalsIgnoreCase("notifytoteam") || id.equalsIgnoreCase("All Team"))
			  {
				  email_to = "select distinct email_id from test_employee_details where (team='"+userTeam.toUpperCase()+"' or ateam='"+userTeam.toUpperCase()+"') and project='"+project+"'";
			  }
			  else
			  {
			   email_to = "select distinct email_id from test_manager where (team='"+userTeam.toUpperCase()+"' or ateam='"+userTeam.toUpperCase()+"') and project='"+project+"'";
			  }  
			  ResultSet rs= stmt.executeQuery(email_to);
			     int i=0;
			     while(rs.next())
			      {
			      	email_cc[i]=rs.getString("email_id");
			      	i++;
			      }
				      SimpleDateFormat formatter = new SimpleDateFormat("dd-MMM-yyyy");
				      Date da,daa;
					try {
						da = formatter.parse(fromdt);
						 Calendar c = Calendar.getInstance();
						  	c.setTime(da);
						   day_of_week = c.get(Calendar.DAY_OF_WEEK);
						   daa = formatter.parse(todt);
							 Calendar c1 = Calendar.getInstance();
							  	c1.setTime(daa);
							   day_of_week1 = c1.get(Calendar.DAY_OF_WEEK);
					} catch (ParseException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					if(id.equalsIgnoreCase("All Team"))
					{
						emailid=email_cc;
						email_cc=test_email_cc;
					}
					else
					{
					emailid[0]=GetUserEmail.getemail(id,conn);
					}
				      SendMail mail=new SendMail();
				      String temp=HelperClass.getDisplayName(shift,project,conn);
				      mail.sendMessage("<Html><body>Hi&nbsp;"+GetNamesDb.getNames(id,conn)+"<br><br>Your Shift has been changed by &nbsp"+HelperClass.changeCase(name)+"<br><br>Changed Shift :<br><br><table border=\"1\"><tr><th>From Date</th><th>To Date</th><th>From Day</th><th>To Day</th><th> Shift</th></tr><tr><td>"+fromdt+"</td><td>"+todt+"</td><td>"+days[day_of_week]+"</td><td>"+days[day_of_week1]+"</td><td>"+HelperClass.getDisplayName(shift,project,conn)+"</td></tr></table>"+"<br><br>Thank You<br><br><br><br><br>This is auto generated message . Please do not reply.", "Shift Change Notification",emailid,email_cc);
				      conn.close();
				      }
		  catch (SQLException e)
			{     e.printStackTrace(); 
	          }
			catch (ClassNotFoundException e)
			{     e.printStackTrace(); }
		
	}
}
