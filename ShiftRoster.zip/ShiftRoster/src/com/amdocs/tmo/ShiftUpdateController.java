/**
 * 
 */
package com.amdocs.tmo;


import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.io.Writer;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.amdocs.tmo.model.SendMail;


/**
 * @author SAHILBA
 *
 */
@Controller
public class ShiftUpdateController {
	@RequestMapping(value = "/updateshift", method = RequestMethod.POST)
	public String updateShift(@RequestParam("userid") String userid,
								@RequestParam("id") String id,
								@RequestParam("from") String from_date,
								@RequestParam("to") String to_date,
								@RequestParam("project") String project,Model model) {
		 String[] days={"Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"};
		 StringBuilder message=new StringBuilder();
		 boolean isError=false;
		 DateFormat dateFormat = new SimpleDateFormat("MMMM dd yyyy");
		 java.util.Date date = new java.util.Date();
		  int count=0;
		  try { 
			  if(!isError){
			  String[] shifts=new String[50];
			  String[] in_time=new String[50];
			  String[] out_time=new String[50];
			  int i=0;
			  Class.forName("oracle.jdbc.driver.OracleDriver");
			  Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@sorabhh01v:1521/xe","system", "amdocs");
			  Statement stmt=conn.createStatement();
			  stmt = conn.createStatement();
			  String get_time =" select * from test_shift_details where project='"+project+"' order by shift_id";
			  ResultSet get_time_rs=stmt.executeQuery(get_time);
			  while(get_time_rs.next())
			  {shifts[i]=get_time_rs.getString("DISPLAY_VALUE");
			  	in_time[i]=get_time_rs.getString("IN_TIME");
			  	out_time[i]=get_time_rs.getString("OUT_TIME");
			  	i++;
			  }
			//  String mon=month.substring(0, 3);
			//  int day=HelperClass.getDays(mon,year);
			//  String from_date="01-"+mon+"-"+year;
			//  String to_date=day+"-"+mon+"-"+year;
			  
			  String shift="Select display_value,display_name from test_shift_details where project='"+project+"'";
			  ResultSet rs1=stmt.executeQuery(shift);
			  StringBuilder tempmessage=new StringBuilder();
			  while(rs1.next())
			  {
				  tempmessage=tempmessage.append("<option value="+"\""+rs1.getString("display_value")+"\">"+rs1.getString("display_name")+"</options>");
			  }
			  String sql="Select dt,shift from test_shifts where nt_id='"+userid+"' and dt > = '"+from_date+"' and dt < = '"+to_date+"'  and project='"+project+"' order by dt asc";
			  ResultSet rs=stmt.executeQuery(sql);
			  message=message.append("<table border=\"1\" align=\"center\"><tr><th bgcolor=\"green\">Date</th><th bgcolor=\"green\">Day</th bgcolor=\"green\"><th bgcolor=\"green\">Shift</th><th bgcolor=\"green\">In Time</th><th bgcolor=\"green\">Out Time</th></tr>") ;
			  while(rs.next())
			  {		String tmp="id"+count;
			  		String tmp2="row"+count;
				  Calendar c = Calendar.getInstance();
				  c.setTime(rs.getDate("dt"));
				  int day_of_week = c.get(Calendar.DAY_OF_WEEK);
				  String temp=rs.getString("shift");
				 message=message.append("<tr><th bgcolor="+HelperClass.getColor(temp, project, conn)+">"+rs.getDate("dt")+"</th><th bgcolor="+HelperClass.getColor(temp, project, conn)+">"+days[day_of_week - 1]+"</th><th bgcolor="+HelperClass.getColor(temp, project, conn)+">");
				 message=message.append("<Select name="+"\""+tmp+"\">"+tempmessage.toString()+"</select><input type=\"hidden\" name="+"\""+tmp2+"\" value="+"\""+temp+"\"></th><th bgcolor="+HelperClass.getColor(temp, project, conn)+">"+HelperClass.getInTime(rs.getString("shift"), project, conn)+"</th><th bgcolor="+HelperClass.getColor(temp, project, conn)+">"+HelperClass.getOutTime(rs.getString("shift"), project, conn)+"</th></tr>");
				 count++;
			  }
			  count=count-1;
			  message=message.append("</table>");
			  conn.close();}
			  
		  }
		  catch (SQLException e)
			{     e.printStackTrace(); }
			catch (ClassNotFoundException e)
			{     e.printStackTrace(); }
			model.addAttribute("date",date.toString());
			model.addAttribute("userid",userid);
			model.addAttribute("id",id);
			model.addAttribute("total",count);
			model.addAttribute("project",project);
			model.addAttribute("from_date",from_date);
			model.addAttribute("to_date",to_date);
			model.addAttribute("project",project);
			model.addAttribute("message",message.toString());		
		return "test";

}
	
	@RequestMapping(value = "/updateshiftconfirm", method = RequestMethod.POST)
	public String updateShiftConfirm(@RequestParam("id") String id,
							@RequestParam("userid") String userid,
						 @RequestParam("from_date") String from_date,
						 @RequestParam("to_date") String to_date,
						 @RequestParam("newshift") String newshift,
						 @RequestParam("project") String project,
						 @RequestParam("total") String total,Model model) {
		String[] new_shift=new String[Integer.parseInt(total)];
		new_shift=newshift.split(" ");
		StringBuilder message=new StringBuilder();
		String[] emailid=new String[100]; 
		String[] email_cc=new String[100]; 
		String[] test_emailid=new String[100]; 
		String[] test_email_cc=new String[100]; 
		test_emailid[0]="sahil.batra@amdocs.com";
		 String userTeam="";
		 boolean sendmessage=false;
		  try { 
			  String dates[]=new String[32];
			  int first=Integer.parseInt(from_date.substring(0,2));
			  String month_year=from_date.substring(2);
			  int last=Integer.parseInt(to_date.substring(0,2));
			  for(int j=first;j<=last;j++)
			  {		if(j <=9)
				  		{dates[j]="0"+j+month_year;}
			  		else
			  		{
			  			dates[j]=j+month_year;
			  		}
			  }
			  String[] old_shifts=new String[32];
			  int i=1;
			  Class.forName("oracle.jdbc.driver.OracleDriver");
			  Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@sorabhh01v:1521/xe","system", "amdocs");
			  Statement stmt=conn.createStatement();
			  message.append("<HTML>Hi&nbsp;"+GetNamesDb.getNames(userid,conn)+"<br><br>");
			  message=message.append("Your Shift had been changed by&nbsp;"+GetNamesDb.getNames(id, conn));
			  String sql="Select dt,shift from test_shifts where nt_id='"+userid+"' and dt > = '"+from_date+"' and dt < = '"+to_date+"'  and project='"+project+"' order by dt asc";
			  ResultSet rs=stmt.executeQuery(sql);
			  while(rs.next())
			  {
				  old_shifts[i]=rs.getString("shift");
				  i++;
			  }
			  userTeam=GetNamesDb.getTeam(id, conn,project);
			  String email_to = "select distinct email_id from test_manager where (team='"+userTeam.toUpperCase()+"' or ateam='"+userTeam.toUpperCase()+"') and project='"+project+"'";
			  int k=0;
			  rs= stmt.executeQuery(email_to);
			     while(rs.next())
			      {
			      	email_cc[k]=rs.getString("email_id");
			      	k++;
			      }
			   emailid[0]=GetUserEmail.getemail(userid,conn);
			  message=message.append("<br><br>Changed Shift :<br><br><table border=\"1\"><tr><th>Date</th><th>Old Shift</th><th>Changed Shift</th></tr>");
			  for(int j=1;j<new_shift.length;j++)
			  {
					String sql_update="update test_shifts set shift='"+new_shift[j]+"' where nt_id ='"+userid+"' and DT='"+dates[j]+"'";
					System.out.println(sql_update);
					if(!old_shifts[j].equals(new_shift[j]))
					{if(conn.isClosed())
						{
						conn = DriverManager.getConnection("jdbc:oracle:thin:@sorabhh01v:1521/xe","system", "amdocs");
						stmt=conn.createStatement();
						}
						message=message.append("<tr><th>"+dates[j]+"</th><th>"+HelperClass.getDisplayName(old_shifts[j], project, conn)+"</th><th>"+HelperClass.getDisplayName(new_shift[j], project, conn)+"</th></tr>");
						rs=stmt.executeQuery(sql_update);
						sendmessage=true;
					}
			  }	
			  message=message.append("</table><br><br>Thank You<br><br><br><br><br>This is auto generated message . Please do not reply.");
			  SendMail mail=new SendMail();
			  if(sendmessage)
			  mail.sendMessage(message.toString(), "Shift Change Notification",emailid,email_cc);
		  }
		  catch (SQLException e)
			{     e.printStackTrace(); }
			catch (ClassNotFoundException e)
			{     e.printStackTrace(); }
			model.addAttribute("message","Updated Successful");
		return "test2";
	}
}
