package com.amdocs.tmo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
@Controller
public class AllusershiftController {
	 DateFormat dateFormat = new SimpleDateFormat("MMMM dd yyyy");
	 java.util.Date date = new java.util.Date();
	 @RequestMapping(value = "/mytmoshift", method = RequestMethod.POST)
	  public String myTeamShiftShow(@RequestParam("name") String name,
			  				@RequestParam("team") String team,
			  				@RequestParam("ateam") String ateam,
			  				@RequestParam("id") String id,	
			  				@RequestParam("mm") String month,
			  				@RequestParam("yy") String year,
			  				@RequestParam("v1") String view,
			  				@RequestParam("project") String project,Model model) throws ParseException {
		// StringBuilder message=new StringBuilder();
		 String[] days={"Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"};
		boolean isError=false;
		String message="";
		StringBuilder mailMessage= new StringBuilder();
		 if(view.equalsIgnoreCase("monthly"))
		 {
			 MonthlyReport mm=new MonthlyReport();
			 mailMessage.append(mm.generateMonthlyShiftsManager(id,month,year,"ALL",project));
		 }
		 else
		 {
			if(!isError)
			{
				WeeklyReport obj=new WeeklyReport();
			 	mailMessage.append(obj.generateMonthlyShifts(month,year,"ALL",01,07,project));
				mailMessage.append(obj.generateMonthlyShifts(month,year,"ALL",8,14,project));
				mailMessage.append(obj.generateMonthlyShifts(month,year,"ALL",15,21,project));
				mailMessage.append(obj.generateMonthlyShifts(month,year,"ALL",22,28,project));
				mailMessage.append(obj.generateMonthlyShifts(month,year,"ALL",29,0,project));
			   }
		 }
			model.addAttribute("team",team);
			model.addAttribute("ateam",ateam);
			model.addAttribute("name",name); 	
			model.addAttribute("date",date.toString());
			model.addAttribute("id",id);
			model.addAttribute("project",project);
			if(!isError)
			{
			model.addAttribute("month",month);
			model.addAttribute("year",year);
			model.addAttribute("message",mailMessage.toString());
		 return "mytmoshift";
			}
			else
			{
				model.addAttribute("message","<H1>Please select month and year</H1>");
				 return "mytmoshift";
			}
} 
	
}
