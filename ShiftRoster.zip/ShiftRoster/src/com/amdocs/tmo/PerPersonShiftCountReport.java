package com.amdocs.tmo;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.io.Writer;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.util.Calendar;

import com.amdocs.tmo.model.SendMail;

public class PerPersonShiftCountReport {
	StringBuilder perPersonReports(String team,String month,String year,String project)
	{
		String[] months = {"Jan", "Feb","Mar", "Apr", "May", "Jun", "Jul","Aug", "Sep", "Oct", "Nov","Dec"};
		String[] nt_id=new String[100];
		String[] shift=new String[25];
		int count=0;
		int shift_count=0;
		String[] emailid=new String[50];
		emailid[0]="sahil.batra@amdocs.com";
		String[] email_cc=new String[50];
		StringBuilder message=new StringBuilder();
		Calendar cal = Calendar.getInstance();
	//	String month = months[cal.get(Calendar.MONTH)];
	//	int year=cal.get(Calendar.YEAR );
		int day=HelperClass.getDays(month,year+"");
		 String from_date="01-"+month+"-"+year;
		 String to_date=day+"-"+month+"-"+year;
		 try { 
			  Class.forName("oracle.jdbc.driver.OracleDriver");
			  Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@sorabhh01v:1521/xe","system", "amdocs");
			  Statement stmt=conn.createStatement();
			  stmt = conn.createStatement();
			  String sql="Select distinct nt_id from test_shifts where team='"+team+"' and project='"+project+"'";
			  ResultSet rs=stmt.executeQuery(sql);
			  while(rs.next())
			  {nt_id[count]=rs.getString("nt_id");
			  	count++;
			  }
			  message.append("<html><body>Hi Leads,<br>Please find number of shifts per person for "+month+" month<br><br><br><table border=\"1\"><tr><th>Name</th>");
			  String sql_shifts="Select distinct shift from test_shifts where project='"+project+"' order by shift";
			  ResultSet rs_sql_shifts=stmt.executeQuery(sql_shifts);
			  while(rs_sql_shifts.next())
			  {		shift[shift_count]=rs_sql_shifts.getString("shift");
				  message.append("<th>"+HelperClass.getDisplayName(shift[shift_count],project, conn)+"</th>");
				  shift_count++;
			  }
			  message.append("</tr>");
			  for(int i=0;i<count;i++)
			  { message.append("<tr><td>"+GetNamesDb.getNames(nt_id[i],conn)+"</td>");
				  for(int j=0;j<shift_count;j++)
				  {
					  String sql_shift_count="Select Count(*) from test_shifts where shift='"+shift[j]+"' and nt_id='"+nt_id[i]+"' and dt>='"+from_date+"' and dt<='"+to_date+"'";
					  ResultSet rs_sql_shift_count=stmt.executeQuery(sql_shift_count);
					  while(rs_sql_shift_count.next())
					  {
						  message.append("<td>"+rs_sql_shift_count.getInt(1)+""+"</td>");
					  }
				  }
				  message.append("</tr>");
			  }
			  message.append("</table>");
			  conn.close();
			  
//			  SendMail obj=new SendMail();
//			  obj.sendMessage(message.toString(),"Team Wise Shift Count for Team : "+team, emailid, email_cc);
		  } 
		  
		  catch (SQLException e)
			{     e.printStackTrace(); 
	          }
		  catch (ClassNotFoundException e)
			{     e.printStackTrace(); 
	          }
		  return message;
	}
		 public static void main(String args[]) throws ParseException
		 {	String[] emailid=new String[50];
			String[] email_cc=new String[50];
			 PerPersonShiftCountReport obj=new PerPersonShiftCountReport();
		//	 obj.perPersonReports("MW");
		//	 obj.perPersonReports("CM");
		//	 obj.perPersonReports("EP");
		//	 obj.perPersonReports("BI");
	//		 RequestReport obj1=new RequestReport();
	//		 obj1.requestReports("MW");
	//		 obj1.requestReports("CM");
	//		 obj1.requestReports("EP");
	//		 obj1.requestReports("BI");
	//		 emailid[0]="Sahil.batra@amdocs.com";
	//		 SendMail mail=new SendMail();
	//		 MonthlyReport obj2=new MonthlyReport();
	//		String message= obj2.generateMonthlyShifts("March","2014","MW");
	//		mail.sendMessage(message, "Monthly Shift Report of Month for MW", emailid, email_cc);
	//		String message1= obj2.generateMonthlyShifts("March","2014","CM");
	//		mail.sendMessage(message1, "Monthly Shift Report of Month for CM", emailid, email_cc);
	//		String message2= obj2.generateMonthlyShifts("March","2014","EP");
	//		mail.sendMessage(message2, "Monthly Shift Report of Month for EP", emailid, email_cc);
	//		String message3= obj2.generateMonthlyShifts("March","2014","BI");
	//		mail.sendMessage(message3, "Monthly Shift Report of Month for BI", emailid, email_cc);
	//		String message4= obj2.generateMonthlyShifts("March","2014","ALL");
	//		mail.sendMessage(message4, "Monthly Shift Report of Month for TMO- OFFSHORE", emailid, email_cc);
			 
		 }

}
