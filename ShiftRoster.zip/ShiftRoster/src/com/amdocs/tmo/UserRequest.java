package com.amdocs.tmo;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.io.Writer;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import com.amdocs.tmo.model.SendMail;

public class UserRequest {

	public void changeShift(String id,String name,String fromdt,String todt,String shift,String reason,String team,String project)
	{	String[] emailid=new String[100]; 
		String[] email_cc=new String[100]; 
		String[] test_emailid=new String[100]; 
		String[] test_email_cc=new String[100]; 
		test_emailid[0]="sahil.batra@amdocs.com";
		int day_of_week=0,day_of_week1=0;
		 String[] days={"","Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"};
		  try { 
			  Class.forName("oracle.jdbc.driver.OracleDriver");
			  Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@sorabhh01v:1521/xe","system", "amdocs");
			  Statement stmt=conn.createStatement();
			  stmt = conn.createStatement();
			  String email_to = "select distinct email_id from test_manager where ( team='"+team.toUpperCase()+"' or ateam='"+team.toUpperCase()+"') and project='"+project+"'";
			     ResultSet rs= stmt.executeQuery(email_to);
			     int i=0;
			      while(rs.next())
			      {
			      	emailid[i]=rs.getString("email_id");
			      	i++;
			      }
				      SimpleDateFormat formatter = new SimpleDateFormat("dd-MMM-yyyy");
				      Date da,daa;
					try {
						da = formatter.parse(fromdt);
						 Calendar c = Calendar.getInstance();
						  	c.setTime(da);
						   day_of_week = c.get(Calendar.DAY_OF_WEEK);
						   daa = formatter.parse(todt);
							 Calendar c1 = Calendar.getInstance();
							  	c1.setTime(daa);
							   day_of_week1 = c1.get(Calendar.DAY_OF_WEEK);
					} catch (ParseException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					email_cc[0]=GetUserEmail.getemail(id,conn);
					String temp=HelperClass.getDisplayName(shift, project, conn);
				      SendMail mail=new SendMail();
				      if(todt.equalsIgnoreCase(""))
				      {
				    	  mail.sendMessage("<Html><body>Hi&nbsp;Leads,<br><br>"+HelperClass.changeCase(name)+"&nbsp;has requested for the shift change.<br><br>Requested Shift :<br><br><table border=\"1\"><tr><th>NT ID </th><th>From Date</th><th>To Date</th><th>From Day</th><th>To Day</th><th>Requested Shift</th><th>Reason</th></tr><tr><td>"+id+"</td><td>"+fromdt+"</td><td>"+fromdt+"</td><td>"+days[day_of_week]+"</td><td>"+days[day_of_week]+"</td><td>"+temp+"</td><td>"+reason+"</td></tr></table>"+"<br><br>Thank You<br><br><br><br><br>This is auto generated message . Pelase do not reply.", "Shift Change Request",emailid,email_cc);
				      }
				      else
				      {
				      mail.sendMessage("<Html><body>Hi&nbsp;Leads,<br><br>"+HelperClass.changeCase(name)+"&nbsp;has requested for the shift change.<br><br>Requested Shift :<br><br><table border=\"1\"><tr><th>NT ID </th><th>From Date</th><th>To Date</th><th>From Day</th><th>To Day</th><th>Requested Shift</th><th>Reason</th></tr><tr><td>"+id+"</td><td>"+fromdt+"</td><td>"+todt+"</td><td>"+days[day_of_week]+"</td><td>"+days[day_of_week1]+"</td><td>"+temp+"</td><td>"+reason+"</td></tr></table>"+"<br><br>Thank You<br><br><br><br><br>This is auto generated message . Pelase do not reply.", "Shift Change Request",emailid,email_cc);
				      }
				      conn.close(); }
		  catch (SQLException e)
			{     e.printStackTrace(); 
	        }
			catch (ClassNotFoundException e)
			{     e.printStackTrace(); 
	        }
			
	}
}
