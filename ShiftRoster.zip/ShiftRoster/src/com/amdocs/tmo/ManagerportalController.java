package com.amdocs.tmo;
import org.springframework.stereotype.Controller;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.io.Writer;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.StringTokenizer;

import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.amdocs.tmo.model.SendMail;

@Controller

public class ManagerportalController {
		@ModelAttribute("uploadItem")
	 @RequestMapping(value = "/shiftupload", method = RequestMethod.POST)
	  public String myShift(@RequestParam("name") String name,
			  				@RequestParam("team") String team,
			  				@RequestParam("id") String id,
			  				@RequestParam("ateam") String ateam,
			  				@RequestParam("project") String project,Model model) {
		 DateFormat dateFormat = new SimpleDateFormat("MMMM dd yyyy");
		  java.util.Date date = new java.util.Date();
		  StringBuilder message=new StringBuilder();
		  try { 
			  Class.forName("oracle.jdbc.driver.OracleDriver");
			  Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@sorabhh01v:1521/xe","system", "amdocs");
			  Statement stmt=conn.createStatement();
			  stmt = conn.createStatement();
			  String get_time =" select * from test_shift_details where project='"+project+"' order by shift_id ";
			  ResultSet get_time_rs=stmt.executeQuery(get_time);
			  message.append("<table border=\"1\"><tr><th>Shift Code</th><th>Shift</th><th>In Time</th><th>Out Time</th></tr>");
			  while(get_time_rs.next())
			  {	message.append("<tr><td>"+get_time_rs.getString("DISPLAY_VALUE")+"</td><td>"+HelperClass.getDisplayName(get_time_rs.getString("DISPLAY_VALUE"), project, conn)+"</td><td>"+get_time_rs.getString("IN_TIME")+"</td><td>"+get_time_rs.getString("OUT_TIME")+"</td></tr>");
			  }
			  message=message.append("</table>");
			  conn.close();
		  }
		  catch (SQLException e)
			{     e.printStackTrace(); }
			catch (ClassNotFoundException e)
			{     e.printStackTrace(); }
		  model.addAttribute("team",team);
		  model.addAttribute("ateam",ateam);
 			model.addAttribute("name",name); 
 			model.addAttribute("date",date.toString());
 			model.addAttribute("id",id);
 			model.addAttribute("project",project);
 			model.addAttribute("message",message);
		 return "shiftupload";
}
		 @RequestMapping(value = "/adduser", method = RequestMethod.POST)
		  public String myShiftAdduser(@RequestParam("name") String name,
				  				@RequestParam("team") String team,
				  				@RequestParam("id") String id,
				  				@RequestParam("ateam") String ateam,
				  				@RequestParam("project") String project,Model model) {
			 DateFormat dateFormat = new SimpleDateFormat("MMMM dd yyyy");
			  java.util.Date date = new java.util.Date();
			  model.addAttribute("team",team);
			  model.addAttribute("ateam",ateam);
	 			model.addAttribute("name",name); 
	 			model.addAttribute("date",date.toString());
	 			model.addAttribute("id",id);
	 			model.addAttribute("project",project);
			 return "adduser";
	}
		 @RequestMapping(value = "/deleteuser", method = RequestMethod.POST)
		  public String myUserDelete(@RequestParam("name") String name,
				  				@RequestParam("team") String team,
				  				@RequestParam("id") String id,
				  				@RequestParam("ateam") String ateam,
				  				@RequestParam("project") String project,Model model) {
			 DateFormat dateFormat = new SimpleDateFormat("MMMM dd yyyy");
			  java.util.Date date = new java.util.Date();
			  model.addAttribute("team",team);
			  model.addAttribute("ateam",ateam);
	 			model.addAttribute("name",name); 
	 			model.addAttribute("date",date.toString());
	 			model.addAttribute("id",id);
	 			model.addAttribute("project",project);
			 return "deleteuser";
	}
		 @RequestMapping(value = "/allusershift", method = RequestMethod.POST)
		  public String myShiftAll(@RequestParam("name") String name,
				  				@RequestParam("team") String team,
				  				@RequestParam("id") String id,
				  				@RequestParam("ateam") String ateam,
				  				@RequestParam("project") String project,Model model) {
			 DateFormat dateFormat = new SimpleDateFormat("MMMM dd yyyy");
			  java.util.Date date = new java.util.Date();
			  model.addAttribute("team",team);
	 			model.addAttribute("name",name); 
	 			model.addAttribute("date",date.toString());
	 			model.addAttribute("id",id);
	 			 model.addAttribute("ateam",ateam);
	 			model.addAttribute("project",project);
			 return "allusershift";
	}
		 @RequestMapping(value = "/delegate", method = RequestMethod.POST)
		  public String delegate(@RequestParam("name") String name,
				  				@RequestParam("team") String team,
				  				@RequestParam("id") String id,
				  				@RequestParam("ateam") String ateam,
				  				@RequestParam("project") String project,Model model) {
			 DateFormat dateFormat = new SimpleDateFormat("MMMM dd yyyy");
			  java.util.Date date = new java.util.Date();
			  StringBuilder message=new StringBuilder("");
			  try { 
				  Class.forName("oracle.jdbc.driver.OracleDriver");
				  Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@sorabhh01v:1521/xe","system", "amdocs");
				  Statement stmt=conn.createStatement();
				  stmt = conn.createStatement();
				  String sql="Select id from test_manager where  ( team='"+team+"' or team='"+ateam+"' ) and delegate='Y' and project='"+project+"'";
			  		ResultSet rs=stmt.executeQuery(sql);
			  		while(rs.next())
			  		{
		  			message.append("<br><b>Current Delagate :&nbsp;<b>"+GetNamesDb.getNames(rs.getString("id"),conn));
			  		}
			  }
			  catch (SQLException e)
				{     e.printStackTrace(); }
				catch (ClassNotFoundException e)
				{     e.printStackTrace(); }
			  model.addAttribute("team",team);
			  model.addAttribute("ateam",ateam);
	 			model.addAttribute("name",name); 
	 			model.addAttribute("date",date.toString());
	 			model.addAttribute("id",id);
	 			model.addAttribute("project",project);
	 			model.addAttribute("message",message.toString());
			 return "delegate";
	}
		 @RequestMapping(value = "/reviewrequest", method = RequestMethod.POST)
		  public String myShiftChangeReview(@RequestParam("name") String name,
				  				@RequestParam("team") String team,
				  				@RequestParam("id") String id,
				  				@RequestParam("ateam") String ateam,
				  				@RequestParam("project") String project,Model model) {
			 DateFormat dateFormat = new SimpleDateFormat("MMMM dd yyyy");
			  java.util.Date date = new java.util.Date();
			  model.addAttribute("team",team);
	 			model.addAttribute("name",name); 	
	 			model.addAttribute("date",date.toString());
	 			model.addAttribute("id",id);
	 			 model.addAttribute("ateam",ateam);
	 			 model.addAttribute("project",project);
			 return "reviewrequest";	
	}
		 @RequestMapping(value = "/changeshift", method = RequestMethod.POST)
		  public String shiftChange(@RequestParam("name") String name,
				  				@RequestParam("team") String team,
				  				@RequestParam("id") String id,
				  				@RequestParam("ateam") String ateam,
				  				@RequestParam("project") String project,Model model) {
			 DateFormat dateFormat = new SimpleDateFormat("MMMM dd yyyy");
			  java.util.Date date = new java.util.Date();
			  StringBuilder message=new StringBuilder();
			  StringBuilder dropdown=new StringBuilder();
			  try { 
				  Class.forName("oracle.jdbc.driver.OracleDriver");
				  Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@sorabhh01v:1521/xe","system", "amdocs");
				  Statement stmt=conn.createStatement();
				  stmt = conn.createStatement();
				  String get_time =" select * from test_shift_details where project='"+project+"' order by shift_id";
				  ResultSet get_time_rs=stmt.executeQuery(get_time);
				  message.append("<table border=\"1\"><tr><th>Shift Code</th><th>Shift</th><th>In Time</th><th>Out Time</th></tr>");
				  while(get_time_rs.next())
				  {	message.append("<tr><td>"+get_time_rs.getString("DISPLAY_VALUE")+"</td><td>"+HelperClass.getDisplayName(get_time_rs.getString("DISPLAY_VALUE"),project,conn)+"</td><td>"+get_time_rs.getString("IN_TIME")+"</td><td>"+get_time_rs.getString("OUT_TIME")+"</td></tr>");
				  }
				  message=message.append("</table>");
				  conn.close();
			  }
			  catch (SQLException e)
				{     e.printStackTrace(); 
		          }
				catch (ClassNotFoundException e)
				{     e.printStackTrace(); 
		          }
			  model.addAttribute("team",team);
				model.addAttribute("name",name); 
				 model.addAttribute("ateam",ateam);
				model.addAttribute("date",date.toString());
				model.addAttribute("id",id);
				model.addAttribute("message",message);
				model.addAttribute("project",project);
			 return "changeshift";	
	}
		 @RequestMapping(value = "/changeshiftconfirm", method = RequestMethod.POST)
		  public String shiftChangeConfirm(@RequestParam("name") String name,
				  				@RequestParam("team") String team,
				  				@RequestParam("id") String id,
				  				@RequestParam("dt") String fromdt,
				  				@RequestParam("todt") String todt,
				  				@RequestParam("reqshift") String shift,
				  				@RequestParam("reqid") String ntid,
				  				@RequestParam("ateam") String ateam,
				  				@RequestParam("sickleaveemail") String mail,
				  				@RequestParam("notifyteam") String teammail,
				  				@RequestParam("project") String project,
				  				Model model) {
			 boolean isError=false;
			 DateFormat dateFormat = new SimpleDateFormat("MMMM dd yyyy");
			  java.util.Date date = new java.util.Date();
			  StringBuilder message=new StringBuilder();
			  try { if(!isError){
				  Class.forName("oracle.jdbc.driver.OracleDriver");
				  Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@sorabhh01v:1521/xe","system", "amdocs");
				  Statement stmt=conn.createStatement();
				  stmt = conn.createStatement();
				  String sql="";
				  if(ntid.equalsIgnoreCase("All Team"))
				  {
					  sql="update test_shifts set shift='"+shift.toUpperCase()+"' where team='"+team.toUpperCase()+"' and dt>='"+fromdt+"' and dt<='"+todt+"' and project='"+project+"'" ;
				  }
				  else  
				  {sql="update test_shifts set shift='"+shift.toUpperCase()+"' where nt_id='"+ntid.toUpperCase()+"' and dt>='"+fromdt+"' and dt<='"+todt+"'";}
				  stmt.executeUpdate(sql);
				  ChangeShiftEmail email=new ChangeShiftEmail();
				  email.changeShift(ntid,fromdt,todt,shift,team,name,ateam,project,teammail);
				  if(project.equalsIgnoreCase("ATT-JEWEL")){
				  ChangeShiftSMS sms=new ChangeShiftSMS();
				  sms.changeShiftSMS(ntid,fromdt,todt,shift,team,name,ateam,project);
				  }
				  if(shift.equalsIgnoreCase("SL") && mail.equalsIgnoreCase("email"))
				  {		String[] ee=new String[1];
				  	String sql_2="Select distinct projectdl from projects where project='"+project+"'";
				  	ResultSet rs2=stmt.executeQuery(sql_2);
				  	while(rs2.next())
				  	{
				  		ee[0]=rs2.getString("projectdl");
				  	}
				  		String[] ec=new String[0];
					  SendMail obj=new SendMail();
					  obj.sendMessage("<html><body><br><br><br><br><br><br>This is Auto generated mail. Please do not reply to this email.",GetNamesDb.getNames(ntid,conn)+" is OOO due to bad health <EOM>", ee, ec);
				  }
				  conn.close();
			  }
			 
			 }
			  catch (SQLException e)
				{     e.printStackTrace(); 
		          }
				catch (ClassNotFoundException e)
				{     e.printStackTrace(); 
		          }
			  model.addAttribute("team",team);
				model.addAttribute("name",name); 
				 model.addAttribute("ateam",ateam);
				model.addAttribute("date",date.toString());
				model.addAttribute("id",id);
				model.addAttribute("project",project);
				if(!isError){
				model.addAttribute("message","<H1>Shift Updated Successfully</H1>");
			 return "changeshiftconfirm";
				}
				else
				{
					model.addAttribute("message","<H1>Please Enter the Required details</H1>");
					 return "changeshiftconfirm";
				}
	}
		 @RequestMapping(value = "/showreviewrequest", method = RequestMethod.POST)
		  public String showShiftChangeReview(@RequestParam("name") String name,
				  				@RequestParam("team") String team,
				  				@RequestParam("id") String id,
				  				@RequestParam("mm") String month,
				  				@RequestParam("yy") String year,
				  				@RequestParam("ateam") String ateam,
				  				@RequestParam("project") String project,
				  				Model model) {
			 StringBuilder message = new StringBuilder();
			 DateFormat dateFormat = new SimpleDateFormat("MM dd yyyy");
			  java.util.Date date = new java.util.Date();
			  String[] days={"","Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"};
			  String[] status={"Pending","Approved","Rejected"};
			  int i=0;
			  try { 
				  Class.forName("oracle.jdbc.driver.OracleDriver");
				  Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@sorabhh01v:1521/xe","system", "amdocs");
				  Statement stmt=conn.createStatement();
				  String mon=month.substring(0, 3);
				  int day=HelperClass.getDays(mon,year);
				  String get_request="";
				  String from_date="01-"+mon+"-"+year;
				  String to_date=day+"-"+mon+"-"+year;
				  if(!ateam.equalsIgnoreCase("")){
				   get_request =" select * from test_change_request where ( team='"+team+"' or team ='"+ateam+"') and dt_from > = '"+from_date+"' and dt_from < = '"+to_date+"' and status=0  and project='"+project+"' order by dt_from asc";
				  }
				  else
				  {
					   get_request =" select * from test_change_request where team='"+team+"' and dt_from > = '"+from_date+"' and dt_from < = '"+to_date+"' and status=0  and project='"+project+"' order by dt asc";
				  }
				  ResultSet get_request_rs=stmt.executeQuery(get_request);
				  
				  message.append("<table border=\"1\"><tr><th>NT ID </th><th>From Date</th><th>To Date</th><th>Day From</th><th>Day To</th><th>Requested Shift</th><th>Reason</th><th><input type=\"checkbox\" id=\"all\" onclick=\"checkAll(this);\">Select All</th></tr>");
				  while(get_request_rs.next())
				  { Calendar c1 = Calendar.getInstance();
				  	c1.setTime(get_request_rs.getDate("dt_from"));
				  int day_of_week = c1.get(Calendar.DAY_OF_WEEK);
				  Calendar c2 = Calendar.getInstance();
				  c2.setTime(get_request_rs.getDate("dt_to"));
				  int day_of_week1 = c2.get(Calendar.DAY_OF_WEEK);
					  message.append("<tr><td>"+get_request_rs.getString("NT_ID")+"</td><td>"+get_request_rs.getDate("dt_from")+"</td><td>"+get_request_rs.getDate("dt_to")+"</td><td>"+days[day_of_week]+"</td><td>"+days[day_of_week1]+"</td><td>"+HelperClass.getDisplayName(get_request_rs.getString("shift"),project, conn)+"</td><td>"+get_request_rs.getString("reason")+"</td><td><input type=\"checkbox\" name=\"id"+i+"\"/></td></tr>");
					  i++;
				  }
				 
				  message=message.append("</table>");
				  conn.close();
			  }
			  catch (SQLException e)
				{     e.printStackTrace(); 
		          }
				catch (ClassNotFoundException e)
				{     e.printStackTrace(); 
		          }
			  model.addAttribute("team",team);
	 			model.addAttribute("name",name); 
	 			 model.addAttribute("ateam",ateam);
	 			model.addAttribute("date",date.toString());
	 			model.addAttribute("id",id);
	 			model.addAttribute("month",month);
				model.addAttribute("year",year);
				model.addAttribute("project",project);
				model.addAttribute("total",i - 1);
	 			model.addAttribute("message",message.toString());
	 			
			 return "showreviewrequest";	
	}
		 
		 @RequestMapping(value = "/shiftaprovalconfirmation", method = RequestMethod.POST)
		  public String confirmReviewRequest(@RequestParam("name") String name,
				  				@RequestParam("team") String team,
				  				@RequestParam("id") String id,
				  				@RequestParam("approve") String request,
				  				@RequestParam("month") String month,
				  				@RequestParam("year") String year,
				  				@RequestParam("ateam") String ateam,
				  				@RequestParam("button") String button,
				  				@RequestParam("project") String project,
				  				Model model) {
			 String[] ntid=new String[50];
			 String[] date=new String[50];
			 String[] date_to=new String[50];
			 String[] shift=new String[50];
			 ArrayList arr = new ArrayList();
			 int j=0;
			 StringTokenizer st2 = new StringTokenizer(request, "id");
				while (st2.hasMoreElements()) {
					arr.add(Integer.parseInt(st2.nextElement().toString()));
				}
				System.out.println(arr.size());
				 try { 
					  Class.forName("oracle.jdbc.driver.OracleDriver");
					  Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@sorabhh01v:1521/xe","system", "amdocs");
					  Statement stmt=conn.createStatement();
					  String mon=month.substring(0, 3);
					  int day=HelperClass.getDays(mon,year);
					  String from_date="01-"+mon+"-"+year;
					  String to_date=day+"-"+mon+"-"+year;
					  String get_request =" select nt_id,TO_CHAR(dt_from,'DD-MON-YYYY'),TO_CHAR(dt_to,'DD-MON-YYYY'),shift from test_change_request where (team='"+team+"' or team='"+ateam+"') and dt_from > = '"+from_date+"' and dt_from < = '"+to_date+"' and status=0 and project='"+project+"' order by dt_from asc";
					  ResultSet get_request_rs=stmt.executeQuery(get_request);
					  while(get_request_rs.next())
					  {
						  ntid[j]=get_request_rs.getString("nt_id");
						  date[j]=get_request_rs.getString("TO_CHAR(dt_from,'DD-MON-YYYY')");
						  date_to[j]=get_request_rs.getString("TO_CHAR(dt_to,'DD-MON-YYYY')");
						  shift[j]=get_request_rs.getString("shift");
						  j++;

					  }
					  if(button.equalsIgnoreCase("Approve"))
					  {
					  for(int i=0;i<arr.size();i++)
					  {   if(conn.isClosed())
					  	{
						  conn = DriverManager.getConnection("jdbc:oracle:thin:@sorabhh01v:1521/xe","system", "amdocs");
						  stmt=conn.createStatement();
					  	}
						String sql="update test_shifts set shift='"+shift[(Integer)arr.get(i)]+"' where nt_id='"+ntid[(Integer)arr.get(i)]+"' and dt>='"+date[(Integer)arr.get(i)]+"' and dt<='"+date_to[(Integer)arr.get(i)]+"'";
						stmt.executeUpdate(sql);
						String sql_requesr_table="update test_change_request set status=1 where nt_id='"+ntid[(Integer)arr.get(i)]+"' and dt_from='"+date[(Integer)arr.get(i)]+"' and dt_to='"+date_to[(Integer)arr.get(i)]+"' and shift ='"+shift[(Integer)arr.get(i)]+"'";
						stmt.executeUpdate(sql_requesr_table);
						RequestApproval obj=new RequestApproval();
						obj.approve(ntid[(Integer)arr.get(i)], shift[(Integer)arr.get(i)], date[(Integer)arr.get(i)],date_to[(Integer)arr.get(i)], team, 1,ateam,name,project,conn);
					  }
					  }
					  if(button.equalsIgnoreCase("Reject"))
					  {
						  for(int i=0;i<arr.size();i++)
						  {  if(conn.isClosed())
						  	{
							  conn = DriverManager.getConnection("jdbc:oracle:thin:@sorabhh01v:1521/xe","system", "amdocs");
							  stmt=conn.createStatement();
						  	}
							String sql_requesr_table="update test_change_request set status=2 where nt_id='"+ntid[(Integer)arr.get(i)]+"' and dt_from='"+date[(Integer)arr.get(i)]+"' and dt_to='"+date_to[(Integer)arr.get(i)]+"' and shift ='"+shift[(Integer)arr.get(i)]+"'";
							stmt.executeUpdate(sql_requesr_table);
							RequestApproval obj=new RequestApproval();
							obj.approve(ntid[(Integer)arr.get(i)], shift[(Integer)arr.get(i)], date[(Integer)arr.get(i)],date_to[(Integer)arr.get(i)], team, 2,ateam,name,project,conn);
						  }
					}
						  model.addAttribute("team",team);
						  model.addAttribute("ateam",ateam);
				 			model.addAttribute("name",name); 
				 			model.addAttribute("date",date.toString());
				 			model.addAttribute("id",id);
				 			model.addAttribute("project",project);
				 			model.addAttribute("message","The Shift changes are updated in the databse");
				 			 conn.close();  
				  }
				  catch (SQLException e)
					{     e.printStackTrace(); 
			          }
					catch (ClassNotFoundException e)
					{     e.printStackTrace(); 
			          }
			 
			 return "changeshiftconfirm";	
	}
		 @RequestMapping(value = "/alladdedusers", method = RequestMethod.POST)
		  public String allAddedUsers(@RequestParam("name") String name,
				  				@RequestParam("team") String team,
				  				@RequestParam("id") String id,
				  				@RequestParam("ateam") String ateam,
				  				@RequestParam("project") String project,
				  				Model model) {
			 StringBuilder message=new StringBuilder();
			 DateFormat dateFormat = new SimpleDateFormat("MMMM dd yyyy");
			  java.util.Date date = new java.util.Date();
			 try { 
				  Class.forName("oracle.jdbc.driver.OracleDriver");
				  Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@sorabhh01v:1521/xe","system", "amdocs");
				  Statement stmt=conn.createStatement();
				  String get_request =" select * from test_employee_details where project='"+project+"'";
				  ResultSet get_request_rs=stmt.executeQuery(get_request);
				  message.append("<table border=\"1\"><tr><th>NT ID </th><th>Name</th><th>Emp Id</th><th>Team</th></tr>");
				  while(get_request_rs.next())
				  { 
					  message.append("<tr><td>"+get_request_rs.getString("NT_ID")+"</td><td>"+get_request_rs.getString("FNAME")+" "+get_request_rs.getString("LNAME")+"</td><td>"+get_request_rs.getString("EMP_ID")+"</td><td>"+get_request_rs.getString("TEAM")+"</td></tr>");
				  }
				 
				  message=message.append("</table>");
				  conn.close();
			  }
			  catch (SQLException e)
				{     e.printStackTrace(); 
		          }
				catch (ClassNotFoundException e)
				{     e.printStackTrace(); 
		          }
			  model.addAttribute("team",team);
			  model.addAttribute("ateam",ateam);
				model.addAttribute("name",name); 
				model.addAttribute("id",id);
				model.addAttribute("project",project);
				model.addAttribute("date",date.toString());
				model.addAttribute("message",message.toString());
				
			 return "alladdedusers";	
			 
		 }
		 @RequestMapping(value = "/delegateconfirm", method = RequestMethod.POST)
		  public String delegateconfirm(@RequestParam("name") String name,
				  				@RequestParam("team") String team,
				  				@RequestParam("id") String id,
				  				@RequestParam("reqid") String reqid,
				  				@RequestParam("button") String button,
				  				@RequestParam("ateam") String ateam,
				  				@RequestParam("project") String project,
				  				Model model) {
			 StringBuilder message=new StringBuilder();
			 DateFormat dateFormat = new SimpleDateFormat("MMMM dd yyyy");
			  java.util.Date date = new java.util.Date();
			  int count=0;
			  boolean error=false;
			 try { 
				  Class.forName("oracle.jdbc.driver.OracleDriver");
				  Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@sorabhh01v:1521/xe","system", "amdocs");
				  Statement stmt=conn.createStatement();
				  if(button.equalsIgnoreCase("Add"))
				  {
					  String sql="select count(*) from test_manager where id='"+reqid.toUpperCase()+"' and project='"+project+"'";
					  ResultSet rs=stmt.executeQuery(sql);
					  while(rs.next())
					  {
						  count=rs.getInt(1);
					  }
					  if(count==0)
					  {		String temp_email="";
						  	String sql_get_email="Select email_id from test_employee_details where nt_id='"+reqid.toUpperCase()+"'";
					  		ResultSet rs_sql_get_email=stmt.executeQuery(sql_get_email);
					  		while(rs_sql_get_email.next())
					  		{
					  			temp_email=rs_sql_get_email.getString("email_id");
					  		}
						  String sql_add="insert into test_manager values('"+reqid.toUpperCase()+"','Y','"+team.toUpperCase()+"','','"+temp_email+"','"+project+"')"; 
						  stmt.executeUpdate(sql_add);
					  }
					  message.append("User Added Sucessfully");
				  }
				  else if(button.equalsIgnoreCase("Remove"))
				  {
					  String sql="select count(*) from test_manager where id='"+reqid.toUpperCase()+"' and delegate='Y' and project='"+project+"'";
					  ResultSet rs=stmt.executeQuery(sql);
					  while(rs.next())
					  {
						  count=rs.getInt(1);
					  }
					  if(count > 0)
					  {
						  String sql_del="delete from test_manager where id ='"+reqid.toUpperCase()+"' and delegate ='Y'"; 
						  stmt.executeUpdate(sql_del);
					  }
					  message.append("User Deleted Sucessfully");
				  }
				  conn.close();
			  }
			  catch (SQLException e)
				{ error=true;   
				  e.printStackTrace(); 
		          }
				catch (ClassNotFoundException e)
				{    error=true;   
		          }
			  model.addAttribute("team",team);
			  model.addAttribute("ateam",ateam);
				model.addAttribute("name",name); 
				model.addAttribute("id",id);
				model.addAttribute("date",date.toString());
				model.addAttribute("project",project);
				if(error){
					model.addAttribute("message","Error Occured the root cause may be the ntid already exist in database");
				}else
				{
				model.addAttribute("message",message.toString());
				}
				
			 return "delegateconfirm";	
			 
		 }
}