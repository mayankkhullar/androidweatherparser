package com.amdocs.tmo;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class GetFullNames {
	public static String getNames(String ntid,Connection conn)
	{String name="";
		int empid=0000;
	  try { 
		  Statement stmt=conn.createStatement();
		  String sql="Select emp_id,fname,lname from test_employee_details where nt_id='"+ntid+"'";
		  ResultSet rs=stmt.executeQuery(sql);
		  while(rs.next())
		  {		empid=rs.getInt("emp_id");
			  name=rs.getString("fname") + " " +rs.getString("lname");
		  }
	  } 
	  catch (SQLException e)
		{     e.printStackTrace(); 
        }
		if(name == null || ("").equalsIgnoreCase(name))
		{
			return ""+empid+"%"+ntid;
		}
		else
		{
			return ""+empid+"%"+GetFullNames.changeCase(name);
		}
	}
	public static String toTitleCase(String input) {
	    StringBuilder titleCase = new StringBuilder();
	    boolean nextTitleCase = true;

	    for (char c : input.toCharArray()) {
	        if (Character.isSpaceChar(c)) {
	            nextTitleCase = true;
	        } else if (nextTitleCase) {
	            c = Character.toTitleCase(c);
	            nextTitleCase = false;
	        }

	        titleCase.append(c);
	    }

	    return titleCase.toString();
	}
	public static String getInitials(String ntid,Connection conn)
	{
		String name="";
		int empid=0000;
	  try { 
		  Statement stmt=conn.createStatement();
		  String sql="Select fname,lname from test_employee_details where nt_id='"+ntid+"'";
		  ResultSet rs=stmt.executeQuery(sql);
		  while(rs.next())
		  {		
			  name=rs.getString("fname").charAt(0)+""+rs.getString("lname").charAt(0);
		  }
	  } 
	  catch (SQLException e)
		{     e.printStackTrace(); 
        }
	  return name;
	}
	public static String changeCase(String message)
	{
		String temp="";
		String arr[]=message.split(" ");
		for(int i=0;i<arr.length;i++)
		{	if(!arr[i].equalsIgnoreCase(""))
		{
			arr[i].toLowerCase();
			String t=arr[i].toLowerCase().substring(0,1);
			String tt=t.toUpperCase();
			String qq=arr[i].toLowerCase().substring(1);
			String temp1=tt+qq;
			temp=temp+" "+temp1;
		}
		}
		return temp;
	}
}
