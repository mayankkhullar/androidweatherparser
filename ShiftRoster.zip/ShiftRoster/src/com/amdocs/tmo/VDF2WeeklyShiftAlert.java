/**
 * 
 */


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import com.amdocs.tmo.model.SendMail;

/**
 * @author SAHILBA
 *
 */
public class VDF2WeeklyShiftAlert {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		String[] nt_id=new String[100];
		String[] email_cc=new String[50];
		String[] dates_day=new String[50];
		String[] dates=new String[50];
		String[] emailid=new String[50];
		 SimpleDateFormat formatter = new SimpleDateFormat("dd-MMM-yyyy");
			Calendar cal = Calendar.getInstance();
			    cal.add(Calendar.DATE, +3); 
			System.out.println(formatter.format(cal.getTime()));
			String dt=formatter.format(cal.getTime());
			StringBuilder message=new StringBuilder();
			String[] dayss={"Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"};
			String[] month_array={"","Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"};
			try { 
				  Class.forName("oracle.jdbc.driver.OracleDriver");
				  Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@sorabhh01v:1521/xe","system", "amdocs");
				  Statement stmt=conn.createStatement();
					 int day=HelperClass.getDays(dt.substring(3,6),dt.substring(7));
					 System.out.println(dt.substring(3,6)+" "+day);
					 String from_dt=dt.substring(0,2)+"-"+dt.substring(3,6)+"-"+dt.substring(7);
					 System.out.println(from_dt);
					 cal.add(Calendar.DATE,6);
					String to_dt=formatter.format(cal.getTime());
					String to_date=to_dt.substring(0,2)+"-"+to_dt.substring(3,6)+"-"+to_dt.substring(7);
					 System.out.println(to_date);
					 String get_dates="select distinct dt from test_shifts where dt > = '"+from_dt+"' and dt < = '"+to_date+"' and project='KIAS/non-KIAS' order by dt";
					  ResultSet rs_get_dates=stmt.executeQuery(get_dates);
					  message=message.append("<br><h4>Shifts From : "+from_dt+" to "+to_date+"</h4><br><table width=\"50%\" border=\"1\"><tr><th bgcolor=\"#C0C0C0\">Name & Date</th>");
					  int days=0;
					  while(rs_get_dates.next())
					  {		java.sql.Date dt1=rs_get_dates.getDate("dt");
					  		Calendar c = Calendar.getInstance();
					  		c.setTime(dt1);
					  		int day_of_week = c.get(Calendar.DAY_OF_WEEK);
					  		dates_day[days]=dayss[day_of_week - 1];
					  		String temp=dt1.toString().substring(5,7);
						 // 	String temp=rs_get_dates.getString("dt").substring(5,7);
				  			String m=month_array[Integer.parseInt(temp)];
				  			String tempp=dt1.toString().substring(8, 10);
				  		//	String tempp=rs_get_dates.getString("dt").substring(8, 10);
				  			tempp= tempp+"-"+m+"-"+c.get(Calendar.YEAR)+"";
						  dates[days]=tempp;
						  message=message.append("<th bgcolor=\"#C0C0C0\">"+dates[days].substring(0, 6)+"</th>");
						  days++;
					  }
					  message=message.append("</tr><tr><th bgcolor=#C0C0C0>Days</th>");
					  for(int i=0;i<days;i++)
					  {
						  message=message.append("<th bgcolor=\"#C0C0C0\">"+dates_day[i]+"</th>");
					  }
					  message=message.append("</tr>");
					  String get_nt_id="select distinct nt_id from test_shifts where shift is not null and dt >='"+from_dt+"' and dt<='"+to_date+"' and project='KIAS/non-KIAS' order by nt_id";
					  ResultSet rs_get_nt_id=stmt.executeQuery(get_nt_id);
					  int count=0;
					  while(rs_get_nt_id.next())
					  {
						  nt_id[count]=rs_get_nt_id.getString("nt_id");
						  count++;  
					  }
					  for(int i=0;i<count;i++)
					  {
						  message=message.append("<tr><th bgcolor=\"#C0C0C0\">"+GetNamesDb.getNames(nt_id[i],conn)+"</th>");
						  	for(int k=0;k<days;k++)
						  	{
						  		String get_shift="select shift from test_shifts where nt_id='"+nt_id[i]+"' and dt='"+dates[k]+"'";
						  		ResultSet rs_get_shift=stmt.executeQuery(get_shift);
						  		if(rs_get_shift.next())
						  		{String temp=rs_get_shift.getString("shift");
						  			message=message.append("<th bgcolor="+HelperClass.getColor(temp, "KIAS/non-KIAS", conn)+">"+HelperClass.getDisplayName(temp, "KIAS/non-KIAS", conn)+"</th>");
						  		}
						  		else
						  		{
						  			message=message.append("<th></th>");
						  		}
						  	}
						  	message=message.append("</tr>");  
					  }
					  message=message.append("</table>");  
					  emailid[0]="VFMinusD2INFRATeam@int.amdocs.com";
					  SendMail mail=new SendMail();
				      mail.sendMessage("<Html><body>Hi&nbsp;Team,<br><br>Please find below the shifts for next week<br><br>"+message.toString()+"<br><br>Thank You<br><br><br><br><br>This is auto generated message . Please do not reply.", "Shift Schedule from "+from_dt+" to "+to_date,emailid,email_cc);  
					  conn.close(); 
				 } 
			  catch (SQLException e)
				{     e.printStackTrace(); 
		          } catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		   
		// TODO Auto-generated method stub

	}

}
