package com.amdocs.tmo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import com.amdocs.tmo.model.SendMail;

public class ATTJewelCombinedSMS {


	public static void main(String[] args) {
		String email_id[]=new String[30];
		String email_cc[]=new String[20];
		List temp=new ArrayList();
		int count=0;
		String key="";
		StringBuilder message=new StringBuilder();
		Map <String,String> map=new HashMap<String,String>();
		Map <String,String> sorted=new HashMap<String,String>();
		 SimpleDateFormat formatter = new SimpleDateFormat("dd-MMM-yyyy");
			Calendar cal = Calendar.getInstance();
			    cal.add(Calendar.DATE, +1); 
			    String dt=formatter.format(cal.getTime());
			    try { 
					  Class.forName("oracle.jdbc.driver.OracleDriver");
					  Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@sorabhh01v:1521/xe","system", "amdocs");
					  Statement stmt=conn.createStatement();
					  stmt = conn.createStatement();
					  Statement tempstmt=conn.createStatement();
					  tempstmt = conn.createStatement();
					  String sql="select distinct nt_id from test_employee_details where project='ATT-JEWEL'";
					  ResultSet rs=stmt.executeQuery(sql);
					  while(rs.next())
					  {	String shift="";
						  String ntid=rs.getString("nt_id");
						  String sql2="Select shift from test_shifts where DT='"+dt+"' and nt_id='"+ntid+"'";
						  ResultSet rs2=tempstmt.executeQuery(sql2);
						  while(rs2.next())
						  {		
							  	key=ntid;
							  	shift=rs2.getString("shift");
							  	if(!(shift.equalsIgnoreCase("") || shift ==null))
							  	{map.put(key, shift);
							  		if(!temp.contains(shift))
							  		{
							  			temp.add(shift);
							  		}
							  	}
							  	count++;
						  }
					  }
					Iterator iter=temp.iterator();
					while(iter.hasNext())
					{
						String t=(String) iter.next();
						message.append(t+"=");
						  for (Map.Entry<String, String> entry : map.entrySet()) {
							  	if(entry.getValue().equalsIgnoreCase(t))
							  	message.append(entry.getKey()+";");
										}
					}
					  email_id[0]="NESHARMA@amdocs.com";
					  email_id[1]="BISINGH@amdocs.com";
						 SendMail mail=new SendMail();
						 mail.sendMessage("", message.toString(), email_id,email_cc);
						 System.out.println(message.toString().length());
						  }
					  catch (Exception e)
				      {			
				              e.printStackTrace();
				      }        

	}
}
