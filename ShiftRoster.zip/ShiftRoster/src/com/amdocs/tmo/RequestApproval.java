package com.amdocs.tmo;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.io.Writer;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import com.amdocs.tmo.model.SendMail;

public class RequestApproval {
public void approve(String id,String shift,String fromdt,String todt,String team,int status,String ateam,String name,String project,Connection conn)
{
	String[] emailid=new String[100]; 
	String[] email_cc=new String[100]; 
	String[] test_emailid=new String[100]; 
	String[] test_email_cc=new String[100]; 
	test_emailid[0]="sahil.batra@amdocs.com";
	int day_of_week=0,day_of_week1=0;
	 String[] days={"","Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"};
	 String[] shift_status={"","Approved","Rejected"};
	  try { 
		  if(conn.isClosed())
		  {
			  conn = DriverManager.getConnection("jdbc:oracle:thin:@sorabhh01v:1521/xe","system", "amdocs");
		  }
		  Class.forName("oracle.jdbc.driver.OracleDriver");
		  Statement stmt=conn.createStatement();
		  stmt = conn.createStatement();
		  String userTeam=GetNamesDb.getTeam(id, conn,project);
		  String email_to = "select distinct email_id from test_manager where (team='"+userTeam.toUpperCase()+"' or ateam='"+userTeam.toUpperCase()+"') and project='"+project+"'";
		     ResultSet rs= stmt.executeQuery(email_to);
		     int i=0;
		     while(rs.next())
		      {
		      	email_cc[i]=rs.getString("email_id");
		      	i++;
		      }
			      SimpleDateFormat formatter = new SimpleDateFormat("dd-MMM-yyyy");
			      Date da,daa;
				try {
					da = formatter.parse(fromdt);
					 Calendar c = Calendar.getInstance();
					  	c.setTime(da);
					   day_of_week = c.get(Calendar.DAY_OF_WEEK);
					   daa = formatter.parse(todt);
						 Calendar c1 = Calendar.getInstance();
						  	c1.setTime(daa);
						   day_of_week1 = c1.get(Calendar.DAY_OF_WEEK);
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					Writer writer = new StringWriter();
			          PrintWriter printWriter = new PrintWriter(writer);
			          e.printStackTrace(printWriter);
			          String s = writer.toString();
			          SendMail m=new SendMail();
			          String[] ee=new String[1];
			          String[] ec=new String[0];
			          ee[0]="Sahil.batra@amdocs.com";
			          m.sendMessage(s,"Error Report", ee, ec);
				}
				emailid[0]=GetUserEmail.getemail(id,conn);
				
			      SendMail mail=new SendMail();
			      if(status==3)
			      {
			    	  mail.sendMessage("<Html><body>Hi&nbsp;"+GetNamesDb.getNames(id,conn)+"<br><br>Your Request has been Deleted .<br><br>Request Status:<br><br><table border=\"1\"><tr><th>From Date</th><th>To Date</th><th>From Day</th><th>From Day</th><th> Shift</th><th> Status</th></tr><tr><td>"+fromdt+"</td><td>"+todt+"</td><td>"+days[day_of_week]+"</td><td>"+days[day_of_week1]+"</td><td>"+HelperClass.getDisplayName(shift, project, conn)+"</td><td>Deleted by User</td></tr></table>"+"<br><br>Thank You<br><br><br><br><br>This is auto generated message . Please do not reply.", "Shift Change Request Deletion",emailid,email_cc); 
			      }
			      else
			      {
			      mail.sendMessage("<Html><body>Hi&nbsp;"+GetNamesDb.getNames(id,conn)+"<br><br>Your Request has been reviewed by &nbsp;"+HelperClass.changeCase(name)+".<br><br>Request Status:<br><br><table border=\"1\"><tr><th>From Date</th><th>To Date</th><th>From Day</th><th>From Day</th><th> Shift</th><th> Status</th></tr><tr><td>"+fromdt+"</td><td>"+todt+"</td><td>"+days[day_of_week]+"</td><td>"+days[day_of_week1]+"</td><td>"+HelperClass.getDisplayName(shift, project, conn)+"</td><td>"+shift_status[status]+"</td></tr></table>"+"<br><br>Thank You<br><br><br><br><br>This is auto generated message . Please do not reply.", "Shift Change Request Approval/Rejection",emailid,email_cc);
			      }
	  }
	  catch (SQLException e)
		{     e.printStackTrace(); 
		Writer writer = new StringWriter();
        PrintWriter printWriter = new PrintWriter(writer);
        e.printStackTrace(printWriter);
        String s = writer.toString();
        SendMail m=new SendMail();
        String[] ee=new String[1];
        String[] ec=new String[0];
        ee[0]="Sahil.batra@amdocs.com";
        m.sendMessage(s,"Error Report", ee, ec);
        }
		catch (ClassNotFoundException e)
		{     e.printStackTrace(); 
		Writer writer = new StringWriter();
        PrintWriter printWriter = new PrintWriter(writer);
        e.printStackTrace(printWriter);
        String s = writer.toString();
        SendMail m=new SendMail();
        String[] ee=new String[1];
        String[] ec=new String[0];
        ee[0]="Sahil.batra@amdocs.com";
        m.sendMessage(s,"Error Report", ee, ec);
        }
}
}
