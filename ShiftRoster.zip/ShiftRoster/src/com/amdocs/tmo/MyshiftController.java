package com.amdocs.tmo;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.io.Writer;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.StringTokenizer;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.amdocs.tmo.model.SendMail;
@Controller
public class MyshiftController {
	 @RequestMapping(value = "/myshiftshow", method = RequestMethod.POST)
	  public String myShiftshow(
			  				@RequestParam("name") String name,
			  				@RequestParam("team") String team,
			  				@RequestParam("ateam") String ateam,
			  				@RequestParam("id") String id,	
			  				@RequestParam("project") String project,
			  				@RequestParam("mm") String month,
			  				@RequestParam("yy") String year,Model model,
			  				HttpServletRequest request) {
		// 	String name=request.getSession().getAttribute("name").toString();
		// 	String team=request.getSession().getAttribute("team").toString();
		// 	String ateam=request.getSession().getAttribute("ateam").toString();
		// 	String id=request.getSession().getAttribute("id").toString();
		// 	String project=request.getSession().getAttribute("project").toString();
		 String[] days={"Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"};
		 StringBuilder message1=new StringBuilder();
		 StringBuilder message2=new StringBuilder();
		 StringBuilder message3=new StringBuilder();
		 String[] shift=new String[25];
			int shift_count=0;
		 boolean isError=false;
		 if(month.equalsIgnoreCase("Select") || year.equalsIgnoreCase("Select"))
		 {
			 isError=true;
		 }
		 DateFormat dateFormat = new SimpleDateFormat("MMMM dd yyyy");
		 java.util.Date date = new java.util.Date();
		  try { 
			  if(!isError){
			  String[] shifts=new String[50];
			  String[] in_time=new String[50];
			  String[] out_time=new String[50];
			  int i=0;
			  Class.forName("oracle.jdbc.driver.OracleDriver");
			  Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@sorabhh01v:1521/xe","system", "amdocs");
			  Statement stmt=conn.createStatement();
			  stmt = conn.createStatement();
			  String get_time =" select * from test_shift_details where project='"+project+"' order by shift_id";
			  ResultSet get_time_rs=stmt.executeQuery(get_time);
			  while(get_time_rs.next())
			  {shifts[i]=get_time_rs.getString("DISPLAY_VALUE");
			  	in_time[i]=get_time_rs.getString("IN_TIME");
			  	out_time[i]=get_time_rs.getString("OUT_TIME");
			  	i++;
			  }
			  String mon=month.substring(0, 3);
			  String temp_date="";
			  String temp_date_2="";
			  int day=HelperClass.getDays(mon,year);
			  if(day == 31)
			  {
				   temp_date="16-"+mon+"-"+year;
				   temp_date_2="16-"+mon+"-"+year;
			  }
			  else if(day == 30)
			  {
				   temp_date="15-"+mon+"-"+year;
				   temp_date_2="16-"+mon+"-"+year;
			  }
			  else if(day==28)
			  {
				   temp_date="14-"+mon+"-"+year;
				   temp_date_2="15-"+mon+"-"+year;
			  }
			  String from_date="01-"+mon+"-"+year;
			  String to_date=day+"-"+mon+"-"+year; //and project='"+project+"'
			  String sql1="Select dt,shift from test_shifts where nt_id='"+id+"' and dt > = '"+from_date+"' and dt < = '"+temp_date+"' order by dt asc";
			  String sql2="Select dt,shift from test_shifts where nt_id='"+id+"' and dt > = '"+temp_date_2+"' and dt < = '"+to_date+"'  order by dt asc";
			  ResultSet rs1=stmt.executeQuery(sql1);
			  message1=message1.append("<table border=\"1\" align=\"center\"><tr><th bgcolor=\"#C0C0C0\">Date</th><th bgcolor=\"#C0C0C0\">Day</th bgcolor=\"#C0C0C0\"><th bgcolor=\"#C0C0C0\">Shift</th><th bgcolor=\"#C0C0C0\">In Time</th><th bgcolor=\"#C0C0C0\">Out Time</th></tr>") ;
			  message2=message2.append("<table border=\"1\" align=\"center\"><tr><th bgcolor=\"#C0C0C0\">Date</th><th bgcolor=\"#C0C0C0\">Day</th bgcolor=\"#C0C0C0\"><th bgcolor=\"#C0C0C0\">Shift</th><th bgcolor=\"#C0C0C0\">In Time</th><th bgcolor=\"#C0C0C0\">Out Time</th></tr>") ;
			  while(rs1.next())
			  {	
				  Calendar c = Calendar.getInstance();
				  c.setTime(rs1.getDate("dt"));
				  int day_of_week = c.get(Calendar.DAY_OF_WEEK);
				  String temp=rs1.getString("shift");
				 message1=message1.append("<tr><th bgcolor="+HelperClass.getColor(temp, project, conn)+">"+rs1.getDate("dt")+"</th><th bgcolor="+HelperClass.getColor(temp, project, conn)+">"+days[day_of_week - 1]+"</th><th bgcolor="+HelperClass.getColor(temp, project, conn)+">"+HelperClass.getDisplayName(temp, project, conn)+"</th><th bgcolor="+HelperClass.getColor(temp, project, conn)+">"+HelperClass.getInTime(rs1.getString("shift"), project, conn)+"</th><th bgcolor="+HelperClass.getColor(temp, project, conn)+">"+HelperClass.getOutTime(rs1.getString("shift"), project, conn)+"</th></tr>");
			  }
			  ResultSet rs2=stmt.executeQuery(sql2);
			  while(rs2.next())
			  {	
				  Calendar c = Calendar.getInstance();
				  c.setTime(rs2.getDate("dt"));
				  int day_of_week = c.get(Calendar.DAY_OF_WEEK);
				  String temp=rs2.getString("shift");
				 message2=message2.append("<tr><th bgcolor="+HelperClass.getColor(temp, project, conn)+">"+rs2.getDate("dt")+"</th><th bgcolor="+HelperClass.getColor(temp, project, conn)+">"+days[day_of_week - 1]+"</th><th bgcolor="+HelperClass.getColor(temp, project, conn)+">"+HelperClass.getDisplayName(temp, project, conn)+"</th><th bgcolor="+HelperClass.getColor(temp, project, conn)+">"+HelperClass.getInTime(rs2.getString("shift"), project, conn)+"</th><th bgcolor="+HelperClass.getColor(temp, project, conn)+">"+HelperClass.getOutTime(rs2.getString("shift"), project, conn)+"</th></tr>");
			  }
			  message1=message1.append("</table>");
			  message2=message2.append("</table>");
			  
			  
			  
			  message3.append("<table border=\"1\"><tr>");
			  String sql_shifts="Select distinct shift from test_shifts where project='"+project+"' order by shift";
			  ResultSet rs_sql_shifts=stmt.executeQuery(sql_shifts);
			  while(rs_sql_shifts.next())
			  {		shift[shift_count]=rs_sql_shifts.getString("shift");
				  message3.append("<th bgcolor="+HelperClass.getColor(shift[shift_count], project, conn)+">"+HelperClass.getDisplayName(shift[shift_count],project, conn)+"</th>");
				  shift_count++;
			  }
			  message3.append("</tr>");
				  for(int j=0;j<shift_count;j++)
				  {
					  String sql_shift_count="Select Count(*) from test_shifts where shift='"+shift[j]+"' and nt_id='"+id+"' and dt>='"+from_date+"' and dt<='"+to_date+"'";
					  ResultSet rs_sql_shift_count=stmt.executeQuery(sql_shift_count);
					  while(rs_sql_shift_count.next())
					  {
						  message3.append("<td>"+rs_sql_shift_count.getInt(1)+""+"</td>");
					  }
				  }
				  message3.append("</tr>");
				  message3.append("</table>");
				  conn.close();
			  }
		  }
		  catch (SQLException e)
			{     e.printStackTrace(); }
			catch (ClassNotFoundException e)
			{     e.printStackTrace(); }
			model.addAttribute("team",team);
			model.addAttribute("ateam",ateam);
			model.addAttribute("name",name); 	
		//	model.addAttribute("date",date.toString());
			model.addAttribute("id",id);
			model.addAttribute("project",project);
			
			if(!isError)
			{
			model.addAttribute("month",month);
			model.addAttribute("year",year);
			model.addAttribute("message","&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Shift for Month : "+month +" and Year "+year+"<br>Shift Counts :");
			model.addAttribute("message1",message1.toString());
			model.addAttribute("message2",message2.toString());
			model.addAttribute("message3",message3.toString());
		 return "mainmenu_new";
			}
			else
			{
				model.addAttribute("message","<H1>Please Select the Month and Year</H1>");
				 return "myshiftshow";
			}
}
	 @RequestMapping(value = "/myteamshift", method = RequestMethod.POST)
	  public String myTeamShiftShow(
			  				@RequestParam("name") String name,
			  				@RequestParam("team") String team,
			  				@RequestParam("ateam") String ateam,
			  				@RequestParam("project") String project,
			  				@RequestParam("id") String id,	
			  				@RequestParam("mmm") String month,
			  				@RequestParam("yyy") String year,
			  				@RequestParam("v2") String view,Model model,HttpServletRequest request) throws ParseException {
		//	String name=request.getSession().getAttribute("name").toString();
		// 	String team=request.getSession().getAttribute("team").toString();
		// 	String ateam=request.getSession().getAttribute("ateam").toString();
		// 	String id=request.getSession().getAttribute("id").toString();
		// 	String project=request.getSession().getAttribute("project").toString();
		 boolean isError=false;
		 StringBuilder mailMessage= new StringBuilder();
		 java.util.Date date = new java.util.Date();
		 if(month.equalsIgnoreCase("Select") || year.equalsIgnoreCase("Select"))
		 {
			 isError=true;
		 }
		 if(view.equalsIgnoreCase("monthly"))
		 {
			 MonthlyReport mm=new MonthlyReport();
			 mailMessage.append(mm.generateMonthlyShifts(month,year,team,project));
		 }
		 else
		 {
		 	WeeklyReport obj=new WeeklyReport();
		 	if(!isError){
		 		mailMessage.append(obj.generateMonthlyShifts(month,year,team,01,07,project));
				mailMessage.append(obj.generateMonthlyShifts(month,year,team,8,14,project));
				mailMessage.append(obj.generateMonthlyShifts(month,year,team,15,21,project));
				mailMessage.append(obj.generateMonthlyShifts(month,year,team,22,28,project));
				mailMessage.append(obj.generateMonthlyShifts(month,year,team,29,0,project));
		 	}
		 }
			model.addAttribute("team",team);
			model.addAttribute("ateam",ateam);
			model.addAttribute("name",name); 	
			model.addAttribute("date",date.toString());
			model.addAttribute("id",id);
			model.addAttribute("project",project);
			if(!isError)
			{	model.addAttribute("month",month);
				model.addAttribute("year",year);
				model.addAttribute("message",mailMessage.toString());
				return "mainmenu_new";
			}
			else
			{
				model.addAttribute("message","<H1>Please Select the Month and Year</H1>");
				 return "myteamshift";
			}
} 
	 @RequestMapping(value = "/changerequest", method = RequestMethod.POST)
	  public String myShiftReview(@RequestParam("name") String name,
			  				@RequestParam("team") String team,
			  				@RequestParam("ateam") String ateam,
			  				@RequestParam("id") String id,
			  				@RequestParam("project") String project,Model model) {
		 DateFormat dateFormat = new SimpleDateFormat("MMMM dd yyyy");
		  java.util.Date date = new java.util.Date();
		  StringBuilder message=new StringBuilder();
		  try { 
			  Class.forName("oracle.jdbc.driver.OracleDriver");
			  Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@sorabhh01v:1521/xe","system", "amdocs");
			  Statement stmt=conn.createStatement();
			  stmt = conn.createStatement();
			  String get_time =" select * from test_shift_details where project='"+project+"' order by shift_id ";
			  ResultSet get_time_rs=stmt.executeQuery(get_time);
			  message.append("<table border=\"1\"><tr><th>Shift Code</th><th>Shift</th><th>In Time</th><th>Out Time</th></tr>");
			  while(get_time_rs.next())
			  {	message.append("<tr><td>"+get_time_rs.getString("DISPLAY_VALUE")+"</td><td>"+HelperClass.getDisplayName(get_time_rs.getString("DISPLAY_VALUE"), project, conn)+"</td><td>"+get_time_rs.getString("IN_TIME")+"</td><td>"+get_time_rs.getString("OUT_TIME")+"</td></tr>");
			  }
			  message=message.append("</table>");
			  conn.close();
		  }
		  catch (SQLException e)
			{     e.printStackTrace(); }
			catch (ClassNotFoundException e)
			{     e.printStackTrace(); }
		  model.addAttribute("team",team);
		  model.addAttribute("ateam",ateam);
			model.addAttribute("name",name); 
			model.addAttribute("date",date.toString());
			model.addAttribute("id",id);
			model.addAttribute("project",project);
			model.addAttribute("message",message);
		 return "changerequest";
}
	 @RequestMapping(value = "/changerequestconfirm", method = RequestMethod.POST)
	  public String myShiftChangeConfirm(
			  				@RequestParam("name") String name,
			  				@RequestParam("team") String team,
			  				@RequestParam("ateam") String ateam,
			  				@RequestParam("id") String id,
			  				@RequestParam("dt") String fromdt,
			  				@RequestParam("todt")String todt,
			  				@RequestParam("reqshift") String shift,
			  				@RequestParam("reason") String reason,
			  				@RequestParam("project") String project,
			  				Model model,HttpServletRequest request) {
	//	 	String name=request.getSession().getAttribute("name").toString();
	//	 	String team=request.getSession().getAttribute("team").toString();
	//	 	String ateam=request.getSession().getAttribute("ateam").toString();
	//	 	String id=request.getSession().getAttribute("id").toString();
	//	 	String project=request.getSession().getAttribute("project").toString();
		 boolean flag=true;
		 DateFormat dateFormat = new SimpleDateFormat("MMMM dd yyyy");
		 java.util.Date date = new java.util.Date();
		 int count=0;
		 String message="Request Sent To Lead";
		  try { 
			  Class.forName("oracle.jdbc.driver.OracleDriver");
			  Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@sorabhh01v:1521/xe","system", "amdocs");
			  Statement stmt=conn.createStatement();
			  stmt = conn.createStatement();
			  String sql_search="Select count(*) from test_change_request where nt_id='"+id+"' and dt_from='"+fromdt+"' and dt_to='"+todt+"' and status=0 and project='"+project+"'";
			  ResultSet rs1=stmt.executeQuery(sql_search);
				while(rs1.next())
				{
					count=rs1.getInt(1);
				}
				if(count==0)
				{
					String sql="insert into test_change_request values('"+id.toUpperCase()+"',to_date('"+fromdt+"','dd-mon-yy'),to_date('"+todt+"','dd-mon-yy'),'"+shift.toUpperCase()+"','"+reason+"','"+team.toUpperCase()+"',0,'"+project.toUpperCase()+"')";
					if(todt.equalsIgnoreCase(""))
					{
						sql="insert into test_change_request values('"+id.toUpperCase()+"',to_date('"+fromdt+"','dd-mon-yy'),to_date('"+fromdt+"','dd-mon-yy'),'"+shift.toUpperCase()+"','"+reason+"','"+team.toUpperCase()+"',0,'"+project.toUpperCase()+"')";
					}
					stmt.executeUpdate(sql);
					UserRequest ur=new UserRequest();
					ur.changeShift(id, name, fromdt,todt, shift, reason,team,project);
				}
				else
				{
					message="Request already exist for these dates, please delete the same and enter new one";
				}
			  
				model.addAttribute("team",team);
				model.addAttribute("ateam",ateam);
				model.addAttribute("name",name); 
				model.addAttribute("date",date.toString());
				model.addAttribute("id",id);
				model.addAttribute("project",project);
				model.addAttribute("message",message);
				conn.close();
		  }
		  catch (SQLException e)
			{     e.printStackTrace(); 
	          }
			catch (ClassNotFoundException e)
			{     e.printStackTrace(); 
	          }
		 return "mainmenu_new";
	 }
	 @RequestMapping(value = "/myallrequest", method = RequestMethod.POST)
	  public String myRequest(
			  				@RequestParam("name") String name,
			  				@RequestParam("team") String team,
			  				@RequestParam("ateam") String ateam,
			  				@RequestParam("id") String id,
			  				@RequestParam("mon") String month,
			  				@RequestParam("yrs") String year,
			  				@RequestParam("project") String project,
			  				Model model,HttpServletRequest request) {
		//	String name=request.getSession().getAttribute("name").toString();
		// 	String team=request.getSession().getAttribute("team").toString();
		// 	String ateam=request.getSession().getAttribute("ateam").toString();
		// 	String id=request.getSession().getAttribute("id").toString();
		// 	String project=request.getSession().getAttribute("project").toString();
		 StringBuilder message = new StringBuilder();
		 boolean isError=false;
		 if(month.equalsIgnoreCase("Select") || year.equalsIgnoreCase("Select")|| month.equalsIgnoreCase("") || year.equalsIgnoreCase(""))
		 {
			 isError=true;
		 }
		 DateFormat dateFormat = new SimpleDateFormat("MM dd yyyy");
		  java.util.Date date = new java.util.Date();
		  String[] days={"","Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"};
		  String[] status={"Pending","Approved","Rejected"};
		  int i=0;
		  try { 
			  if(!isError){
			  Class.forName("oracle.jdbc.driver.OracleDriver");
			  Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@sorabhh01v:1521/xe","system", "amdocs");
			  Statement stmt=conn.createStatement();
			  String mon="";
			 if(!month.equalsIgnoreCase("")){ mon=month.substring(0, 3);}
			  int day=HelperClass.getDays(mon,year);
			  String from_date="01-"+mon+"-"+year;
			  String to_date=day+"-"+mon+"-"+year;
			  String get_request =" select * from test_change_request where nt_id='"+id+"' and dt_from > = '"+from_date+"' and dt_from < = '"+to_date+"'  and project='"+project+"' order by dt_from asc";
			  ResultSet get_request_rs=stmt.executeQuery(get_request);
			 
			  message.append("<table border=\"1\"><tr><th>NT ID </th><th>From Date</th><th>To Date</th><th>From Day</th><th>To Day</th><th>Requested Shift</th><th>Reason</th><th>Status</th><th>Delete</th></tr>");
			  while(get_request_rs.next())
			  { Calendar c1 = Calendar.getInstance();
			  	c1.setTime(get_request_rs.getDate("dt_from"));
				  int day_of_week = c1.get(Calendar.DAY_OF_WEEK);
				  Calendar c2 = Calendar.getInstance();
				  c2.setTime(get_request_rs.getDate("dt_to"));
				  int day_of_week1 = c2.get(Calendar.DAY_OF_WEEK);
				  int stat=get_request_rs.getInt("status");
				  if(stat==0)
				  {
				  message.append("<tr><td>"+get_request_rs.getString("NT_ID")+"</td><td>"+get_request_rs.getDate("dt_from")+"</td><td>"+get_request_rs.getDate("dt_to")+"</td><td>"+days[day_of_week]+"</td><td>"+days[day_of_week1]+"</td><td>"+HelperClass.getDisplayName(get_request_rs.getString("shift"), project, conn)+"</td><td>"+get_request_rs.getString("reason")+"</td><td>"+status[stat]+"</td><td><input type=\"checkbox\" name=\"id"+i+"\"/></td></tr>");
				  }
				  else
				  {
					  message.append("<tr><td>"+get_request_rs.getString("NT_ID")+"</td><td>"+get_request_rs.getDate("dt_from")+"</td><td>"+get_request_rs.getDate("dt_to")+"</td><td>"+days[day_of_week]+"</td><td>"+days[day_of_week1]+"</td><td>"+HelperClass.getDisplayName(get_request_rs.getString("shift"), project, conn)+"</td><td>"+get_request_rs.getString("reason")+"</td><td>"+status[stat]+"</td><td><input type=\"checkbox\" disabled=\"disabled\" name=\"id"+i+"\"/></td></tr>"); 
				  }
				  i++;
			  }
			 
			  message=message.append("</table>");
			  conn.close();}
		  }
		  catch (SQLException e)
			{     e.printStackTrace(); 
	          }
			catch (ClassNotFoundException e)
			{     e.printStackTrace(); 
	          }
		  model.addAttribute("team",team);
		  model.addAttribute("ateam",ateam);
			model.addAttribute("name",name); 
			model.addAttribute("date",date.toString());
			model.addAttribute("id",id);
			model.addAttribute("project",project);
			model.addAttribute("total",i - 1);
			if(!isError)
			{	model.addAttribute("month",month);
				model.addAttribute("year",year);
				model.addAttribute("message",message.toString());
				return "myallrequest";
			}
			else
			{
				model.addAttribute("message","<H1>Please Select the Month and Year</H1>");
				 return "myallrequest";
			}
}
	
	 @RequestMapping(value = "/shiftdelete", method = RequestMethod.POST)
	  public String confirmReviewRequest(
			  				@RequestParam("name") String name,
			  				@RequestParam("team") String team,
			  				@RequestParam("id") String id,
			  				@RequestParam("approve") String request,
			  				@RequestParam("month") String month,
			  				@RequestParam("year") String year,
			  				@RequestParam("ateam") String ateam,
			  				@RequestParam("project") String project,
			  				HttpServletRequest requestt,
			  				Model model) {
	//		String name=requestt.getSession().getAttribute("name").toString();
	//	 	String team=requestt.getSession().getAttribute("team").toString();
	//	 	String ateam=requestt.getSession().getAttribute("ateam").toString();
	//	 	String id=requestt.getSession().getAttribute("id").toString();
	//	 	String project=requestt.getSession().getAttribute("project").toString();
		 String[] ntid=new String[50];
		 String[] date=new String[50];
		 String[] date_to=new String[50];
		 String[] shift=new String[50];
		 ArrayList arr = new ArrayList();
		 int j=0;
		 StringTokenizer st2 = new StringTokenizer(request, "id");
			while (st2.hasMoreElements()) {
				arr.add(Integer.parseInt(st2.nextElement().toString()));
			}
			System.out.println(arr.size());
			 try { 
				  Class.forName("oracle.jdbc.driver.OracleDriver");
				  Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@sorabhh01v:1521/xe","system", "amdocs");
				  Statement stmt=conn.createStatement();
				  String mon=month.substring(0, 3);
				  int day=HelperClass.getDays(mon,year);
				  String from_date="01-"+mon+"-"+year;
				  String to_date=day+"-"+mon+"-"+year;
				  String get_request =" select nt_id,TO_CHAR(dt_from,'DD-MON-YYYY'),TO_CHAR(dt_to,'DD-MON-YYYY'),shift from test_change_request where nt_id='"+id+"' and dt_from > = '"+from_date+"' and dt_from < = '"+to_date+"' and project='"+project+"' order by dt_from asc";
				  ResultSet get_request_rs=stmt.executeQuery(get_request);
				  while(get_request_rs.next())
				  {
					  ntid[j]=get_request_rs.getString("nt_id");
					  date[j]=get_request_rs.getString("TO_CHAR(dt_from,'DD-MON-YYYY')");
					  date_to[j]=get_request_rs.getString("TO_CHAR(dt_to,'DD-MON-YYYY')");
					  shift[j]=get_request_rs.getString("shift");
					  j++;
				  }
				  for(int i=0;i<arr.size();i++)
				  { if(conn.isClosed())
				  	{
					  conn = DriverManager.getConnection("jdbc:oracle:thin:@sorabhh01v:1521/xe","system", "amdocs");
					  stmt=conn.createStatement();
				  	}
						String sql_requesr_table="delete from test_change_request where nt_id='"+ntid[(Integer)arr.get(i)]+"' and dt_from='"+date[(Integer)arr.get(i)]+"' and dt_to='"+date_to[(Integer)arr.get(i)]+"' and project='"+project+"'";
						stmt.executeUpdate(sql_requesr_table);
						RequestApproval obj=new RequestApproval();
						obj.approve(ntid[(Integer)arr.get(i)], shift[(Integer)arr.get(i)], date[(Integer)arr.get(i)],date_to[(Integer)arr.get(i)], team, 3,ateam,name,project,conn);
				  }
				  model.addAttribute("team",team);
				  model.addAttribute("ateam",ateam);
		 			model.addAttribute("name",name); 
		 			model.addAttribute("date",date.toString());
		 			model.addAttribute("id",id);
		 			model.addAttribute("project",project);
		 			model.addAttribute("message","The Shift request Deleted successfully");
		 			 conn.close();  
		  }
		  catch (SQLException e)
			{     e.printStackTrace(); 
	          }
			catch (ClassNotFoundException e)
			{     e.printStackTrace(); 
	          }
			 return "mainmenu_new";	
		}
	
}