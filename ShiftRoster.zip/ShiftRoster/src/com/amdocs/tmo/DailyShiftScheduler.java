
package com.amdocs.tmo;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.io.Writer;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import com.amdocs.tmo.model.SendMail;

public class DailyShiftScheduler {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		DailyShiftScheduler obj= new DailyShiftScheduler();
		obj.myShift();
		// TODO Auto-generated method stub

	}
		public void myShift()
		{
			 
			String[] teams=new String[10];
			int team_count=0;
			int day_of_week=0;
			 String[] days={"","Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"};
			 
			  try { 
				  Class.forName("oracle.jdbc.driver.OracleDriver");
				  Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@sorabhh01v:1521/xe","system", "amdocs");
				  Statement stmt=conn.createStatement();
				  stmt = conn.createStatement();
				 String get_teams="Select distinct team from test_employee_details";
				 ResultSet rs_get_teams=stmt.executeQuery(get_teams);
				 while(rs_get_teams.next())
				 {
					 teams[team_count]=rs_get_teams.getString("team");
					 team_count++;
				 }
				 for(int j=0;j<team_count;j++)
				  {	String[] emailid=new String[100]; 
					String[] email_cc=new String[100];
					 StringBuilder message=new StringBuilder();
					 String get_team_email ="Select email_id from test_employee_details where team='"+teams[j]+"'";
					 ResultSet rs_get_team_email=stmt.executeQuery(get_team_email);
					 int k=0;
					 while(rs_get_team_email.next())
					 {
						 
						 emailid[k]=rs_get_team_email.getString("email_id");
						 k++;
					 }
					 String get_manager_email ="Select email_id from test_manager where team='"+teams[j]+"' or ateam='"+teams[j]+"'";
					 ResultSet rs_get_manager_email=stmt.executeQuery(get_manager_email);
					 int p=0;
					 while(rs_get_manager_email.next())
					 {
						 
						 email_cc[p]=rs_get_manager_email.getString("email_id");
						 p++;
					 }
					 SimpleDateFormat formatter = new SimpleDateFormat("dd-MMM-yyyy");
						Calendar cal = Calendar.getInstance();
						    cal.add(Calendar.DATE, +1); 
						    day_of_week = cal.get(Calendar.DAY_OF_WEEK);
					 message=message.append("<table border=\"1\"><tr><th bgcolor=\"green\">Name</th><th bgcolor=\"green\">Date</th><th bgcolor=\"green\"> Day</th><th bgcolor=\"green\">Shift</th></tr>");
					 String get_shift="Select nt_id,shift from test_shifts where DT='"+formatter.format(cal.getTime())+"' and team='"+teams[j]+"'";
					 ResultSet rs_get_shifts=stmt.executeQuery(get_shift);
					 while(rs_get_shifts.next())
					 {String temp=rs_get_shifts.getString("shift");
						 message=message.append("<tr><td bgcolor="+setColor(temp)+">"+GetNamesDb.getNames(rs_get_shifts.getString("nt_id"),conn)+"</td><td bgcolor="+setColor(temp)+">"+formatter.format(cal.getTime())+"</td><td bgcolor="+setColor(temp)+">"+days[day_of_week]+"</td><td bgcolor="+setColor(temp)+">"+setShift(temp)+"</td><tr>");
					 }
					 
					
					      SendMail mail=new SendMail();
					      mail.sendMessage("<Html><body>Hi&nbsp;Team,<br><br>Please find below the tomorrow shifts<br><br>"+message.toString()+"</table><br><br>Thank You<br><br><br><br><br>This is auto generated message . Pelase do not reply.", "Shift Schedule for "+formatter.format(cal.getTime()),emailid,email_cc);
				  }
				 conn.close();
				 } 
			  catch (SQLException e)
				{     e.printStackTrace(); 
				Writer writer = new StringWriter();
		          PrintWriter printWriter = new PrintWriter(writer);
		          e.printStackTrace(printWriter);
		          String s = writer.toString();
		          SendMail m=new SendMail();
		          String[] ee=new String[1];
		          String[] ec=new String[0];
		          ee[0]="Sahil.batra@amdocs.com";
		          m.sendMessage(s,"Error Report", ee, ec);
		          }
				catch (ClassNotFoundException e)
				{     e.printStackTrace(); }
				
		}
		public  String setShift(String shift)
		{ 	String temp=null;
			if(shift.equalsIgnoreCase("G"))
				temp="General";
			else if (shift.equalsIgnoreCase("M"))
				temp="Morning";
			else if (shift.equalsIgnoreCase("A"))
				temp="Afternoon";
			else if (shift.equalsIgnoreCase("E"))
				temp="Evening";
			else if (shift.equalsIgnoreCase("N"))
				temp="Night";
			else if (shift.equalsIgnoreCase("WO"))
				temp="Work Off";
			else if (shift.equalsIgnoreCase("VA"))
				temp="Vacation";
			else if (shift.equalsIgnoreCase("SL"))
				temp="Sickleave";
			else if (shift.equalsIgnoreCase("OP"))
				temp="Optional Off";
			else if (shift.equalsIgnoreCase("EM"))
				temp="Early Morning";
			else if (shift.equalsIgnoreCase("HO"))
				temp="Holiday";
			return temp;
		}
		 public String setColor(String shift)
			{ 	String temp=null;
				if(shift.equalsIgnoreCase("G"))
					temp="\"00FF66\"";
				else if (shift.equalsIgnoreCase("M"))
					temp="\"00FFFF\"";
				else if (shift.equalsIgnoreCase("A"))
					temp="\"CC6600\"";
				else if (shift.equalsIgnoreCase("E"))
					temp="\"CCFF00\"";
				else if (shift.equalsIgnoreCase("N"))
					temp="\"#989898\"";
				else if (shift.equalsIgnoreCase("WO"))
					temp="\"FF6699\"";
				else if (shift.equalsIgnoreCase("VA"))
					temp="\"FF0000\"";
				else if (shift.equalsIgnoreCase("SL"))
					temp="\"3399FF\"";
				else if (shift.equalsIgnoreCase("OP"))
					temp="\"33FFFF\"";
				else if (shift.equalsIgnoreCase("EM"))
					temp="\"FFFF99\"";
				else if (shift.equalsIgnoreCase("HO"))
					temp="\"#E00000\"";
				else
					temp=""+shift;
				return temp;
			}
		}

