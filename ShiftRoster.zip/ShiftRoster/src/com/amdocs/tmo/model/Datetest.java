package com.amdocs.tmo.model;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class Datetest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 SimpleDateFormat formatter = new SimpleDateFormat("dd-MMM-yyyy");
		Calendar cal = Calendar.getInstance();
		    cal.add(Calendar.DATE, -1);    
		   System.out.println(formatter.format(cal.getTime()));

	}

}
