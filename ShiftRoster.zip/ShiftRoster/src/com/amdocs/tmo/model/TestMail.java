
package com.amdocs.tmo.model;
import java.util.*;

import javax.mail.*;
import javax.mail.internet.*;



public class TestMail
{
   public void sendMessage(String email_message,String subject,String[] email_id,String[] email_id_cc)
   {
      
      // Recipient's email ID needs to be mentioned.
      String to = "sahil.batra@amdocs.com";

      // Sender's email ID needs to be mentioned
      String from = "ShiftRoster@amdocs.com";

      // Assuming you are sending email from localhost
      String host = "ggnmail.corp.amdocs.com";
      System.setProperty("java.net.preferIPv4Stack" , "true");
      // Get system properties
      Properties properties = System.getProperties();
     

      // Setup mail server
      properties.setProperty("mail.smtp.host", host);

      // Get the default Session object.
      Session session = Session.getDefaultInstance(properties);
      
      

      try{
    	  
    //	  Context initCtx = new InitialContext();
     //     Context envCtx = (Context) initCtx.lookup("java:comp/env");
    //      Session session = (Session) envCtx.lookup("mail/NomDeLaRessource");
         // Create a default MimeMessage object.
         MimeMessage message = new MimeMessage(session);

         // Set From: header field of the header.
         message.setFrom(new InternetAddress(from));

         // Set To: header field of the header.
         for(int i=0;i<email_id.length;i++ ){
        	 if(!(null==email_id[i] || email_id[i].equalsIgnoreCase("")))
         message.addRecipient(Message.RecipientType.TO,
                                  new InternetAddress(email_id[i]));
         }
         for(int i=0;i<email_id_cc.length;i++ ){
        	 if(!(null==email_id_cc[i] || email_id_cc[i].equalsIgnoreCase("")))
         message.addRecipient(Message.RecipientType.CC,
                                  new InternetAddress(email_id_cc[i]));
         }
         // Set Subject: header field
         message.setSubject(subject);

         // Send the actual HTML message, as big as you like
         message.setContent(email_message,"text/html" );

         // Send message
         Transport.send(message);
         System.out.println("Sent message successfully....");
      }catch (MessagingException mex) {
         mex.printStackTrace();
      }// catch (NamingException e) {
		// TODO Auto-generated catch block
	//	e.printStackTrace();
	//}
   }
}