package com.amdocs.tmo;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.io.Writer;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class GetUserEmail {
	
	public static String getemail(String id,Connection conn)
	{String email="";
		  try { 
			  if(conn.isClosed())
			  	{
				  conn = DriverManager.getConnection("jdbc:oracle:thin:@sorabhh01v:1521/xe","system", "amdocs");
			  	}
			  Statement stmt=conn.createStatement();
			  stmt = conn.createStatement();
			  String email_to = "select email_id from test_employee_details where nt_id='"+id.toUpperCase()+"'";
			     ResultSet rs= stmt.executeQuery(email_to);
			      while(rs.next())
			      {int i=0;
			      	email=rs.getString("email_id");
			      	i++;
			      }
			      conn.close();	     
		  }
		  catch (SQLException e)
			{     e.printStackTrace(); 
			}
			 return email;	
	}

}
