package com.amdocs.tmo;

import java.io.PrintStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import com.amdocs.tmo.model.SendMail;


public class AttJewelSMS {

	/**
	 * @param args
	 */
	static String email_id[]=new String[1];
	static String email_cc[]=new String[1];
	public static void main(String[] args) {
		 SimpleDateFormat formatter = new SimpleDateFormat("dd-MMM-yyyy");
			Calendar cal = Calendar.getInstance();
			    cal.add(Calendar.DATE, +1); 
			    String dt=formatter.format(cal.getTime());
			    try { 
					  Class.forName("oracle.jdbc.driver.OracleDriver");
					  Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@sorabhh01v:1521/xe","system", "amdocs");
					  Statement stmt=conn.createStatement();
					  stmt = conn.createStatement();
					  Statement tempstmt=conn.createStatement();
					  tempstmt = conn.createStatement();
					  String sql="select distinct nt_id from test_employee_details where project='ATT-JEWEL'";
					  ResultSet rs=stmt.executeQuery(sql);
					  while(rs.next())
					  {	String shift="";
						  String ntid=rs.getString("nt_id");
				//		  email_id[0]="SMS"+ntid+"@amdocs.com";
						  String sql2="Select shift from test_shifts where DT='"+dt+"' and nt_id='"+ntid+"'";
						  ResultSet rs2=tempstmt.executeQuery(sql2);
						  while(rs2.next())
						  {
							  shift=rs2.getString("shift");
						  }
						  if(!(shift.equalsIgnoreCase("") || shift ==null))
						  { String message="Shift for "+dt+" : "+HelperClass.getDisplayName(shift, "ATT-JEWEL", conn);
						  email_id[0]="sahil.batra@amdocs.com";
						  System.out.println(email_id[0]+" "+message);
						 SendMail mail=new SendMail();
						 mail.sendMessage("", message, email_id,email_cc);
						  }
					  }
			    }
					  catch (Exception e)
				      {			
				              e.printStackTrace();
				      }        

	}

}
