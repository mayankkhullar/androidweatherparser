package com.amdocs.tmo;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.io.Writer;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.amdocs.tmo.model.SendMail;

public class GetNamesDb {
	
	public static String getNames(String ntid,Connection conn)
	{String name="";
		String lname="";
		String project="";
		int count=0;
	  try { 
		  if(conn.isClosed())
		  {
			  conn = DriverManager.getConnection("jdbc:oracle:thin:@sorabhh01v:1521/xe","system", "amdocs");
		  }
		  Statement stmt=conn.createStatement();
		  String sql="Select fname,lname,project from test_employee_details where nt_id='"+ntid+"'";
		  ResultSet rs=stmt.executeQuery(sql);
		  while(rs.next())
		  {		lname=rs.getString("lname");
			  name=rs.getString("fname");
			  project=rs.getString("project");
			  String sql1="Select count(*) from test_employee_details where fname='"+name+"' and project='"+project+"'";
			  ResultSet rs1=stmt.executeQuery(sql1);
			  while(rs1.next())
			  {
				  count=rs1.getInt(1);
			  }
			  if(count>1)
			  {
				  name=name+" "+lname.charAt(0) ;
			  }
		  }
	  } 
	  catch (SQLException e)
		{     e.printStackTrace(); 
        }
		if(name == null || ("").equalsIgnoreCase(name))
		{
			if(ntid.equalsIgnoreCase("All Team"))
			{ntid="All";}
			return ntid;
			
		}
		else
		{
		return changeCase(name);
		}
	}
	public static String getTeam(String ntid,Connection conn,String project)
	{String team="";
	  try { 
		  Statement stmt=conn.createStatement();
		  String sql="Select team from test_employee_details where nt_id='"+ntid+"' and project='"+project+"'";
		  ResultSet rs=stmt.executeQuery(sql);
		  while(rs.next())
		  {
			  team=rs.getString("team");
		  }
	  } 
	  catch (SQLException e)
		{     e.printStackTrace(); 
        }
		if(team == null || ("").equalsIgnoreCase(team))
		{
			return "";
		}
		else
		{
		return team.toUpperCase();
		}
	}
	 public static String changeCase(String message)
		{
			String temp="";
			String arr[]=message.split(" ");
			for(int i=0;i<arr.length;i++)
			{	arr[i].toLowerCase();
				String t=arr[i].toLowerCase().substring(0,1);
				String tt=t.toUpperCase();
				String qq=arr[i].toLowerCase().substring(1);
				String temp1=tt+qq;
				temp=temp+" "+temp1;
			}
			return temp;
		}

}
