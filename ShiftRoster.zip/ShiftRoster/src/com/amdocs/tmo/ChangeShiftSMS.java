package com.amdocs.tmo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import com.amdocs.tmo.model.SendMail;

public class ChangeShiftSMS {
	public void changeShiftSMS(String id,String fromdt,String todt,String shift,String team,String name,String ateam,String project)
	{
		String[] emailid=new String[100]; 
		String[] email_cc=new String[100]; 
		String[] smsemailid=new String[100]; 
		String[] smsemail_cc=new String[100]; 
		String[] test_emailid=new String[100]; 
		String[] test_email_cc=new String[100]; 
		test_emailid[0]="sahil.batra@amdocs.com";
		int day_of_week=0,day_of_week1=0;
		 String[] days={"","Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"};
		  try { 
			  Class.forName("oracle.jdbc.driver.OracleDriver");
			  Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@sorabhh01v:1521/xe","system", "amdocs");
		//	  Statement stmt=conn.createStatement();
		//	  stmt = conn.createStatement();
		//	  String userTeam=GetNamesDb.getTeam(id, conn);
		//	  String email_to = "select distinct nt_id from test_employee_details where project='"+project+"'";
		//	     ResultSet rs= stmt.executeQuery(email_to);
		//	     int i=0;
		//	     while(rs.next())
		//	      {
		//	      	email_cc[i]="SMS"+rs.getString("nt_id")+"@amdocs.com";
		//	      	i++;
		//	      }
				      SimpleDateFormat formatter = new SimpleDateFormat("dd-MMM-yyyy");
				      Date da,daa;
					try {
						da = formatter.parse(fromdt);
						 Calendar c = Calendar.getInstance();
						  	c.setTime(da);
						   day_of_week = c.get(Calendar.DAY_OF_WEEK);
						   daa = formatter.parse(todt);
							 Calendar c1 = Calendar.getInstance();
							  	c1.setTime(daa);
							   day_of_week1 = c1.get(Calendar.DAY_OF_WEEK);
					} catch (ParseException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					emailid[0]="SMS"+id+"@amdocs.com";
				      SendMail mail=new SendMail();
			//	      String temp=GetNamesDb.getNames(id, conn);
				      mail.sendMessage("", "Shift Change From Date: "+fromdt+" To Date: "+todt+" Shift: "+HelperClass.getDisplayName(shift, "ATT-JEWEL", conn),emailid,email_cc);
				      conn.close();
				      }
		  catch (SQLException e)
			{     e.printStackTrace(); 
	          }
			catch (ClassNotFoundException e)
			{     e.printStackTrace(); }
		
	}
}
