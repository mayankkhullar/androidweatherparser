package com.amdocs.tmo;
import org.springframework.stereotype.Controller;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.io.Writer;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;


import com.amdocs.tmo.model.SendMail;
@Controller
public class ReportsController {
	 @RequestMapping(value = "/reports", method = RequestMethod.POST)
	  public String reportMenu(@RequestParam("name") String name,
			  				@RequestParam("team") String team,
			  				@RequestParam("id") String id,
			  				@RequestParam("ateam") String ateam,
			  				@RequestParam("project") String project,Model model) {
		  java.util.Date date = new java.util.Date();
			model.addAttribute("team",team);
		  	model.addAttribute("ateam",ateam);
   			model.addAttribute("name",name.toString()); 
   			model.addAttribute("date",date.toString());
   			model.addAttribute("id",id);
   			model.addAttribute("project",project);
   			model.addAttribute("message","");
		 return "reports";	
	 }
	 @RequestMapping(value = "/reportconfirm", method = RequestMethod.POST)
	  public String reportGenerate(@RequestParam("name") String name,
			  				@RequestParam("team") String team,
			  				@RequestParam("id") String id,
			  				@RequestParam("mm") String mon,
			  				@RequestParam("yy") String year,
			  				@RequestParam("tm") String reportteam,
			  				@RequestParam("report") String report,
			  				@RequestParam("mail") String mail,
			  				@RequestParam("ateam") String ateam,
			  				@RequestParam("project") String project,Model model) throws ParseException {
		  java.util.Date date = new java.util.Date();
		  String team_array[]=reportteam.split("%");
		  String report_array[]=report.split("%");
		  String month=mon.substring(0, 3);
		  String email[]=new String[20];
		  String email_id[]=new String[20];
		  String email_cc[]=new String[20];
		  email_id[0]="sahil.batra@amdocs.com";
		  String sql="";
		  try{
		  for(int i=0;i<team_array.length;i++)
		  {	 if(!team_array[i].equalsIgnoreCase("")){
			  Class.forName("oracle.jdbc.driver.OracleDriver");
			  	Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@sorabhh01v:1521/xe","system", "amdocs");
			  Statement stmt=conn.createStatement();
			  stmt = conn.createStatement();
			  if(mail.equalsIgnoreCase("onlyme"))
			  {
				 sql=" select distinct email_id from test_manager where id='"+id+"' and project='"+project+"'";
			  }
			  else if(mail.equalsIgnoreCase("teamleads"))
			  {
			  sql = "select distinct email_id from test_manager where ( team='"+team_array[i]+"' or ateam='"+team_array[i]+"') and  project='"+project+"'";
			  }  
			  else if(mail.equalsIgnoreCase("allleads"))
			  {
				  sql = "select distinct email_id from test_manager where project='"+project+"'";
			  }
			  ResultSet rs= stmt.executeQuery(sql);
			     int k=0;
			     while(rs.next())
			      {
			    	 email[k]=rs.getString("email_id");
			      	k++;
			      }
			     conn.close();
			  for(int j=0;j<report_array.length;j++)
			  {	StringBuilder mailMessage= new StringBuilder();
				  if(report_array[j]!="" && report_array[j].equalsIgnoreCase("Monthly Shift Report"))
				  {
						WeeklyReport obj=new WeeklyReport();
					 	mailMessage.append(obj.generateMonthlyShifts(month,year,team_array[i],01,07,project));
						mailMessage.append(obj.generateMonthlyShifts(month,year,team_array[i],8,14,project));
						mailMessage.append(obj.generateMonthlyShifts(month,year,team_array[i],15,21,project));
						mailMessage.append(obj.generateMonthlyShifts(month,year,team_array[i],22,28,project));
						mailMessage.append(obj.generateMonthlyShifts(month,year,team_array[i],29,0,project));
				  }
				  else if(report_array[j]!="" && report_array[j].equalsIgnoreCase("Monthly Shift Count"))
				  {
					  mailMessage.append(new PerPersonShiftCountReport().perPersonReports(team_array[i], month.substring(0,3), year,project));
				  }
				  else if(report_array[j]!="" && report_array[j].equalsIgnoreCase("Weekday n Weekend Shift Count"))
				  {
					  if(project.equalsIgnoreCase("ATT-JEWEL"))
					  {
						 mailMessage.append(new ShiftCountsWeekendJewel().countShifts(month.substring(0,3), year, team_array[i],project));
					  }
					  else if(project.equalsIgnoreCase("TMO-US"))
					  {
					  mailMessage.append(new ShiftCountWeekends().countShifts(month.substring(0,3), year, team_array[i],project));
					  }
				  }
				  else if(report_array[j]!="" && report_array[j].equalsIgnoreCase("Night Shift Count"))
				  {
					  mailMessage.append(new NightShiftCount().countNightShift(month.substring(0, 3), year, team_array[i],project));
				  }
				  if(!report_array[j].equalsIgnoreCase(""))
				  new SendMail().sendMessage(mailMessage.toString(),report_array[j]+ " for team " +team_array[i], email, email_cc);
			  }
			 } 
		  }
	 }
		  catch (SQLException e)
		  {} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		  
			model.addAttribute("team",team);
		  	model.addAttribute("ateam",ateam);
  			model.addAttribute("name",name.toString()); 
  			model.addAttribute("date",date.toString());
  			model.addAttribute("id",id);
  			model.addAttribute("project",project);
  			model.addAttribute("message","Mail Sent Successfully");
		 return "reports";	
	 }
	 
}
