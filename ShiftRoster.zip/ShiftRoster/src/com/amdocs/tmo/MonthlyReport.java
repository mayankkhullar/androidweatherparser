package com.amdocs.tmo;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.io.Writer;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import com.amdocs.tmo.model.SendMail;

public class MonthlyReport {
	
	public String generateMonthlyShifts(String month,String year,String team,String project) throws ParseException
	{	String[] dates=new String[50];
		String[] nt_id=new String[100];
		String[] emailid=new String[50];
		String[] dates_day=new String[50];
		String[] email_cc=new String[50];
		StringBuilder message=new StringBuilder();
		String[] dayss={"Sun","Mon","Tues","Wed","Thur","Fri","Sat"}; 
		String[] month_array={"","Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"};
		SimpleDateFormat formatter = new SimpleDateFormat("dd-MMM-yyyy");
		 try { 
			  Class.forName("oracle.jdbc.driver.OracleDriver");
			  Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@sorabhh01v:1521/xe","system", "amdocs");
			  Statement stmt=conn.createStatement();
			  String mon="";
				 if(!month.equalsIgnoreCase("")){ mon=month.substring(0, 3);}
				 int day=HelperClass.getDays(mon,year);
				 String from_date="01-"+mon+"-"+year;
				 String to_date=day+"-"+mon+"-"+year;
			  String get_dates="select distinct dt from test_shifts where project='"+project+"' and dt > = '"+from_date+"' and dt < = '"+to_date+"' order by dt";
			  ResultSet rs_get_dates=stmt.executeQuery(get_dates);
			  message=message.append("<table border=\"1\"  class=\"fixed\"><tr><th bgcolor=\"#C0C0C0\">Name & Date</th>");
			  int days=0;
			  while(rs_get_dates.next())
			  {		java.sql.Date dt=rs_get_dates.getDate("dt");
				  Calendar c = Calendar.getInstance();
		  			c.setTime(dt);
		  			int day_of_week = c.get(Calendar.DAY_OF_WEEK);
		  			dates_day[days]=dayss[day_of_week - 1];
				  	String temp=rs_get_dates.getString("dt").substring(5,7);
		  			String m=month_array[Integer.parseInt(temp)];
		  			String tempp=rs_get_dates.getString("dt").substring(8, 10);
		  			tempp= tempp+"-"+m;
				  dates[days]=tempp;
				  message=message.append("<th bgcolor=\"#C0C0C0\">"+dates[days]+"</th>");
				  days++;
			  }
			//  message=message.append("<th bgcolor=\"#C0C0C0\">Update</th>");
			  message=message.append("</tr><tr><th bgcolor=#C0C0C0>Days</th>");
			  for(int i=0;i<days;i++)
			  {
				  message=message.append("<th bgcolor=\"#C0C0C0\">"+dates_day[i]+"</th>");
			  }
			//  message=message.append("<th bgcolor=\"#C0C0C0\">Update</th>");
			  String get_nt_id="";
			  if(team.equalsIgnoreCase("ALL"))
			  {
				  get_nt_id="select distinct nt_id from test_shifts where shift is not null and dt >='"+from_date+"' and project='"+project+"' order by nt_id"; 
			  }
			  else
			  {	  
			  get_nt_id="select distinct nt_id from test_shifts where team='"+team+"' and dt >='"+from_date+"' and project='"+project+"' order by nt_id ";
			  }
			  ResultSet rs_get_nt_id=stmt.executeQuery(get_nt_id);
			  int count=0;
			  while(rs_get_nt_id.next())
			  {
				  nt_id[count]=rs_get_nt_id.getString("nt_id");
				  count++;  
			  }
			  for(int i=0;i<count;i++)
			  {
				  message=message.append("<tr><td bgcolor=\"#C0C0C0\">"+GetNamesDb.getNames(nt_id[i],conn)+"</td>");
				  	for(int k=0;k<days;k++)
				  	{
				  		String get_shift="select shift from test_shifts where nt_id='"+nt_id[i]+"' and dt='"+dates[k]+"-"+year+"'";
				  		System.out.println(get_shift);
				  		ResultSet rs_get_shift=stmt.executeQuery(get_shift);
				  		if(rs_get_shift.next())
				  		{String temp=rs_get_shift.getString("shift");
				  			message=message.append("<td bgcolor="+HelperClass.getColor(temp, project, conn)+">"+temp+"</td>");
				  		}
				  		else
				  		{
				  			message=message.append("<td></td>");
				  		}
				  	}
			//	  	message=message.append("<td><form action=\"updateshift.html\" method=\"post\">");
			//	  	message=message.append("<input type=\"hidden\" name=\"userid\" value="+"\""+nt_id[i]+"\">");
			//	  	message=message.append("<input type=\"hidden\" name=\"from\" value="+"\""+from_date+"\">");
			//	  	message=message.append("<input type=\"hidden\" name=\"to\" value="+"\""+to_date+"\">");
			//	  	message=message.append("<input type=\"hidden\" name=\"project\" value="+"\""+project+"\">");
			//	  	message=message.append("<input type=\"submit\" value=\"Update\"></form></td>");
				  	message=message.append("</tr>"); 
				 
			  }
			  message=message.append("</table>");  
	//		  emailid[0]="Sahil.batra@amdocs.com";
	//		  SendMail mail=new SendMail();
	//	      mail.sendMessage("<Html><body>Hi&nbsp;Team,<br><br>Please find below the monthly shifts<br><br>"+message.toString()+"<br><br>Thank You<br><br><br><br><br>This is auto generated message . Plase do not reply.", "Shift Schedule for Current Month",emailid,email_cc);  
			  
			  conn.close(); 
		 } 
		  catch (SQLException e)
			{     e.printStackTrace(); 
	          }
			catch (ClassNotFoundException e)
			{     e.printStackTrace(); 
	          }
			 return message.toString();
	}
	public String generateMonthlyShiftsManager(String id,String month,String year,String team,String project) throws ParseException
	{	String[] dates=new String[50];
		String[] nt_id=new String[100];
		String[] emailid=new String[50];
		String[] dates_day=new String[50];
		String[] email_cc=new String[50];
		StringBuilder message=new StringBuilder();
		String[] dayss={"Sun","Mon","Tues","Wed","Thur","Fri","Sat"}; 
		String[] month_array={"","Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"};
		SimpleDateFormat formatter = new SimpleDateFormat("dd-MMM-yyyy");
		 try { 
			  Class.forName("oracle.jdbc.driver.OracleDriver");
			  Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@sorabhh01v:1521/xe","system", "amdocs");
			  Statement stmt=conn.createStatement();
			  String mon="";
				 if(!month.equalsIgnoreCase("")){ mon=month.substring(0, 3);}
				 int day=HelperClass.getDays(mon,year);
				 String from_date="01-"+mon+"-"+year;
				 String to_date=day+"-"+mon+"-"+year;
			  String get_dates="select distinct dt from test_shifts where project='"+project+"' and dt > = '"+from_date+"' and dt < = '"+to_date+"' order by dt";
			  ResultSet rs_get_dates=stmt.executeQuery(get_dates);
			  message=message.append("<table border=\"1\"  class=\"fixed\"><tr><th bgcolor=\"#C0C0C0\">Name & Date</th>");
			  int days=0;
			  while(rs_get_dates.next())
			  {		java.sql.Date dt=rs_get_dates.getDate("dt");
				  Calendar c = Calendar.getInstance();
		  			c.setTime(dt);
		  			int day_of_week = c.get(Calendar.DAY_OF_WEEK);
		  			dates_day[days]=dayss[day_of_week - 1];
				  	String temp=rs_get_dates.getString("dt").substring(5,7);
		  			String m=month_array[Integer.parseInt(temp)];
		  			String tempp=rs_get_dates.getString("dt").substring(8, 10);
		  			tempp= tempp+"-"+m;
				  dates[days]=tempp;
				  message=message.append("<th bgcolor=\"#C0C0C0\">"+dates[days]+"</th>");
				  days++;
			  }
			  message=message.append("<th bgcolor=\"#C0C0C0\">Update</th>");
			  message=message.append("</tr><tr><th bgcolor=#C0C0C0>Days</th>");
			  for(int i=0;i<days;i++)
			  {
				  message=message.append("<th bgcolor=\"#C0C0C0\">"+dates_day[i]+"</th>");
			  }
			  message=message.append("<th bgcolor=\"#C0C0C0\">Update</th>");
			  String get_nt_id="";
			  if(team.equalsIgnoreCase("ALL"))
			  {
				  get_nt_id="select distinct nt_id from test_shifts where shift is not null and dt >='"+from_date+"' and project='"+project+"' order by nt_id"; 
			  }
			  else
			  {	  
			  get_nt_id="select distinct nt_id from test_shifts where team='"+team+"' and dt >='"+from_date+"' and project='"+project+"' order by nt_id ";
			  }
			  ResultSet rs_get_nt_id=stmt.executeQuery(get_nt_id);
			  int count=0;
			  while(rs_get_nt_id.next())
			  {
				  nt_id[count]=rs_get_nt_id.getString("nt_id");
				  count++;  
			  }
			  for(int i=0;i<count;i++)
			  {
				  message=message.append("<tr><td bgcolor=\"#C0C0C0\">"+GetNamesDb.getNames(nt_id[i],conn)+"</td>");
				  	for(int k=0;k<days;k++)
				  	{
				  		String get_shift="select shift from test_shifts where nt_id='"+nt_id[i]+"' and dt='"+dates[k]+"-"+year+"'";
				  		System.out.println(get_shift);
				  		ResultSet rs_get_shift=stmt.executeQuery(get_shift);
				  		if(rs_get_shift.next())
				  		{String temp=rs_get_shift.getString("shift");
				  			message=message.append("<td bgcolor="+HelperClass.getColor(temp, project, conn)+">"+temp+"</td>");
				  		}
				  		else
				  		{
				  			message=message.append("<td></td>");
				  		}
				  	}
				  	message=message.append("<td><form action=\"updateshift.html\" method=\"post\" target=\"_blank\">");
				  	message=message.append("<input type=\"hidden\" name=\"id\" value="+"\""+id+"\">");
				  	message=message.append("<input type=\"hidden\" name=\"userid\" value="+"\""+nt_id[i]+"\">");
				  	message=message.append("<input type=\"hidden\" name=\"from\" value="+"\""+from_date+"\">");
				  	message=message.append("<input type=\"hidden\" name=\"to\" value="+"\""+to_date+"\">");
				  	message=message.append("<input type=\"hidden\" name=\"project\" value="+"\""+project+"\">");
				  	message=message.append("<input type=\"submit\" value=\"Update\"></form></td>");
				  	message=message.append("</tr>"); 
				 
			  }
			  message=message.append("</table>");  
	//		  emailid[0]="Sahil.batra@amdocs.com";
	//		  SendMail mail=new SendMail();
	//	      mail.sendMessage("<Html><body>Hi&nbsp;Team,<br><br>Please find below the monthly shifts<br><br>"+message.toString()+"<br><br>Thank You<br><br><br><br><br>This is auto generated message . Plase do not reply.", "Shift Schedule for Current Month",emailid,email_cc);  
			  
			  conn.close(); 
		 } 
		  catch (SQLException e)
			{     e.printStackTrace(); 
	          }
			catch (ClassNotFoundException e)
			{     e.printStackTrace(); 
	          }
			 return message.toString();
	}
	 public static void main(String args[]) throws ParseException
	 {
		 MonthlyReport mm=new MonthlyReport();
	//	String message=mm.generateMonthlyShifts("Apr","2014","INFRA-JEWEL","ATT-JEWEL");
	 }

}
