package com.amdocs.tmo;

import java.io.PrintStream;

import org.springframework.mail.MailMessage;

import com.sun.mail.smtp.SMTPTransport;

import sun.net.smtp.SmtpClient;
 
public class TestMail {
 
	public static void main(String[] args) {
 try{
        SmtpClient client = new SmtpClient("TLV.amdocs.com");
        System.out.println("sahil.batra@amdocs.com");
        client.from("Sahil.batra@amdocs.com");
        client.to("sahil.batra@amdocs.com");
        PrintStream message = client.startMessage();
       message.println("To: sahil.batra@amdocs.com");
       message.println("Subject: Test");
        message.println();
        message.println("<html><body><b><u>============This is Auto Generated Mail=============</u></b></body></html>");
        message.println("<br>my name is sahil</br>");
        client.closeServer();
        }catch(Exception e)
        {
               System.out.println("Mail Sent"+e);
        }
        System.out.println("Mail Sent");

}
}