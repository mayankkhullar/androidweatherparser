package com.amdocs.tmo;
import org.springframework.stereotype.Controller;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.io.Writer;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.amdocs.tmo.model.SendMail;
@Controller
public class DeleteuserController {
 @RequestMapping(value = "/deleteconfirm", method = RequestMethod.POST)
  public String myShift(@RequestParam("name") String name,
		  				@RequestParam("team") String team,
		  				@RequestParam("ateam") String ateam,
		  				@RequestParam("id") String id,
		  				@RequestParam("empid") String ntid,
		  				@RequestParam("project") String project,
		  				Model model) {
	 boolean flag=true;
	 DateFormat dateFormat = new SimpleDateFormat("MMMM dd yyyy");
	  java.util.Date date = new java.util.Date();
	  if(("").equals(ntid))
	  {
		flag=false;
	  }
	  try {if(flag) {
		  Class.forName("oracle.jdbc.driver.OracleDriver");
		  Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@sorabhh01v:1521/xe","system", "amdocs");
		  if(conn !=null)
		  {	
			  System.out.println("connected to database");
			  Statement stmt;
			  stmt = conn.createStatement();

		      String sql = "delete from test_employee_details where nt_id='"+ntid.toUpperCase()+"' and project='"+project+"'";
		      stmt.executeUpdate(sql);
		      String sql_manager="delete from test_manager where id='"+ntid.toUpperCase()+"' and project='"+project+"'";
		      stmt.executeUpdate(sql_manager);
		  
		  
			  }
			conn.close();  
	  }
		      }
		      catch (Exception e)
		      {			
		              e.printStackTrace();
		      }
		  	model.addAttribute("team",team);
		  	model.addAttribute("ateam",ateam);
   			model.addAttribute("name",name.toString()); 
   			model.addAttribute("date",date.toString());
   			model.addAttribute("id",id);
   			model.addAttribute("project",project);
			model.addAttribute("message","User Deleted Successfully");
	if(flag)
	{
	 return "addconfirm";
	}
	else
	{
		return "adduser";
	}
}
}