package com.amdocs.tmo;
import org.springframework.stereotype.Controller;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.io.Writer;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;


import com.amdocs.tmo.model.SendMail;
@Controller
public class AdduserController {
	
 @RequestMapping(value = "/addconfirm", method = RequestMethod.POST)
  public String myShift(@RequestParam("name") String name,
		  				@RequestParam("team") String team,
		  				@RequestParam("ateam") String ateam,
		  				@RequestParam("id") String id,
		  				@RequestParam("fname") String fname,
		  				@RequestParam("lname") String lname,
		  				@RequestParam("email") String email,
		  				@RequestParam("ntid") String ntid,
		  				@RequestParam("teamnm") String teamname,
		  				@RequestParam("ateamnm") String ateamname,
		  				@RequestParam("empid") String empid,
		  				@RequestParam("role") String role,
		  				@RequestParam("project") String project,
		  				Model model) {
	 boolean flag=true;
	 String[] emailid=new String[100]; 
		String[] email_cc=new String[100]; 
	 DateFormat dateFormat = new SimpleDateFormat("MMMM dd yyyy");
	  java.util.Date date = new java.util.Date();
	  if(("").equals(fname) || ("").equals(lname) || ("").equals(email)||("").equals(ntid) ||("Select").equals(teamname) || ("").equals(empid)|| ("Select").equals(role))
	  {
		flag=false;
	  }
	  try {if(flag) {
		  Class.forName("oracle.jdbc.driver.OracleDriver");
		  Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@sorabhh01v:1521/xe","system", "amdocs");
		  if(conn !=null)
		  {		if("Select".equalsIgnoreCase(ateamname))
		  		{
			  ateamname="";
		  		}
			  
			  System.out.println("connected to database");
			  Statement stmt;
			  stmt = conn.createStatement();
			  if(role.equalsIgnoreCase("Lead\\Manager"))
			  {
				  String sql="insert into test_manager values('"+ntid.toUpperCase()+"','N','"+teamname.toUpperCase()+"','"+ateamname.toUpperCase()+"','"+email.toUpperCase()+"','"+project+"')";
				  stmt.executeUpdate(sql);
			  }
		      String sql = "insert into test_employee_details values("+Integer.parseInt(empid)+",'"+fname.toUpperCase()+"','"+lname.toUpperCase()+"','"+email.toUpperCase()+"','"+ntid.toUpperCase()+"','"+teamname.toUpperCase()+"','"+ateamname.toUpperCase()+"','"+project+"')";
		      stmt.executeUpdate(sql);
		      String email_sql = "select distinct email_id from test_manager where (team='"+teamname.toUpperCase()+"' or ateam='"+teamname.toUpperCase()+"') and id !='"+ntid.toUpperCase()+"'";
		     ResultSet rs= stmt.executeQuery(email_sql);
		     int i=0;
		      while(rs.next())
		      {
		      	email_cc[i]=rs.getString("email_id");
		      	i++;
		      }
		      emailid[0]=email;
		      SendMail mail=new SendMail();
		      mail.sendMessage("<Html><body>Hi&nbsp;"+fname+",<br><br>You can access shift roster now<br><br> <b>The link is http://sorabhh01v:6060/Shifts/index.jsp.</b><br><br>Thank You<br><br><br><br><br>This is auto generated message . Please do not reply.", "Shift Roster Access",emailid,email_cc);
			  }
			conn.close();  
	  }
		      }
		      catch (Exception e)
		      {			
		              e.printStackTrace();
		          System.out.println("exc");
		          flag=false;
		      }
		  	model.addAttribute("team",team);
		  	model.addAttribute("ateam",ateam);
   			model.addAttribute("name",name.toString()); 
   			model.addAttribute("date",date.toString());
   			model.addAttribute("id",id);
			model.addAttribute("message","User Added");
			model.addAttribute("project",project);
	if(flag)
	{
	 return "addconfirm";
	}
	else
	{
		return "adduser";
	}
}
}