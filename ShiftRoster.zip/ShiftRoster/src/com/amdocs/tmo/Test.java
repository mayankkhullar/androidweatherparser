package com.amdocs.tmo;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.io.Writer;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.amdocs.tmo.model.SendMail;


class Test{
	public void update_db(String file_path) throws ParseException
	{
	try {           FileInputStream file = new FileInputStream(new File(file_path));          
	//Get the workbook instance for XLS file    
	XSSFWorkbook workbook = new XSSFWorkbook(file); 
	int count=0;
	String[] months = {"","Jan", "Feb","Mar", "Apr", "May", "Jun", "Jul","Aug", "Sep", "Oct", "Nov","Dec"};
	  Class.forName("oracle.jdbc.driver.OracleDriver");
	Class.forName("oracle.jdbc.driver.OracleDriver");
	  Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@sorabhh01v:1521/xe","system", "amdocs");
	  Statement stmt=conn.createStatement();
	  stmt = conn.createStatement();
	  
	//Get first sheet from the workbook  
	XSSFSheet sheet = workbook.getSheetAt(0);  
	//Iterate through each rows from first sheet   
	Iterator<Row> rowIterator = sheet.iterator(); 

		Row row = rowIterator.next();
		SimpleDateFormat format2 = new SimpleDateFormat("dd-MMM-yy");

	
		int length= sheet.getLastRowNum();
		for ( int i=1; i<=length;i++)
			
		{	
			
			for(int j=3;j < sheet.getRow(0).getLastCellNum();j++ )
		{
			Cell cell=null;
			if(null != sheet.getRow(i) && null !=sheet.getRow(i).getCell(0) )
			cell=sheet.getRow(i).getCell(0);
			if(null == cell || null == cell.getStringCellValue())
			{
				break;
			}
			String id=cell.getStringCellValue().replaceAll("\\p{Z}","");
			cell=sheet.getRow(i).getCell(1);
			if(null == cell || null == cell.getStringCellValue())
			{
				break;
			}
			String team=cell.getStringCellValue().replaceAll("\\p{Z}","");
			if(null != sheet.getRow(i) && null !=sheet.getRow(i).getCell(0) )
				cell=sheet.getRow(i).getCell(2);
			if(null == cell || null == cell.getStringCellValue())
			{
				break;
			}
			String project=cell.getStringCellValue().replaceAll("\\p{Z}","");
			
			cell= sheet.getRow(0).getCell(j);
			if(null == cell || null == cell.getDateCellValue())
			{
				break;
			}
			String dateStr = cell.getDateCellValue().toString();
			DateFormat formatter = new SimpleDateFormat("E MMM dd HH:mm:ss Z yyyy");
			Date date = (Date)formatter.parse(dateStr);
			System.out.println(date);        
			Calendar cal = Calendar.getInstance();
			cal.setTime(date);
			String formatedDate = cal.get(Calendar.DATE) +"-"+ months[(cal.get(Calendar.MONTH) + 1)] + "-" +         cal.get(Calendar.YEAR);
	//		System.out.println("formatedDate : " + formatedDate); 
			//String date = cell.getDateCellValue().toString().replaceAll("\\p{Z}","");
		//	Date date = format2.parse(cell.getDateCellValue().toString());
			cell= sheet.getRow(i).getCell(j);
			if(null == cell || null == cell.getStringCellValue())
			{
				break;
			}
			String shift=cell.getStringCellValue().replaceAll("\\p{Z}","");
			String sql_search ="Select count(*) from test_shifts where nt_id ='"+id.toUpperCase().trim()+"' and team ='"+team.toUpperCase().trim()+"' and DT='"+formatedDate+"'";
			String sql="insert into test_shifts values('"+id.toUpperCase().trim()+"','"+team.toUpperCase().trim()+"',to_date('"+formatedDate+"','dd-mon-yy'),'"+shift.toUpperCase().trim()+"','"+project+"')";
			System.out.println(sql);
			ResultSet rs=stmt.executeQuery(sql_search);
			while(rs.next())
			{
				count=rs.getInt(1);
			}
			if(count==1)
			{
				String sql_update="update test_shifts set shift='"+shift.toUpperCase().trim()+"' where nt_id ='"+id.toUpperCase().trim()+"' and team ='"+team.toUpperCase().trim()+"' and DT='"+formatedDate+"'";
				System.out.println(sql_update);
				rs=stmt.executeQuery(sql_update);
			}
			else
			{
				rs=stmt.executeQuery(sql);
			}

		}
			
		}
  
	file.close();     
	conn.close();
	} catch (FileNotFoundException ee)
	{     ee.printStackTrace(); }
	catch (IOException e)
	{     e.printStackTrace(); 
	Writer writer = new StringWriter();
    PrintWriter printWriter = new PrintWriter(writer);
    e.printStackTrace(printWriter);
    String s = writer.toString();
    SendMail m=new SendMail();
    String[] ee=new String[1];
    String[] ec=new String[0];
    ee[0]="Sahil.batra@amdocs.com";
    m.sendMessage(s,"Error Report", ee, ec);
    } 
	catch (SQLException e)
	{     e.printStackTrace();
	Writer writer = new StringWriter();
    PrintWriter printWriter = new PrintWriter(writer);
    e.printStackTrace(printWriter);
    String s = writer.toString();
    SendMail m=new SendMail();
    String[] ee=new String[1];
    String[] ec=new String[0];
    ee[0]="Sahil.batra@amdocs.com";
    m.sendMessage(s,"Error Report", ee, ec);
    }
	catch (ClassNotFoundException e)
	{     e.printStackTrace(); 
	Writer writer = new StringWriter();
    PrintWriter printWriter = new PrintWriter(writer);
    e.printStackTrace(printWriter);
    String s = writer.toString();
    SendMail m=new SendMail();
    String[] ee=new String[1];
    String[] ec=new String[0];
    ee[0]="Sahil.batra@amdocs.com";
    m.sendMessage(s,"Error Report", ee, ec);
    }
	}
	}

