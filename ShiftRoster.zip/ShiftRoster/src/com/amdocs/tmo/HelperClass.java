package com.amdocs.tmo;

import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import java.sql.Connection;

public class HelperClass {
	
	public static String getInTime(String shift,String project,Connection conn)
	{String intime="";
	  try { 
		  if(conn.isClosed())
		  {
			  conn = DriverManager.getConnection("jdbc:oracle:thin:@sorabhh01v:1521/xe","system", "amdocs");
		  }
		  Statement stmt=conn.createStatement();
		  String sql="Select in_time from test_shift_details where display_value='"+shift+"' and project='"+project+"'";
		  ResultSet rs=stmt.executeQuery(sql);
		  while(rs.next())
		  {
			  intime=rs.getString("in_time");
		  }
	  } 
	  catch (SQLException e)
		{     e.printStackTrace(); 
        }
		return intime;
	}
	public static String getOutTime(String shift,String project,Connection conn)
	{String outtime="";
	  try { 
		  if(conn.isClosed())
		  {
			  conn = DriverManager.getConnection("jdbc:oracle:thin:@sorabhh01v:1521/xe","system", "amdocs");
		  }
		  Statement stmt=conn.createStatement();
		  String sql="Select out_time from test_shift_details where display_value='"+shift+"' and project='"+project+"'";
		  ResultSet rs=stmt.executeQuery(sql);
		  while(rs.next())
		  {
			  outtime=rs.getString("out_time");
		  }
	  } 
	  catch (SQLException e)
		{     e.printStackTrace(); 
        }
		return outtime;
	}
	public static String getColor(String shift,String project,Connection conn)
	{String color="";
	  try { 
		  if(conn.isClosed())
		  {
			  conn = DriverManager.getConnection("jdbc:oracle:thin:@sorabhh01v:1521/xe","system", "amdocs");
		  }
		  Statement stmt=conn.createStatement();
		  String sql="Select colour from test_shift_details where display_value='"+shift+"' and project='"+project+"'";
		  ResultSet rs=stmt.executeQuery(sql);
		  while(rs.next())
		  {
			  color=rs.getString("colour");
		  }
	  } 
	  catch (SQLException e)
		{     e.printStackTrace();
        }
		return color;
	}
	public static String getDisplayName(String shift,String project,Connection conn)
	{String color="";
	  try { 
		  if(conn.isClosed())
		  {
			  conn = DriverManager.getConnection("jdbc:oracle:thin:@sorabhh01v:1521/xe","system", "amdocs");
		  }
		  Statement stmt=conn.createStatement();
		  String sql="Select display_name from test_shift_details where display_value='"+shift+"' and project='"+project+"'";
		  ResultSet rs=stmt.executeQuery(sql);
		  while(rs.next())
		  {
			  color=rs.getString("display_name");
		  }
	  } 
	  catch (SQLException e)
		{     e.printStackTrace(); 
        }
		return color;
	}

	public static String setShift(String shift)
	{ 	String temp=null;
		if(shift.equalsIgnoreCase("G"))
			temp="General";
		else if (shift.equalsIgnoreCase("M"))
			temp="Morning";
		else if (shift.equalsIgnoreCase("A"))
			temp="Afternoon";
		else if (shift.equalsIgnoreCase("E"))
			temp="Evening";
		else if (shift.equalsIgnoreCase("N"))
			temp="Night";
		else if (shift.equalsIgnoreCase("WO"))
			temp="WeekOff";
		else if (shift.equalsIgnoreCase("VA"))
			temp="Vacation";
		else if (shift.equalsIgnoreCase("SL"))
			temp="Sickleave";
		else if (shift.equalsIgnoreCase("OP"))
			temp="OptionalOff";
		else if (shift.equalsIgnoreCase("EM"))
			temp="EarlyMorning";
		else if (shift.equalsIgnoreCase("HO"))
			temp="Holiday";
		else if (shift.equalsIgnoreCase("WE"))
			temp="WeekendGeneral";
		return temp;
	}
	public static int search(String shift)
	{int index=0;
	if(shift.equalsIgnoreCase("EM"))
		index=0;
	else if (shift.equalsIgnoreCase("M"))
		index=1;
	else if (shift.equalsIgnoreCase("A"))
		index=4;
	else if (shift.equalsIgnoreCase("E"))
		index=2;
	else if (shift.equalsIgnoreCase("N"))
		index=5;
	else if (shift.equalsIgnoreCase("WO"))
		index=6;
	else if (shift.equalsIgnoreCase("VA"))
		index=7;
	else if (shift.equalsIgnoreCase("SL"))
		index=8;
	else if (shift.equalsIgnoreCase("OP"))
		index=9;
	else if (shift.equalsIgnoreCase("HO"))
		index=10;
	else if (shift.equalsIgnoreCase("G"))
		index=3;
	else if (shift.equalsIgnoreCase("WE"))
		index=11;
	return index;
		
		
	}
	public static int getDays(String month,String year)
	{int days=0;
	if(month.equalsIgnoreCase("jan") || month.equalsIgnoreCase("mar") || month.equalsIgnoreCase("may") || month.equalsIgnoreCase("jul") || month.equalsIgnoreCase("aug") || month.equalsIgnoreCase("oct") || month.equalsIgnoreCase("dec"))
		days=31;
	else if(month.equalsIgnoreCase("apr") || month.equalsIgnoreCase("jun") || month.equalsIgnoreCase("sep") || month.equalsIgnoreCase("nov"))
		days=30;
	else if(month.equalsIgnoreCase("feb"))
	{ int yr=Integer.parseInt(year);
		if( (yr % 4 == 0) && (yr % 100 != 0) || (yr % 400 == 0))
		{
			days=29;
		}
		else
		{
			days=28;
		}
	}
	return days;	
	}
	 public static String setColor(String shift)
		{ 	String temp="white";
			if(shift.equalsIgnoreCase("G"))
				temp="\"00FF66\"";
			else if (shift.equalsIgnoreCase("M"))
				temp="\"00FFFF\"";
			else if (shift.equalsIgnoreCase("A"))
				temp="\"CC6600\"";
			else if (shift.equalsIgnoreCase("E"))
				temp="\"CCFF00\"";
			else if (shift.equalsIgnoreCase("N"))
				temp="\"989898\"";
			else if (shift.equalsIgnoreCase("WO"))
				temp="\"FFCCFF\"";
			else if (shift.equalsIgnoreCase("VA"))
				temp="\"FF0000\"";
			else if (shift.equalsIgnoreCase("SL"))
				temp="\"3399FF\"";
			else if (shift.equalsIgnoreCase("OP"))
				temp="\"33FFFF\"";
			else if (shift.equalsIgnoreCase("EM"))
				temp="\"FFFF99\"";
			else if (shift.equalsIgnoreCase("HO"))
				temp="\"FF6633\"";
			else if (shift.equalsIgnoreCase("WE"))
				temp="\"00FF66\"";
			else
				temp=""+shift;
			return temp;
		}
	 public static String changeCase(String message)
		{
			String temp="";
			String arr[]=message.split(" ");
			for(int i=0;i<arr.length;i++)
			{	arr[i].toLowerCase();
				String t=arr[i].toLowerCase().substring(0,1);
				String tt=t.toUpperCase();
				String qq=arr[i].toLowerCase().substring(1);
				String temp1=tt+qq;
				temp=temp+" "+temp1;
			}
			return temp;
		}
}
