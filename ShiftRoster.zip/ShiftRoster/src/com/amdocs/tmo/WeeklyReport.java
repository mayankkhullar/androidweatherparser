package com.amdocs.tmo;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.io.Writer;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;


import com.amdocs.tmo.model.SendMail;

public class WeeklyReport {
	
	public StringBuilder generateMonthlyShifts(String month,String year,String team,int from_day,int to_day,String project) throws ParseException
	{	String[] dates=new String[50];
		String[] dates_day=new String[50];
		String[] nt_id=new String[100];
		String[] emailid=new String[50];
		String[] email_cc=new String[50];
		String to_date;
		StringBuilder message=new StringBuilder();
		String[] dayss={"Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"};
		 String[] month_array={"","Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"};
		SimpleDateFormat formatter = new SimpleDateFormat("dd-MMM-yyyy");
		 try { 
			  Class.forName("oracle.jdbc.driver.OracleDriver");
			  Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@sorabhh01v:1521/xe","system", "amdocs");
			  Statement stmt=conn.createStatement();
			  String mon="";
				 if(!month.equalsIgnoreCase("")){ mon=month.substring(0, 3);}
				 int day=HelperClass.getDays(mon,year);
				 String from_date=from_day+"-"+mon+"-"+year;
				 Calendar from = Calendar.getInstance();
				 from.set(Integer.parseInt(year), getIndex(mon),from_day);
				 int day_week = from.get(Calendar.DAY_OF_WEEK);
				 day_week=day_week -1;
				 if(day_week>0){
				 from.add(Calendar.DATE, -day_week);
				 }
				 from_date=from.get(Calendar.DATE)+"-"+month_array[from.get(Calendar.MONTH)+1]+"-"+from.get(Calendar.YEAR);
				if(day!=to_day){ 
				 if(to_day==0)
				 {
					 to_date=day+"-"+mon+"-"+year; 
					 
				 }
				 else
				 {
					 to_date=to_day+"-"+mon+"-"+year;
					 Calendar to = Calendar.getInstance();
					 to.set(Integer.parseInt(year), getIndex(mon),to_day);
					 if(day_week>0){
						 to.add(Calendar.DATE, -day_week);
						 }
					 to_date=to.get(Calendar.DATE)+"-"+month_array[to.get(Calendar.MONTH)+1]+"-"+to.get(Calendar.YEAR);
				 }
			  String get_dates="select distinct dt from test_shifts where dt > = '"+from_date+"' and dt < = '"+to_date+"' and project='"+project+"' order by dt";
			  ResultSet rs_get_dates=stmt.executeQuery(get_dates);
			  message=message.append("<br><h4>Shifts From : "+from_date+" to "+to_date+"</h4><br><table width=\"50%\" border=\"1\"><tr><th bgcolor=\"#C0C0C0\">Name & Date</th>");
			  int days=0;
			  while(rs_get_dates.next())
			  {		java.sql.Date dt=rs_get_dates.getDate("dt");
			  		Calendar c = Calendar.getInstance();
			  		c.setTime(dt);
			  		int day_of_week = c.get(Calendar.DAY_OF_WEEK);
			  		dates_day[days]=dayss[day_of_week - 1];
			  		String temp=dt.toString().substring(5,7);
				 // 	String temp=rs_get_dates.getString("dt").substring(5,7);
		  			String m=month_array[Integer.parseInt(temp)];
		  			String tempp=dt.toString().substring(8, 10);
		  		//	String tempp=rs_get_dates.getString("dt").substring(8, 10);
		  			tempp= tempp+"-"+m;
				  dates[days]=tempp;
				  message=message.append("<th bgcolor=\"#C0C0C0\">"+dates[days]+"</th>");
				  days++;
			  }
			  message=message.append("</tr><tr><th bgcolor=#C0C0C0>Days</th>");
			  for(int i=0;i<days;i++)
			  {
				  message=message.append("<th bgcolor=\"#C0C0C0\">"+dates_day[i]+"</th>");
			  }
			  message=message.append("</tr>");
			  String get_nt_id="";
			  if(team.equalsIgnoreCase("ALL"))
			  {
				  get_nt_id="select distinct nt_id from test_shifts where shift is not null and dt >='"+from_date+"' and project='"+project+"' order by nt_id"; 
			  }
			  else
			  {	  
			  get_nt_id="select distinct nt_id from test_shifts where team='"+team+"' and dt >='"+from_date+"' and project='"+project+"' order by nt_id ";
			  }
			  ResultSet rs_get_nt_id=stmt.executeQuery(get_nt_id);
			  int count=0;
			  while(rs_get_nt_id.next())
			  {
				  nt_id[count]=rs_get_nt_id.getString("nt_id");
				  count++;  
			  }
			  for(int i=0;i<count;i++)
			  {
				  message=message.append("<tr><th bgcolor=\"#C0C0C0\">"+GetNamesDb.getNames(nt_id[i],conn)+"</th>");
				  	for(int k=0;k<days;k++)
				  	{
				  		String get_shift="select shift from test_shifts where nt_id='"+nt_id[i]+"' and dt='"+dates[k]+"-"+year+"'";
				  		ResultSet rs_get_shift=stmt.executeQuery(get_shift);
				  		if(rs_get_shift.next())
				  		{String temp=rs_get_shift.getString("shift");
				  			message=message.append("<th bgcolor="+HelperClass.getColor(temp, project, conn)+">"+HelperClass.getDisplayName(temp, project, conn)+"</th>");
				  		}
				  		else
				  		{
				  			message=message.append("<th></th>");
				  		}
				  	}
				  	message=message.append("</tr>");  
			  }
			  message=message.append("</table>");  
		//	  emailid[0]="Sahil.batra@amdocs.com";
		//	  SendMail mail=new SendMail();
		 //     mail.sendMessage("<Html><body>Hi&nbsp;Team,<br><br>Please find below the tomorrow shifts<br><br>"+message.toString()+"<br><br>Thank You<br><br><br><br><br>This is auto generated message . Pelase do not reply.", "Shift Schedule for Current Month",emailid,email_cc);  
				} 
			  conn.close(); 
		 } 
		  catch (SQLException e)
			{     e.printStackTrace(); 
	          }
			catch (ClassNotFoundException e)
			{     e.printStackTrace(); 
	          }
			 return message;
	}
	public int getIndex(String mon)
	{int index=0;
		 String[] month_array={"","Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"};
		 for(int i=0;i<=month_array.length;i++)
		 {
			 if(mon.equalsIgnoreCase(month_array[i]))
			 {
				 index=i;
				 break;
			 }
		 }
		 index=index -1;
		 return index;
	}
	 /*public static void main(String args[]) throws ParseException
	 {String[] emailid=new String[50];
		String[] email_cc=new String[50];
		 StringBuilder mailMessage= new StringBuilder();
		 WeeklyReport obj=new WeeklyReport();
		mailMessage.append(obj.generateMonthlyShifts("Mar","2014","CM",01,07,"TMO-US"));
		mailMessage.append(obj.generateMonthlyShifts("Mar","2014","CM",8,14,"TMO-US"));
		mailMessage.append(obj.generateMonthlyShifts("Mar","2014","CM",15,21,"TMO-US"));
		mailMessage.append(obj.generateMonthlyShifts("Mar","2014","CM",22,28,"TMO-US"));
		mailMessage.append(obj.generateMonthlyShifts("Mar","2014","CM",29,0,"TMO-US"));
		  emailid[0]="Sahil.batra@amdocs.com";
		  SendMail mail=new SendMail();
	     mail.sendMessage("<Html><body>Hi&nbsp;Team,<br><br>Please find below the shifts<br><br>"+mailMessage.toString()+"<br><br>Thank You<br><br><br><br><br>This is auto generated message . Pelase do not reply.", "Shift Schedule for Current Month",emailid,email_cc);  
		
		 
	 }*/

}
