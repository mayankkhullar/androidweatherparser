package com.amdocs.tmo;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.io.Writer;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.amdocs.tmo.model.SendMail;

public class GetNames {
	
	public static String getNames11(String ntid )
	{String name="";
	  try { 
		  Class.forName("oracle.jdbc.driver.OracleDriver");
		  Connection conn1 = DriverManager.getConnection("jdbc:oracle:thin:@sorabhh01v:1521/xe","system", "amdocs");
		  Statement stmt=conn1.createStatement();
		  String sql="Select fname,lname from test_employee_details where nt_id='"+ntid+"'";
		  ResultSet rs=stmt.executeQuery(sql);
		  while(rs.next())
		  {
			  name=rs.getString("fname");
		  }
		  conn1.close();
	  } 
	  catch (SQLException e)
		{     e.printStackTrace(); 
        }
		catch (ClassNotFoundException e)
		{     e.printStackTrace(); 
		}
		if(name == null || ("").equalsIgnoreCase(name))
		{
			return ntid;
		}
		else
		{
		return name.toUpperCase();
		}
	}

}
