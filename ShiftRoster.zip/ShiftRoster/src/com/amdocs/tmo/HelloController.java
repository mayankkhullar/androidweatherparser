package com.amdocs.tmo;


import org.springframework.stereotype.Controller;
import java.sql.*;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
 
@Controller
public class HelloController {
 
  @RequestMapping("/Hello")
  public String hello() {
	 
    return "Hello";
  }
 
  @RequestMapping(value = "/Hi", method = RequestMethod.GET)
  public String hi(@RequestParam("name") String name, Model model) {
	  StringBuilder message=new StringBuilder(name);
	  try
      { 
	  Class.forName("oracle.jdbc.driver.OracleDriver");
	  Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@sahilba02:1521/xe","system", "amdocs");
	  if(conn !=null)
	  {
		  System.out.println("connected to database");
		  Statement stmt;
		  stmt = conn.createStatement();
	      String sql = "SELECT * FROM test";
	      ResultSet rs = stmt.executeQuery(sql);
//	      message=message.append("<table border=\"1\"><tr><th>ID</th><th>name</th><tr>");
//	      while(rs.next())
//	      {
//	    	  String temp = "<tr><td>: "+rs.getString("id")+" </td><td>"+rs.getString("name")+ "</td><tr>";
//	    	  message=message.append(temp);
//	      }
//	      message=message.append("</table>");
	      conn.close();
	  }
      }
      catch (Exception e)
      {
              e.printStackTrace();
          System.out.println("exc");
      }
  //  String message = "<b><u>Hi " + name + "!</u></b>";
    model.addAttribute("message", message.toString());
  return "Hi";
  }
 
}
